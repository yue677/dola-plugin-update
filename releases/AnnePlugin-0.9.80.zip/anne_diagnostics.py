"""Private-by-construction local diagnostics, bounded and retained for at most 48h."""
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import re
import stat
import threading
import time
import uuid

RETENTION_SECONDS = 48 * 3600
MAX_FILE_BYTES = 512 * 1024
MAX_TOTAL_BYTES = 8 * 1024 * 1024
NAME = re.compile(r'^anne-diag-(\d{14})-(\d+)-([a-f0-9]{8})\.jsonl$')
EVENTS = {
    'startup', 'startup_failed', 'load_started', 'load_finished', 'renderer_terminated',
    'page_metrics', 'page_console_error', 'log_export', 'plugin_started', 'generation_started',
    'generation_failed', 'generation_finished', 'plugin_progress', 'composer_input',
    'composer_verified', 'composer_mismatch', 'upload_progress', 'submission_key',
    'login_page_refresh', 'login_verification_failed', 'account_saved',
    'submission_preflight', 'submission_observed', 'submission_integrity',
    'original_lookup', 'original_download',
    'new_chat_ready',
}
NUMBERS = {
    'pid', 'account_index', 'status', 'error_code', 'exit_code', 'line', 'count', 'ready',
    'total', 'elapsed', 'percent', 'chars', 'lines', 'crlf', 'bare_cr', 'bare_lf',
    'expected_chars', 'actual_chars', 'expected_lines', 'actual_lines', 'difference_index',
    'dpr', 'width', 'height', 'input_count', 'visible_inputs', 'input_y', 'http_status',
    'requested_percent', 'effective_percent', 'minimum_native_dpi', 'qt_scale',
    'message_count', 'matching_messages', 'image_only_messages', 'attachment_count',
    'bitrate', 'content_length',
}
BOOLS = {'success', 'online', 'focused', 'dpi_detected', 'in_viewport', 'route_changed'}
ENUMS = {
    'lookup_status': {'resolving', 'waiting', 'ready'},
    'lookup_reason': {'none', 'directory_pending', 'original_pending', 'network', 'timeout',
                      'route_changed', 'identity', 'page_unavailable'},
    'mode': {'auto', 'compatible', 'standard', 'chat', 'video'},
    'reason': {'manual', 'dpi-unavailable', 'device-scale-below-one', 'native-rendering', 'other'},
    'ready_state': {'loading', 'interactive', 'complete'},
    'platform': {'dola', 'doubao'},
    'stage': {'progress', 'waiting', 'upload', 'composer', 'generation', 'download', 'login', 'other'},
    'error': {'composer_mismatch', 'login', 'timeout', 'network', 'upload', 'quota', 'other',
              'unexpected_submission', 'preparation_changed', 'attachment_changed', 'split_submission', 'route_unconfirmed',
              'account_plan_changed'},
    'method': {'enter', 'button'},
    'expected_kind': {'newline', 'tab', 'space', 'text', 'end', 'invisible', 'atom'},
    'actual_kind': {'newline', 'tab', 'space', 'text', 'end', 'invisible', 'atom'},
    'error_type': {'RuntimeError', 'TimeoutError', 'OSError', 'PermissionError', 'ValueError',
                   'TypeError', 'ConnectionError', 'ImportError', 'ModuleNotFoundError', 'OtherException'},
    'network_code': {'ERR_CERT_AUTHORITY_INVALID', 'ERR_CERT_DATE_INVALID', 'ERR_NAME_NOT_RESOLVED',
                     'ERR_PROXY_CONNECTION_FAILED', 'ERR_CONNECTION_RESET', 'ERR_CONNECTION_TIMED_OUT',
                     'ERR_CONNECTION_CLOSED', 'ERR_CONNECTION_REFUSED', 'ERR_NETWORK_CHANGED',
                     'ERR_INTERNET_DISCONNECTED', 'ERR_ABORTED', 'ERR_FAILED'},
}


def safe_fields(fields):
    result = {}
    for key, value in fields.items():
        if key in NUMBERS and isinstance(value, (int, float)) and not isinstance(value, bool):
            if math.isfinite(value) and abs(value) <= 1e12:
                result[key] = value
        elif key in BOOLS and isinstance(value, bool):
            result[key] = value
        elif key in ENUMS and isinstance(value, str) and value in ENUMS[key]:
            result[key] = value
        elif key in {'version', 'qt_version', 'os_version', 'plugin_version'} and isinstance(value, str):
            if re.fullmatch(r'\d{1,5}(?:\.\d{1,5}){1,4}', value):
                result[key] = value
    return result


def _plain(path):
    try:
        info = path.lstat()
        return not path.is_symlink() and not getattr(info, 'st_file_attributes', 0) & 0x400
    except OSError:
        return False


class Diagnostics:
    def __init__(self, directory, source='workbench', clock=time.time, background=True):
        self.directory = Path(directory).absolute()
        self.source = source if source in {'workbench', 'plugin'} else 'workbench'
        self.clock = clock
        self.lock = threading.RLock()
        self._path = None
        self._created = 0
        self.last_cleanup = 0
        self.disabled = False
        try:
            # Never follow a junction or symlink into another account/data directory.
            for parent in reversed([self.directory, *self.directory.parents]):
                if parent.exists() and not _plain(parent):
                    raise OSError('Linked diagnostic directory')
            self.directory.mkdir(parents=True, exist_ok=True)
            self.cleanup()
        except OSError:
            self.disabled = True
        if background and not self.disabled:
            threading.Thread(target=self._maintenance, name='AnneLogRetention', daemon=True).start()

    def _maintenance(self):
        while True:
            time.sleep(600)
            self.cleanup()

    def _files(self):
        if not _plain(self.directory):
            return []
        result = []
        for path in self.directory.iterdir():
            match = NAME.fullmatch(path.name)
            if not match or not _plain(path) or not path.is_file() or path.resolve().parent != self.directory.resolve():
                continue
            try:
                created = datetime.strptime(match[1], '%Y%m%d%H%M%S').replace(tzinfo=timezone.utc).timestamp()
                result.append((created, path.stat().st_size, path))
            except (ValueError, OSError):
                continue
        return sorted(result, key=lambda item: (item[0], item[2].name))

    def cleanup(self):
        if self.disabled:
            return
        with self.lock:
            try:
                now = self.clock()
                remaining = []
                for created, size, path in self._files():
                    # Files rotate at least hourly; expiry is based on their FIRST event.
                    if created < now - RETENTION_SECONDS:
                        path.unlink()
                        if path == self._path:
                            self._path = None
                    else:
                        remaining.append((created, size, path))
                total = sum(size for _, size, _ in remaining)
                for _, size, path in remaining:
                    if total <= MAX_TOTAL_BYTES:
                        break
                    path.unlink()
                    total -= size
                    if path == self._path:
                        self._path = None
                self.last_cleanup = now
            except OSError:
                pass  # Diagnostics cannot stop work because another process rotated a file.

    def record(self, event, **fields):
        if self.disabled or event not in EVENTS:
            return False
        with self.lock:
            try:
                now = self.clock()
                if now - self.last_cleanup >= 60:
                    self.cleanup()
                if not _plain(self.directory):
                    return False
                if self._path is None or not self._path.exists() or now - self._created >= 3600 or self._path.stat().st_size >= MAX_FILE_BYTES:
                    stamp = datetime.fromtimestamp(now, timezone.utc).strftime('%Y%m%d%H%M%S')
                    self._path = self.directory / f'anne-diag-{stamp}-{os.getpid()}-{uuid.uuid4().hex[:8]}.jsonl'
                    self._created = now
                    self._path.touch(exist_ok=False)
                if not _plain(self._path):
                    return False
                entry = dict(time=round(now, 3), source=self.source, event=event, **safe_fields(fields))
                with self._path.open('a', encoding='utf8') as output:
                    output.write(json.dumps(entry, ensure_ascii=False, separators=(',', ':')) + '\n')
                if self._path.stat().st_size >= MAX_FILE_BYTES:
                    self.cleanup()
                return True
            except (OSError, ValueError, TypeError):
                return False

    def snapshot(self):
        self.cleanup()
        rows = []
        with self.lock:
            now = self.clock()
            try:
                for _, _, path in self._files():
                    if path.stat().st_size > MAX_FILE_BYTES + 8192:
                        continue
                    with path.open(encoding='utf8') as source:
                        for line in source:
                            if len(line) > 8192:
                                continue
                            try:
                                row = json.loads(line)
                                stamp = row.get('time')
                                if not isinstance(stamp, (int, float)) or isinstance(stamp, bool) or not now - RETENTION_SECONDS <= stamp <= now + 60:
                                    continue
                                if row.get('event') not in EVENTS or row.get('source') not in {'workbench', 'plugin'}:
                                    continue
                                rows.append(dict(time=stamp, source=row['source'], event=row['event'], **safe_fields(row)))
                            except (ValueError, TypeError, AttributeError):
                                continue
            except OSError:
                pass
        return sorted(rows, key=lambda row: row['time'])

    def export(self, parent=None):
        # Exports are deliberately outside the rolling log directory: user copies aren't silently deleted.
        target = Path(parent) if parent is not None else self.directory.parent / '日志导出'
        if any(p.exists() and not _plain(p) for p in [target, *target.parents]):
            raise OSError('Linked export directory')
        target.mkdir(parents=True, exist_ok=True)
        rows = self.snapshot()
        name = 'Anne-诊断日志-' + datetime.now().strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:6] + '.txt'
        path = target / name
        with path.open('x', encoding='utf-8-sig') as output:
            output.write('Anne 本地诊断日志（最近48小时）\n')
            output.write('仅结构化运行信息；不含提示词、聊天、Cookie、授权码、账号名或完整网址。\n')
            output.write('不会自动上传。部分事件未记录不代表该环节一定正常。\n')
            output.write('事件说明：startup 启动；load_finished 网页加载；renderer_terminated 渲染退出；')
            output.write('page_metrics 页面尺寸；upload_progress 上传；composer_mismatch 输入不一致；generation_failed 生成失败。\n\n')
            for row in rows:
                output.write(json.dumps(row, ensure_ascii=False) + '\n')
        self.record('log_export', count=len(rows))
        return path


_workbench = None


def workbench(root):
    global _workbench
    folder = Path(root).absolute() / 'Data/desktop/diagnostics'
    if _workbench is None or _workbench.directory != folder:
        _workbench = Diagnostics(folder)
    return _workbench


class QuietConsole:
    """Legacy print output may contain account URLs/content; never persist it wholesale."""
    encoding = 'utf-8'
    errors = 'replace'
    def write(self, value):
        return len(str(value))
    def flush(self):
        pass
    def isatty(self):
        return False
