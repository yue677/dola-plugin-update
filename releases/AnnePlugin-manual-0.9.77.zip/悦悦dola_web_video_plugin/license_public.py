# Generated public verification key. This file contains no private signing data.

PUBLIC_MODULUS_B64 = (
    "sCscIDaHktntI5mgKxaXAeazPeMGIseemC+OiooQeruZyv12i9USSaXZeI30wxNm5NHf"
    "PGGQ6eePwnWBPedKwq1T8M81udW0+8Q3kvXcYUOqSaiyxuW6YbIsBJUjSyANs54uciP7"
    "faa81bKcoqdCkfs9czzVw3WHNK9gjZ3cbFSVQzK4X+W//W85QX8WnkQbJo+VK/vjgedz"
    "Se5B0fTCsLjIY2rE0HRkEN3tKBUokxVZo1tmNRzneAm7bm0qMjRQE7zIKjDtXLdqYlEs"
    "zXte0qqXDLj/p6OqTD0t9V4TpASorVjc5/p32rBdTmgpowH8xP7iOFTCs2nEKCjDosN/"
    "5w=="
)
PUBLIC_EXPONENT = 65537
