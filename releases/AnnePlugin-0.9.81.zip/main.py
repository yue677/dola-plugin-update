"""字字动画本地 Dola 30 秒漫剧视频插件。

插件通过现有 Dola 多账号管理器启动独立本地 Dola/Cici 客户端，再使用
Playwright 连接本地 ``dola-chat`` 页面。账号 Cookie 始终留在浏览器资料
目录中，插件不导出 Cookie，也不另开 dola.com 网页标签。
"""

from __future__ import annotations

import base64
from collections import deque
import configparser
from datetime import datetime, timedelta, timezone
import difflib
import hashlib
import html
import io
import json
import os
from pathlib import Path
import pickle
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile

# 字字动画会按文件路径动态加载插件，加载时不一定把插件目录加入
# sys.path。先显式加入本目录，确保授权联动模块能够稳定导入。
_BOOTSTRAP_PLUGIN_DIR = Path(__file__).resolve().parent
if str(_BOOTSTRAP_PLUGIN_DIR) not in sys.path:
    sys.path.insert(0, str(_BOOTSTRAP_PLUGIN_DIR))

_PLUGIN_VERSION = "0.9.81"
_PLUGIN_ID = "dola_doubao_auto_plugin"
_ACCOUNT_INDEX_BASE = 1
_MANAGER_API_ROOT = "http://127.0.0.1:8888"
_BEIJING_TIMEZONE = timezone(timedelta(hours=8))
_PLUGIN_DIR = Path(__file__).resolve().parent
_PLUGIN_FILE = str(Path(__file__).resolve())
_UPDATE_PRESERVE_NAMES = {
    "config.json", "data", "license_guard.py", "license_public.py",
    "local_update_policy.json",
    "runtime_state.json",
    "update_state.json",
    "dola_manager",
    "__pycache__",
}
_MAX_UPDATE_DOWNLOAD_BYTES = 256 * 1024 * 1024
_MAX_UPDATE_EXTRACT_BYTES = 512 * 1024 * 1024
_LEGACY_MANAGER_ROOT = Path(r"Z:\doladuokai2\最新1.68多开30s\最新1.68多开30s")
_PLUGINS_DIR = _PLUGIN_DIR.parent.parent
if str(_PLUGINS_DIR) not in sys.path:
    sys.path.insert(0, str(_PLUGINS_DIR))


def _load_local_authorization():
    """Load this installation's adapter, not a different plugin's cached module."""
    import importlib
    import types

    identity = os.path.normcase(str(_PLUGIN_DIR.resolve()))
    package_name = "_anne_plugin_auth_" + hashlib.sha256(identity.encode("utf-8")).hexdigest()
    if package_name not in sys.modules:
        package = types.ModuleType(package_name)
        package.__package__ = package_name
        package.__path__ = [str(_PLUGIN_DIR)]
        sys.modules[package_name] = package
    # Public installs always use the compatible guard delivered by this update.
    # Only the owner's existing local development adapter remains unchanged.
    policy = _PLUGIN_DIR / "local_update_policy.json"
    module_name = "license_guard" if policy.is_file() else "anne_auth_compat"
    return importlib.import_module(package_name + "." + module_name)


_local_license_guard = _load_local_authorization()
AuthorizationError = _local_license_guard.AuthorizationError
validate_authorization = _local_license_guard.validate_authorization

try:
    from plugin_utils import load_plugin_config
except Exception:
    def load_plugin_config(_plugin_file):
        return {}


_DEFAULT_PARAMS = {
    "target_platform": "dola",
    "doubao_group": "",
    "doubao_account_start": 1,
    # Empty means portable mode: use ``dola_manager`` beside this main.py.
    "manager_root": "",
    "account_start": 1,
    "account_end": 40,
    "force_account_start": False,
    "slots_per_account": 2,
    "required_credits": 2,
    "check_quota": True,
    "account_wait_timeout": 7200,
    "max_concurrent_generations": 2,
    "base_port": 9221,
    "model": "Seedance 2.5",
    "duration": "30",
    "aspect_ratio": "16:9",
    "same_chat_attempts": 1,
    "new_chat_attempts": 3,
    "submit_timeout": 120,
    "generation_timeout": 5400,
    # The local Dola page can stop updating while a job is running, or leave
    # the completed video card as an empty placeholder until it is refreshed.
    "result_refresh_interval": 120,
    "browser_start_timeout": 45,
    "startup_ready_timeout": 90,
    "startup_settle_seconds": 20,
    "login_confirm_seconds": 30,
    "video_entry_timeout": 45,
    "step_delay_seconds": 1,
    "upload_timeout": 180,
    "append_parameters": False,
    "allow_preview_fallback": False,
    "headless_mode": False,
    "update_manifest_url": "https://raw.githubusercontent.com/yue677/dola-plugin-update/main/manifest.json",
}

_global_params = {}
_platform_context = threading.local()
_adapter_import_lock = threading.RLock()


def _is_doubao():
    return getattr(_platform_context, 'name', 'dola') == 'doubao'


def _doubao_adapter():
    import importlib.util
    name = __name__ + '_doubao'
    with _adapter_import_lock:
        if name not in sys.modules:
            spec = importlib.util.spec_from_file_location(name, _PLUGIN_DIR / 'doubao_adapter.py')
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            sys.modules[name] = module
    return sys.modules[name]


_state_lock = threading.RLock()
_account_condition = threading.Condition(_state_lock)
_manager_api_lock = threading.RLock()
_manager_connection_context = threading.local()
_generation_lock = threading.RLock()
_generation_condition = threading.Condition(_generation_lock)
_generation_waiting = deque()
_generation_running = set()
_generation_concurrency_limit = 2
_generation_stop_in_progress = False
_plugin_update_in_progress = False
_plugin_update_restart_required = False
_stop_event = threading.Event()
_pause_event = threading.Event()
_network_pause_event = threading.Event()
_account_safety_event = threading.Event()
_account_safety_lock = threading.RLock()
_consecutive_logged_out = []
_account_safety_message = ""
_account_safety_retry_lock = threading.Lock()
_account_safety_check_passed = False
_network_guard_lock = threading.RLock()
_network_preflight_lock = threading.RLock()
_pause_clock_local = threading.local()
_network_guard_state = {}
_network_guard_last_poll = 0.0
_network_guard_batch_checked = False
_active_generation_count = 0
_inflight_generations = {}
_observed_credit_costs = {}
_active_slots = {}
_batch_logged_out = set()
_batch_unavailable = set()
# Set once per process: the workbench is asked to re-read its account files the
# first time a window has to be started, then again only when it reports a stale
# account/directory mapping.
_manager_accounts_refreshed = False
_batch_insufficient_quota = set()
_runtime_log_lock = threading.RLock()
_runtime_log_entries = deque(maxlen=500)
_runtime_log_sequence = 0
_runtime_log_last_seen = {}
_diagnostic_lock = threading.RLock()
_diagnostic_writers = {}
_diagnostic_context = threading.local()
_hidden_account_windows = {}


class LoginExpired(Exception):
    """The selected account is logged out and should be skipped this batch."""


class AccountUnavailable(Exception):
    """The selected account/browser cannot be used and should be skipped."""


class LocalConnectionError(Exception):
    """A local control connection failed; do not consume or rotate accounts."""


class UiNotReady(Exception):
    """The account is logged in, but the creation controls are not ready yet."""


class RecoveryPromptMismatch(Exception):
    """The restored chat does not contain this storyboard's complete prompt."""


class UploadNotReady(UiNotReady):
    """Reference assets did not become safely submittable in time."""


class PreparationUnconfirmed(Exception):
    """Keep the existing draft; never rotate, re-upload or auto-retry it."""


class VideoGenerationFailed(Exception):
    """Dola accepted the job but later reported that video generation failed."""


class InsufficientQuota(Exception):
    """The selected account has fewer credits than this video requires."""


class RegionUnavailable(Exception):
    """Dola rejected the current network region; switching accounts will not help."""


class ManualReviewRequired(Exception):
    """The platform returned a policy/face restriction that must not be bypassed."""


class PromptPolicyRejected(Exception):
    """The same prompt repeatedly received Dola's safety-guidance response."""


class GenerationStopped(Exception):
    """The user stopped all active work from the plugin settings."""


def _check_account_safety():
    if _is_doubao():
        return
    if _account_safety_event.is_set():
        raise GenerationStopped(_account_safety_message or "连续两个账号掉线，插件已全局停止，请重新点击生成视频并通过网络检测。")


def _account_safety_call(action, *args, **kwargs):
    """Guard this plugin's own browser calls; never patch other plugins globally."""
    _check_account_safety()
    result = action(*args, **kwargs)
    _check_account_safety()
    return result


def _account_safety_snapshot():
    if _is_doubao():return {'account_safety_stopped':False,'account_safety_message':'','consecutive_logged_out':[]}
    with _account_safety_lock:
        return {
            "account_safety_stopped": _account_safety_event.is_set(),
            "account_safety_message": _account_safety_message,
            "consecutive_logged_out": list(_consecutive_logged_out),
        }


def _account_login_confirmed(index):
    """Only a newly verified login breaks the streak, never background polling."""
    if index is None:
        return
    with _account_safety_lock:
        if not _account_safety_event.is_set():
            _consecutive_logged_out.clear()


def _retry_account_safety_from_generate():
    """Only a fresh generation call may request a new check and release the latch."""
    global _account_safety_message, _account_safety_check_passed
    global _network_guard_state, _network_guard_last_poll
    if _is_doubao():
        return
    if not _account_safety_event.is_set():
        return
    # Do not let a queued/in-flight worker or a duplicate click reset the latch.
    if not _account_safety_retry_lock.acquire(blocking=False):
        raise GenerationStopped("正在重新检测网络，请等待结果；尚未解除连续掉线保护。")
    try:
        with _generation_lock:
            if _active_generation_count or _generation_stop_in_progress:
                raise GenerationStopped("其他并发任务正在停止，请稍候再次点击生成视频。")
        _log("你已重新点击生成视频：先重新检测网络，通过前保持连续掉线保护，不切号、不提交。")
        try:
            state = _manager_api_request(
                "/automation_network_check", method="POST",
                data={"force": True}, timeout=65, safety_network_check=True,
            )
            speed = float(state.get("download_mbps"))
            passed = (
                state.get("success") is True and state.get("checked") is True
                and state.get("paused") is False and state.get("checking") is False
                and not state.get("reason") and 3 <= speed < float("inf")
            )
        except Exception as error:
            raise GenerationStopped(
                f"重新检测网络未完成：{error}；连续掉线保护仍锁定。请确认多开器已打开，稍后再次点击生成视频。"
            ) from error
        if not passed:
            detail = state.get("message") or "尚未得到符合 3 Mbps 和 IP 地区要求的检测结果"
            _log(str(detail) + " 连续掉线保护仍锁定；即使网络后台恢复，也需要再次点击生成视频。")
            raise GenerationStopped(str(detail) + "；未解除掉线保护，请网络稳定后再次点击生成视频。")
        with _network_guard_lock:
            _network_guard_state = dict(state)
            _network_guard_last_poll = time.monotonic()
            _network_pause_event.clear()
        with _account_safety_lock:
            _consecutive_logged_out.clear()
            _account_safety_message = ""
            _account_safety_check_passed = True
            _account_safety_event.clear()
        _log(f"本次网络复检通过（下载 {speed:.2f} Mbps），已解除连续掉线保护，仅启动本次点击的任务。")
    finally:
        _account_safety_retry_lock.release()


def _poll_network_guard(force=False):
    """Read the shared verdict; the manager owns fault-triggered background checks."""
    global _network_guard_last_poll, _network_guard_state
    if _is_doubao():
        return {}
    if _account_safety_event.is_set():
        return dict(_network_guard_state)
    now = time.monotonic()
    with _network_guard_lock:
        if not force and now - _network_guard_last_poll < 1.5:
            return dict(_network_guard_state)
        _network_guard_last_poll = now
        try:
            state = _manager_api_request("/automation_network_state", timeout=2)
        except Exception:
            return dict(_network_guard_state)
        previous = _network_guard_state
        _network_guard_state = state
        if state.get("paused"):
            _network_pause_event.set()
            if (
                not previous.get("paused")
                or previous.get("reason") != state.get("reason")
                or previous.get("message") != state.get("message")
            ):
                _log(
                    str(state.get("message") or "多开器要求暂停网络操作") +
                    " 字字插件所有自动操作已暂停；" +
                    str(state.get("action_hint") or "请重新检测并恢复。")
                )
        else:
            _network_pause_event.clear()
            if previous.get("paused"):
                _log(
                    "网络检测已通过；" +
                    ("仍保持手动暂停。" if _pause_event.is_set() else "继续原任务。")
                )
        return dict(state)


def _ensure_network_preflight():
    global _network_guard_batch_checked
    with _network_preflight_lock:
        if _network_guard_batch_checked:
            return
        try:
            _manager_api_request(
                "/automation_network_check", method="POST",
                data={"force": True}, timeout=65,
            )
        except urllib.error.HTTPError as error:
            if error.code == 404:
                raise RuntimeError(
                    "多开器缺少网络联动功能，请同步更新 launcher_core.py "
                    "和 dola_network_guard.py 后重启多开器。"
                ) from error
            raise
        _network_guard_batch_checked = True
    _poll_network_guard(force=True)
    _check_stopped()


def _check_stopped():
    # Pausing is cooperative: the current indivisible browser or network call
    # finishes, then every worker stays at the next action boundary without
    # closing the account or losing task state.
    _check_account_safety()
    paused_at = None
    _poll_network_guard()
    _check_account_safety()
    while _pause_event.is_set() or (not _is_doubao() and _network_pause_event.is_set()):
        _check_account_safety()
        if paused_at is None:
            paused_at = time.monotonic()
        if _stop_event.is_set():
            raise GenerationStopped("用户已停止 Dola 插件生成")
        time.sleep(0.2)
        _poll_network_guard()
    if _stop_event.is_set():
        raise GenerationStopped("用户已停止 Dola 插件生成")
    duration = time.monotonic() - paused_at if paused_at is not None else 0.0
    _pause_clock_local.total = getattr(_pause_clock_local, "total", 0.0) + duration
    return duration


def _active_wait_clock():
    """Timeouts exclude pauses even when a nested action was the pause boundary."""
    return time.monotonic() - getattr(_pause_clock_local, "total", 0.0)


def _diagnostic_record(event, **fields):
    try:
        from anne_diagnostics import Diagnostics
        folders=[_PLUGIN_DIR/'data'/'diagnostics']
        manager=getattr(_diagnostic_context,'root',None)
        if manager is not None:
            folders.append(Path(manager)/'Data'/'desktop'/'diagnostics')
        with _diagnostic_lock:
            for folder in folders:
                key=str(folder.absolute())
                if key not in _diagnostic_writers:
                    _diagnostic_writers[key]=Diagnostics(folder,source='plugin')
                    _diagnostic_writers[key].record('plugin_started',plugin_version=_PLUGIN_VERSION)
                _diagnostic_writers[key].record(event,plugin_version=_PLUGIN_VERSION,**fields)
    except Exception:
        pass  # Logging failure must not fail or repeat a generation.


def _diagnostic_runtime(message, kind):
    # UI logs may contain filenames or website replies. Persist only categories/counters.
    if kind=='error':
        code=('composer_mismatch' if '实际文本与分镜提示词不一致' in message else
              'upload' if '上传' in message else 'timeout' if '超时' in message else
              'login' if '登录' in message or '掉线' in message else
              'quota' if '额度' in message else 'network' if '连接' in message else 'other')
        _diagnostic_record('generation_failed',error=code)
    elif kind=='progress':
        stage=('upload' if '上传' in message or '参考图' in message else
               'composer' if '输入框' in message or '文本核对' in message else
               'download' if '下载' in message or '原片' in message else
               'waiting' if '等待' in message or '排队' in message else 'generation')
        _diagnostic_record('plugin_progress',stage=stage)


def _append_runtime_log(message, kind="info", dedupe_seconds=0):
    global _runtime_log_sequence
    text = re.sub(r"\s+", " ", str(message or "")).strip()
    if not text:
        return
    now = time.time()
    key = (threading.get_ident(), str(kind), text)
    with _runtime_log_lock:
        if dedupe_seconds and now - _runtime_log_last_seen.get(key, 0) < dedupe_seconds:
            return
        _runtime_log_last_seen[key] = now
        _runtime_log_sequence += 1
        _runtime_log_entries.append(
            {
                "id": _runtime_log_sequence,
                "time": time.strftime("%H:%M:%S", time.localtime(now)),
                "kind": str(kind or "info"),
                "message": text,
            }
        )
    _diagnostic_runtime(text,str(kind))


def _runtime_log_snapshot(after=0, limit=250):
    after = _as_int(after, 0, 0)
    limit = _as_int(limit, 250, 1, 500)
    with _runtime_log_lock:
        values = [item for item in _runtime_log_entries if item["id"] > after]
        return values[-limit:]


def _clear_runtime_logs():
    global _runtime_log_sequence
    with _runtime_log_lock:
        _runtime_log_entries.clear()
        _runtime_log_last_seen.clear()
        _runtime_log_sequence = 0


def _log(message):
    _append_runtime_log(message, "info")
    print(f"[Dola漫剧] {message}")


def _progress(callback, text, percent=None):
    _check_stopped()
    _append_runtime_log(text, "progress", dedupe_seconds=8)
    if not callback:
        return
    try:
        if percent is None:
            callback(text)
        else:
            callback(text, max(0, min(100, int(percent))))
    except Exception:
        pass


def _as_int(value, default, minimum=None, maximum=None):
    try:
        result = int(value)
    except (TypeError, ValueError):
        result = int(default)
    if minimum is not None:
        result = max(int(minimum), result)
    if maximum is not None:
        result = min(int(maximum), result)
    return result


def _as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return bool(default)
    return str(value).strip().lower() in {"1", "true", "yes", "on", "是"}


def _credit_cost_key(params):
    model = re.sub(r"\s+", " ", str(params.get("model") or "").strip()).lower()
    duration = str(params.get("duration") or "").strip().lower().rstrip("s秒 ")
    return model, duration


def _fixed_model_credit_cost(model, duration='', platform='dola'):
    normalized = re.sub(r"\s+", " ", str(model or "").strip()).lower()
    if normalized == "seedance 2.0 fast":
        # The 1-credit path was measured on Dola only (30-second request, Dola still returns
        # a 15-second video). Doubao has its own accounting and keeps the original 3.
        if str(platform or 'dola').strip().lower() == 'doubao':
            return 3
        if str(duration).strip().lower().rstrip('s秒 ') == '30':
            return 1
        return 3
    if normalized == "seedance 2.5":
        return 2
    return None


def _model_account_limit(model, fallback=2, platform='dola'):
    normalized = re.sub(r"\s+", " ", str(model or "").strip()).lower()
    if normalized == "seedance 2.0 fast":
        # Dola: the 30-second request costs 1 credit, so a 4-credit account can produce up to
        # 4 videos. Doubao keeps its original one-job-per-account rule.
        if str(platform or 'dola').strip().lower() == 'doubao':
            return 1
        return 4
    if normalized == 'seedance 2.0':
        # Dola only: the 15-second variant costs 3 credits, so a 4-credit account gets one job.
        if str(platform or 'dola').strip().lower() == 'doubao':
            return _as_int(fallback, 2, 1, 20)
        return 1
    if normalized == "seedance 2.5":
        return 2
    return _as_int(fallback, 2, 1, 20)


def _model_reference_limit(model):
    normalized = re.sub(r"\s+", " ", str(model or "").strip()).lower()
    if "2.0 fast" in normalized:
        return 9
    if "2.5" in normalized:
        return 30
    return 30


def _effective_required_credits(params):
    key = _credit_cost_key(params)
    fixed = _fixed_model_credit_cost(key[0], key[1], params.get('target_platform') or 'dola')
    if fixed is not None:
        return fixed
    with _state_lock:
        observed = _observed_credit_costs.get(key)
    if observed is not None:
        return _as_int(observed, 1, 1, 20)
    model, _duration = key
    return _as_int(params.get("required_credits"), 2, 1, 20)


def _fresh_params(context=None):
    params = dict(_DEFAULT_PARAMS)
    try:
        disk = load_plugin_config(_PLUGIN_FILE)
        if isinstance(disk, dict):
            params.update(disk)
    except Exception as error:
        _log(f"读取插件配置失败，采用默认值：{error}")
    params.update(_global_params)
    if isinstance(context, dict) and isinstance(context.get("plugin_params"), dict):
        params.update(context["plugin_params"])

    params["account_start"] = _as_int(params.get("account_start"), 1, 1)
    params["doubao_account_start"] = _as_int(params.get("doubao_account_start"), 1, 1, 9999)
    params["max_concurrent_generations"] = _as_int(
        params.get("max_concurrent_generations"), 2, 2, 5
    )
    params["account_end"] = _as_int(
        params.get("account_end"), 40, params["account_start"]
    )
    params["force_account_start"] = _as_bool(
        params.get("force_account_start"), False
    )
    params["slots_per_account"] = _model_account_limit(
        params.get("model"), params.get("slots_per_account"),
        params.get("target_platform") or 'dola'
    )
    params["required_credits"] = _effective_required_credits(params)
    # The port family is determined by the selected manager, never by a stale
    # value copied from another computer.
    params["base_port"] = _detect_manager_base_port(params)
    params["same_chat_attempts"] = 1
    params["new_chat_attempts"] = 3
    params["submit_timeout"] = _as_int(
        params.get("submit_timeout"), 120, 60, 600
    )
    params["generation_timeout"] = _as_int(
        params.get("generation_timeout"), 5400, 300, 7200
    )
    params["result_refresh_interval"] = _as_int(
        params.get("result_refresh_interval"), 120, 0, 300
    )
    # Migrate the previous 40-minute setting. Real Dola jobs can arrive after
    # that deadline even though the queue acknowledgement estimates 15 minutes.
    if params["generation_timeout"] < 5400:
        params["generation_timeout"] = 5400
    params["browser_start_timeout"] = _as_int(
        params.get("browser_start_timeout"), 45, 10, 180
    )
    params["startup_ready_timeout"] = _as_int(
        params.get("startup_ready_timeout"), 90, 30, 180
    )
    params["startup_settle_seconds"] = _as_int(
        params.get("startup_settle_seconds"), 20, 5, 60
    )
    params["login_confirm_seconds"] = _as_int(
        params.get("login_confirm_seconds"), 30, 10, 90
    )
    params["video_entry_timeout"] = _as_int(
        params.get("video_entry_timeout"), 45, 15, 180
    )
    params["step_delay_seconds"] = _as_int(
        params.get("step_delay_seconds"), 1, 1, 10
    )
    params["upload_timeout"] = _as_int(
        params.get("upload_timeout"), 180, 30, 600
    )
    params["account_wait_timeout"] = _as_int(
        params.get("account_wait_timeout"), 7200, 60, 21600
    )
    params["check_quota"] = _as_bool(params.get("check_quota"), True)
    params["append_parameters"] = _as_bool(
        params.get("append_parameters"), True
    )
    params["allow_preview_fallback"] = _as_bool(
        params.get("allow_preview_fallback"), False
    )
    params["headless_mode"] = _as_bool(params.get("headless_mode"), False)
    params["update_manifest_url"] = str(
        params.get("update_manifest_url") or ""
    ).strip()
    return params


def get_params():
    return _fresh_params()


def load_params(params):
    if isinstance(params, dict):
        _global_params.update(params)
        if "max_concurrent_generations" in params:
            _set_generation_concurrency(params["max_concurrent_generations"])


def get_info():
    return {
        "name": f"Anne自动化插件 v{_PLUGIN_VERSION}",
        "description": (
            "复用本地 Dola 多账号管理器，读取已有视频额度状态，自动绑定分镜资产、"
            "选择指定 Seedance 模型/15或30秒/16:9、轮换账号并下载最高画质视频。"
        ),
        "version": _PLUGIN_VERSION,
        "author": "本地定制",
    }


def _runtime_state_path():
    return _PLUGIN_DIR / "runtime_state.json"


def _quota_day(now=None):
    """Dola daily quota day: UTC 00:00, equal to Beijing 08:00."""
    value = now or datetime.now(timezone.utc)
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc).strftime("%Y-%m-%d")


def _empty_state():
    return {
        "date": _quota_day(),
        "quota_reset_timezone": "UTC",
        "account_index_base": _ACCOUNT_INDEX_BASE,
        "submitted": {},
        "last_account": None,
        # Accounts that failed today (logged out, would not start, out of quota).
        # They are skipped for the rest of the quota day instead of being retried
        # by every later batch, like the Doubao scheduler's day markers.
        "day_blocked": {},
        # A submission is recorded before the long generation wait starts.
        # If the host task is stopped meanwhile, clicking retry can reopen the
        # exact account/conversation and return the already-finished result.
        "recoveries": {},
        "recovered": {},
    }


def _load_state_unlocked():
    path = _runtime_state_path()
    try:
        with path.open("r", encoding="utf-8") as file:
            state = json.load(file)
        if not isinstance(state, dict) or state.get("account_index_base") != _ACCOUNT_INDEX_BASE:
            return _empty_state()
        if state.get("quota_reset_timezone") != "UTC":
            # Migrate the former Beijing-midnight counter without clearing it.
            # This avoids granting an extra reset when upgrading from 00:00 to
            # 07:59 Beijing time; the next real reset remains Beijing 08:00.
            state["date"] = _quota_day()
            state["quota_reset_timezone"] = "UTC"
            _save_state_unlocked(state)
        if state.get("date") != _quota_day():
            fresh = _empty_state()
            cutoff = int(time.time()) - 7 * 24 * 60 * 60
            for name in ("recoveries", "recovered"):
                values = state.get(name)
                if not isinstance(values, dict):
                    continue
                fresh[name] = {
                    key: value
                    for key, value in values.items()
                    if isinstance(value, dict)
                    and _as_int(value.get("saved_at"), 0, 0) >= cutoff
                }
            _save_state_unlocked(fresh)
            _batch_logged_out.clear()
            _batch_unavailable.clear()
            _batch_insufficient_quota.clear()
            _append_runtime_log(
                "UTC 00:00（北京时间 08:00）已自动重置每日账号次数和额度跳过状态",
                "info",
            )
            return fresh
        if not isinstance(state.get("submitted"), dict):
            state["submitted"] = {}
        if not isinstance(state.get("recoveries"), dict):
            state["recoveries"] = {}
        if not isinstance(state.get("recovered"), dict):
            state["recovered"] = {}
        if not isinstance(state.get("day_blocked"), dict):
            state["day_blocked"] = {}
        state["day_blocked"] = {
            key: value
            for key, value in state["day_blocked"].items()
            if value == state.get("date")
        }
        return state
    except Exception:
        return _empty_state()


def _save_state_unlocked(state):
    path = _runtime_state_path()
    temp = path.with_suffix(".tmp")
    path.parent.mkdir(parents=True, exist_ok=True)
    with temp.open("w", encoding="utf-8") as file:
        json.dump(state, file, ensure_ascii=False, indent=2)
    os.replace(str(temp), str(path))


def _known_dola_account_numbers(params):
    """Ask the workbench which Dola accounts really exist (positive numbers).

    The start/end fields are typed by hand, so a range like 1..20 used to make the
    plugin open windows for numbers that do not exist: those open blank and then
    cannot be closed. An empty result means "unknown" and the manual range is kept.
    """
    try:
        payload = _manager_api_request('/desktop/dola/accounts', timeout=20)
    except Exception:
        return set()
    rows = payload.get('accounts') if isinstance(payload, dict) else None
    if not isinstance(rows, list):
        return set()
    numbers = set()
    for row in rows:
        if isinstance(row, dict) and type(row.get('index')) is int and row['index'] > 0:
            numbers.add(row['index'])
    return numbers


def _account_range(params):
    # The manager and encrypted account files both use account numbers 1..N.
    start = params["account_start"]
    end = params["account_end"]
    numbers = list(range(start, end + 1))
    known = _known_dola_account_numbers(params)
    if known:
        numbers = [number for number in numbers if number in known]
    return numbers


def _reserve_account(params, excluded=None, preferred_account=None):
    excluded = set(excluded or ())
    deadline = time.monotonic() + params["account_wait_timeout"]
    while True:
        _check_stopped()
        with _account_condition:
            _check_account_safety()
            state = _load_state_unlocked()
            accounts = _account_range(params)
            if not accounts:
                raise RuntimeError("账号范围为空")
            # Plain mode always starts at the configured start number and walks up
            # (1, 2, 3 ...) so the first accounts are used first. The forced mode
            # (start number >= 2) keeps advancing past the last used account.
            forced = bool(params.get("force_account_start")) or _as_int(
                params.get("account_start"), 1, 1
            ) >= 2
            blocked_today = {
                int(key)
                for key, value in (state.get("day_blocked") or {}).items()
                if value == state.get("date") and str(key).isdigit()
            }
            last = state.get("last_account")
            if forced and last in accounts:
                pivot = accounts.index(last) + 1
                accounts = accounts[pivot:] + accounts[:pivot]

            # If recovery proves that an earlier task failed without consuming
            # quota, retry that same account before applying normal round-robin
            # scheduling. A busy preferred account is waited for rather than
            # silently switching accounts and spending another account's slot.
            preferred = _as_int(preferred_account, 0, 0)
            if (
                preferred in accounts
                and preferred not in excluded
                and preferred not in blocked_today
                and preferred not in _batch_logged_out
                and preferred not in _batch_unavailable
                and preferred not in _batch_insufficient_quota
                and _as_int(
                    state["submitted"].get(str(preferred), 0), 0, 0
                ) < params["slots_per_account"]
            ):
                if _as_int(_active_slots.get(preferred, 0), 0, 0):
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        raise RuntimeError("等待原失败任务账号空闲超时")
                    _account_condition.wait(timeout=min(2.0, remaining))
                    continue
                _active_slots[preferred] = 1
                state["last_account"] = preferred
                _save_state_unlocked(state)
                _log(
                    f"原任务失败且额度未扣除，本次锁定账号{preferred}"
                    "新建对话原样重提，不切换账号"
                )
                return preferred

            available_accounts = [
                index
                for index in accounts
                if index not in excluded
                and index not in blocked_today
                and index not in _batch_logged_out
                and index not in _batch_unavailable
                and index not in _batch_insufficient_quota
            ]
            waiting_for_account = False
            # Plain mode: every account gets its configured slots, taken in
            # ascending account order from the start number. Forced mode ignores
            # the per-account cap and simply walks the accounts in order.
            for round_index in range(1 if forced else params["slots_per_account"]):
                round_accounts = [
                    index
                    for index in available_accounts
                    if forced
                    or _as_int(state["submitted"].get(str(index), 0), 0, 0) == round_index
                ]
                if not round_accounts:
                    continue
                for index in round_accounts:
                    active = _as_int(_active_slots.get(index, 0), 0, 0)
                    if active:
                        waiting_for_account = True
                        continue
                    # A local Dola window must only be controlled by one storyboard at a time.
                    _active_slots[index] = 1
                    state["last_account"] = index
                    _save_state_unlocked(state)
                    _log(
                        f"强制模式：按账号编号顺序推进，本次选择账号{index}"
                        if forced else
                        f"账号调度进入第 {round_index + 1}/{params['slots_per_account']} 轮，"
                        f"本次选择账号{index}"
                    )
                    return index
                # Never enter a later round while a lower-round account is
                # merely busy. Wait for that account's current task to settle.
                break

            if not waiting_for_account:
                raise RuntimeError("没有可用账号：账号可能已退出、启动失败或今日额度已用完")
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise RuntimeError("等待可用账号超时")
            _account_condition.wait(timeout=min(2.0, remaining))


def _release_account(index):
    with _account_condition:
        active = _as_int(_active_slots.get(index, 0), 0, 0)
        if active <= 1:
            _active_slots.pop(index, None)
        else:
            _active_slots[index] = active - 1
        _account_condition.notify_all()


def _mark_submitted(index):
    with _state_lock:
        state = _load_state_unlocked()
        key = str(index)
        state["submitted"][key] = _as_int(state["submitted"].get(key, 0), 0, 0) + 1
        _save_state_unlocked(state)


def _submitted_count(index):
    with _state_lock:
        state = _load_state_unlocked()
        return _as_int(state.get("submitted", {}).get(str(index), 0), 0, 0)


def _unmark_submitted(index):
    with _state_lock:
        state = _load_state_unlocked()
        key = str(index)
        current = _as_int(state.get("submitted", {}).get(key, 0), 0, 0)
        if current <= 1:
            state.get("submitted", {}).pop(key, None)
        else:
            state["submitted"][key] = current - 1
        _save_state_unlocked(state)
    # Remove only the local pending reservation inferred from this receipt.
    # This does not establish whether Dola charged/refunded any real credits.
    with _account_condition:
        _batch_insufficient_quota.discard(index)
        _account_condition.notify_all()


def _recovery_key(context):
    unique_name = str((context or {}).get("unique_name") or "").strip()
    if unique_name:
        return unique_name
    fallback = "|".join(
        str((context or {}).get(name) or "")
        for name in ("viewer_index", "output_position", "prompt")
    )
    return hashlib.sha256(fallback.encode("utf-8", errors="ignore")).hexdigest()


def _task_fingerprint(context, params):
    prompt = _submission_prompt(str((context or {}).get("prompt") or ""), params)
    normalized = _normalized_task_text(prompt)
    return hashlib.sha256(normalized.encode("utf-8", errors="ignore")).hexdigest()


def _remember_recovery(context, params, index, chat_url):
    key = _recovery_key(context)
    prompt = _submission_prompt(str(context.get("prompt") or ""), params)
    record = {
        "account": int(index),
        "chat_url": str(chat_url or ""),
        "prompt_hash": _task_fingerprint(context, params),
        "prompt_markers": list(_task_prompt_markers(prompt)),
        "saved_at": int(time.time()),
    }
    with _state_lock:
        state = _load_state_unlocked()
        recoveries = state.setdefault("recoveries", {})
        previous = recoveries.get(key)
        if isinstance(previous, dict) and (
            int(previous.get("account") or 0) != int(index)
            or str(previous.get("chat_url") or "") != str(chat_url or "")
        ):
            history = state.setdefault("recovery_history", {}).setdefault(key, [])
            signature = (
                int(previous.get("account") or 0),
                str(previous.get("chat_url") or ""),
            )
            if not any(
                isinstance(item, dict)
                and (
                    int(item.get("account") or 0),
                    str(item.get("chat_url") or ""),
                ) == signature
                for item in history
            ):
                history.append(previous)
            history.sort(
                key=lambda item: int(item.get("saved_at") or 0)
                if isinstance(item, dict)
                else 0,
                reverse=True,
            )
            del history[8:]
        recoveries[key] = record
        # A fresh Dola submission supersedes an older completed/recovered mark.
        state.setdefault("recovered", {}).pop(key, None)
        _save_state_unlocked(state)


def _forget_recovery(context):
    key = _recovery_key(context)
    with _state_lock:
        state = _load_state_unlocked()
        state.setdefault("recoveries", {}).pop(key, None)
        _save_state_unlocked(state)


def _mark_recovery_complete(context, params, index, chat_url):
    key = _recovery_key(context)
    with _state_lock:
        state = _load_state_unlocked()
        state.setdefault("recoveries", {}).pop(key, None)
        state.setdefault("recovery_history", {}).pop(key, None)
        state.setdefault("recovered", {})[key] = {
            "account": int(index),
            "chat_url": str(chat_url or ""),
            "prompt_hash": _task_fingerprint(context, params),
            "saved_at": int(time.time()),
        }
        _save_state_unlocked(state)


def _recovery_plan(context, params):
    """Return only the newest saved chat for this exact storyboard."""
    # Recovery is a user-triggered retry feature. A first/active generation
    # must stay in its submitted chat and must never enter the old-video lookup
    # path merely because Dola temporarily renders a blank page after refresh.
    if _as_int((context or {}).get("generation_round"), 0, 0) <= 0:
        return []
    key = _recovery_key(context)
    fingerprint = _task_fingerprint(context, params)
    with _state_lock:
        state = _load_state_unlocked()
        record = state.get("recoveries", {}).get(key)
        history = state.get("recovery_history", {}).get(key) or []
    candidates = []
    seen = set()
    for item in [record, *history]:
        if not isinstance(item, dict) or item.get("prompt_hash") != fingerprint:
            continue
        signature = (
            _as_int(item.get("account"), 0, 0),
            str(item.get("chat_url") or ""),
        )
        if not signature[0] or not signature[1] or signature in seen:
            continue
        seen.add(signature)
        candidates.append(item)
    candidates.sort(
        key=lambda item: int(item.get("saved_at") or 0), reverse=True
    )
    # generation_round only identifies the host output round. It is not proof
    # that an older Dola conversation exists. Without an exact saved account
    # and chat URL, fall through to normal scheduling instead of opening other
    # account windows to search for a possible old result.
    return candidates[:1]


def _mark_day_blocked(index):
    """Remember a failed account for the rest of the quota day."""
    try:
        key = str(int(index))
    except (TypeError, ValueError):
        return
    with _state_lock:
        state = _load_state_unlocked()
        if not isinstance(state.get("day_blocked"), dict):
            state["day_blocked"] = {}
        state["day_blocked"][key] = state.get("date") or _quota_day()
        _save_state_unlocked(state)


def _mark_logged_out(index):
    global _account_safety_message
    index = int(index)
    _mark_day_blocked(index)
    triggered = False
    with _account_condition:
        _batch_logged_out.add(index)
        with _account_safety_lock:
            if not _account_safety_event.is_set() and index not in _consecutive_logged_out:
                _consecutive_logged_out.append(index)
                if len(_consecutive_logged_out) >= 2:
                    accounts = "、".join(str(i) + "号" for i in _consecutive_logged_out)
                    _account_safety_message = (
                        f"连续确认两个账号掉线（{accounts}），已触发全局保护："
                        "所有并发和排队任务停止，不再切号、提交、刷新或下载。"
                        "请检查网络节点和账号登录状态，再点击生成视频重新检测网络，通过后才继续；不会自动恢复。"
                    )
                    _account_safety_event.set()
                    triggered = True
        _account_condition.notify_all()
    if triggered:
        _log(_account_safety_message)
    _check_account_safety()


def _mark_unavailable(index):
    _mark_day_blocked(index)
    with _account_condition:
        _batch_unavailable.add(index)
        _account_condition.notify_all()


def _mark_insufficient_quota(index):
    _mark_day_blocked(index)
    with _account_condition:
        _batch_insufficient_quota.add(index)
        _account_condition.notify_all()


def _dola_schedule_preview(params, state, rows):
    """Read-only candidate preview matching normal/forced reservation order."""
    forced = bool(params.get('force_account_start')) or params['account_start'] >= 2
    eligible = [row for row in rows if row['in_range'] and not row['blocked']]
    result = dict(mode='forced' if forced else 'rounds', round=None,
                  total_rounds=params['slots_per_account'], next_account=None, waiting=False)
    if forced:
        last = state.get('last_account')
        numbers = [row['index'] for row in eligible]
        # Pivot on the full configured range even when the last account is blocked.
        ordered = [row['index'] for row in rows if row['in_range']]
        if last in ordered:
            pivot = ordered.index(last) + 1
            ordered = ordered[pivot:] + ordered[:pivot]
            numbers = [index for index in ordered if index in numbers]
        candidates = {row['index']: row for row in eligible}
        result['next_account'] = next((index for index in numbers if not candidates[index]['active']), None)
        result['waiting'] = bool(eligible) and result['next_account'] is None
        return result
    eligible = [row for row in eligible if row['used'] < row['capacity']]
    if not eligible:
        return result
    used = min(row['used'] for row in eligible)
    current = [row for row in eligible if row['used'] == used]
    result.update(round=used + 1,
                  next_account=next((row['index'] for row in current if not row['active']), None))
    result['waiting'] = result['next_account'] is None
    return result


def _restore_dola_account(params, data):
    """Explicitly unskip one account; never reset usage, jobs or global pauses."""
    if params.get('target_platform', 'dola') != 'dola':
        return dict(ok=False, error='请切换到 Dola 后恢复账号调度。')
    index = data.get('index') if isinstance(data, dict) else None
    numbers = _known_dola_account_numbers(params) or set(_account_range(params))
    if type(index) is not int or index <= 0 or index not in numbers:
        return dict(ok=False, error='账号不存在，未修改调度记录。')
    with _account_condition:
        if _as_int(_active_slots.get(index, 0), 0, 0):
            return dict(ok=False, error='该账号正在处理任务，请等待任务结束后恢复。')
        state = _load_state_unlocked()
        marked = (str(index) in state.get('day_blocked', {}) or index in _batch_logged_out
                  or index in _batch_unavailable or index in _batch_insufficient_quota)
        if marked:
            state.setdefault('day_blocked', {}).pop(str(index), None)
            # A manual login/top-up makes this account's old balance stale.
            state.setdefault('credits', {}).pop(str(index), None)
            _save_state_unlocked(state)  # Keep in-memory skip sets on a failed write.
            _batch_logged_out.discard(index)
            _batch_unavailable.discard(index)
            _batch_insufficient_quota.discard(index)
            _account_condition.notify_all()
        used = _as_int(state.get('submitted', {}).get(str(index), 0), 0, 0)
    message = f'已解除 Dola {index} 的异常跳过标记，已提交次数仍为 {used}，未增加额度。' if marked else f'Dola {index} 当前没有异常跳过标记。'
    if _account_safety_event.is_set():
        message += ' 连续掉线保护仍保持停止，请重新点击生成视频进行网络检查。'
    return dict(ok=True, message=message, dola=_dola_state_snapshot(params))


def _dola_state_snapshot(params):
    """Per-account status rows for the Dola panel (read-only, never starts a job)."""
    with _state_lock:
        state = _load_state_unlocked()
        submitted = {}
        for key, value in (state.get("submitted") or {}).items():
            try:
                submitted[int(key)] = _as_int(value, 0, 0)
            except (TypeError, ValueError):
                continue
        slots = max(1, _as_int(params.get("slots_per_account"), 2, 1))
        forced = bool(params.get('force_account_start')) or params['account_start'] >= 2
        # The status list always covers every real Dola account, even those outside the
        # configured start/end range: the range controls scheduling, not visibility.
        known = _known_dola_account_numbers(params)
        numbers = sorted(known) if known else _account_range(params)
        accounts = []
        for index in numbers:
            used = submitted.get(index, 0)
            in_range = params['account_start'] <= index <= params['account_end']
            active = bool(_as_int(_active_slots.get(index, 0), 0, 0))
            blocked_today = (state.get("day_blocked") or {}).get(str(index)) == (
                state.get("date") or _quota_day()
            )
            if index in _batch_logged_out:
                state_text, detail = "登录失效", "当天已跳过"
            elif index in _batch_unavailable:
                state_text, detail = "启动失败", "当天已跳过；工作台会先重读账号列表再重试"
            elif index in _batch_insufficient_quota:
                state_text, detail = "额度不足", "当天已跳过"
            elif blocked_today:
                state_text, detail = "当天已跳过", "本批次不再尝试"
            elif used >= slots and not forced:
                state_text, detail = "本批次已满", f"已完成 {used}/{slots}"
            else:
                state_text, detail = "可调度", f"本批次 {used}/{slots}"
            blocked = (blocked_today or index in _batch_logged_out or index in _batch_unavailable
                       or index in _batch_insufficient_quota)
            if active and not blocked:
                state_text = '处理中'
            elif not in_range and not blocked:
                state_text = '范围外'
            credits = (state.get("credits") or {}).get(str(index))
            if (type(credits) is not int or credits < 0 or
                    (state.get('credits_day') or state.get('date')) != (state.get('date') or _quota_day())):
                credits = None
            if credits is not None:
                detail = f"{detail} · 剩余 {credits} 额度"
            accounts.append(dict(index=index, state=state_text, detail=detail, used=used,
                                 capacity=slots, credits=credits, in_range=in_range, active=active,
                                 blocked=bool(blocked), can_restore=bool(blocked and not active)))
        used_total = sum(submitted.values())
        return dict(
            used=used_total,
            ready=sum(1 for row in accounts if row["state"] == "可调度"),
            unavailable=sum(1 for row in accounts if row["state"] in {"登录失效", "启动失败", "额度不足"}),
            slots=slots,
            total_capacity=len(accounts) * slots,
            message=_account_state_message(params),
            schedule=_dola_schedule_preview(params, state, accounts),
            accounts=accounts,
        )


def _account_state_message(params):
    with _state_lock:
        state = _load_state_unlocked()
        used = sum(_as_int(v, 0, 0) for v in state.get("submitted", {}).values())
        total_accounts = len(_account_range(params))
        total_capacity = total_accounts * params["slots_per_account"]
        logged_out = ", ".join(str(i) for i in sorted(_batch_logged_out)) or "无"
        unavailable = ", ".join(str(i) for i in sorted(_batch_unavailable)) or "无"
        insufficient = ", ".join(
            str(i) for i in sorted(_batch_insufficient_quota)
        ) or "无"
        return (
            f"今日已成功提交 {used}/{total_capacity} 条；"
            f"本批次登录失效账号：{logged_out}；启动失败账号：{unavailable}；"
            f"额度不足账号：{insufficient}；每日 UTC 00:00（北京时间 08:00）重置"
        )


def _port_open(port):
    try:
        with socket.create_connection(("127.0.0.1", int(port)), timeout=0.35):
            return True
    except OSError:
        return False


def _devtools_probe(port, timeout=2):
    """Read only this account's loopback CDP endpoint, without inherited proxies."""
    port = int(port)
    result = {"ready": False, "endpoint": "", "reason": "", "detail": ""}
    if not _port_open(port):
        return dict(result, reason="not_listening", detail="本机端口未监听，客户端尚未启动好或已退出")
    try:
        request = urllib.request.Request(
            f"http://127.0.0.1:{port}/json/version",
            headers={"Accept": "application/json"},
        )
        with _manager_urlopen(request, timeout=timeout) as response:
            raw = response.read(65537)
        if len(raw) > 65536:
            return dict(result, reason="invalid_payload", detail="本机接口返回内容异常，超过正常调试数据大小")
        payload = json.loads(raw.decode("utf-8"))
        endpoint = payload.get("webSocketDebuggerUrl") if isinstance(payload, dict) else None
        if not isinstance(endpoint, str) or not endpoint:
            return dict(result, reason="invalid_payload", detail="本机接口未返回有效的浏览器控制地址")
        parsed = urllib.parse.urlsplit(endpoint)
        if (
            parsed.scheme not in ("ws", "wss")
            or parsed.hostname not in ("127.0.0.1", "localhost", "::1")
            or parsed.port != port
            or parsed.username is not None or parsed.password is not None
            or not parsed.path.startswith("/devtools/browser/")
            or not parsed.path[len("/devtools/browser/"):]
        ):
            return dict(result, reason="invalid_endpoint", detail="控制地址与当前账号的本机端口不一致，已拒绝连接以防串号")
        return dict(result, ready=True, endpoint=endpoint)
    except urllib.error.HTTPError as error:
        return dict(result, reason="http_error", detail=f"本机调试接口返回 HTTP {error.code}")
    except (TimeoutError, socket.timeout):
        return dict(result, reason="timeout", detail="本机调试接口响应超时")
    except (ValueError, UnicodeError):
        return dict(result, reason="invalid_payload", detail="本机接口返回内容不是有效的调试数据")
    except Exception as error:
        # Never expose response bodies, proxy credentials or websocket URLs.
        return dict(result, reason="request_failed", detail=f"本机调试请求失败（{type(error).__name__}）")


def _devtools_ready(port):
    return _devtools_probe(port)["ready"]


def _local_connection_error(index, port, detail):
    return LocalConnectionError(
        f"账号{index}无法连接本机调试端口 {port}：{detail}。"
        "这不是账号掉线或额度不足；已保留账号窗口，停止本次任务，不自动切号。"
        "请保留多开器管理页面，检查客户端是否正常运行后重新点击生成视频。"
    )


def _connect_account_browser(playwright, port, index):
    """Use a verified WS URL so Playwright cannot rediscover it through HTTP_PROXY."""
    detail = "浏览器控制连接未完成"
    for attempt in range(2):
        _check_stopped()
        probe = _devtools_probe(port, timeout=5)
        if probe["ready"]:
            try:
                browser = _account_safety_call(
                    playwright.chromium.connect_over_cdp,
                    probe["endpoint"], timeout=20000,
                )
                _log(f"账号{index}已连接本机控制端口 {port}（直连，不经过代理）")
                return browser
            except GenerationStopped:
                raise
            except Exception as error:
                detail = f"调试接口已就绪，但控制连接失败（{type(error).__name__}）"
        else:
            detail = probe["detail"]
        if attempt == 0:
            _log(f"账号{index}{detail}；正在重试同一端口 {port}，不关闭窗口、不切号")
            _check_stopped()
            time.sleep(0.5)
    _check_stopped()
    raise _local_connection_error(index, port, detail)


def _account_process_ids(port):
    """Find the local client process tree that owns one debugging port."""
    try:
        import psutil
    except Exception:
        return set()
    roots = set()
    try:
        for connection in psutil.net_connections(kind="tcp"):
            address = connection.laddr
            if (
                address
                and getattr(address, "port", None) == int(port)
                and connection.pid
            ):
                roots.add(int(connection.pid))
    except Exception:
        return set()
    result = set(roots)
    for pid in tuple(roots):
        try:
            result.update(child.pid for child in psutil.Process(pid).children(recursive=True))
        except Exception:
            pass
    return result


def _set_account_windows_visible(index, params, visible):
    """Hide/show only the top-level windows belonging to one local Dola client."""
    if os.name != "nt":
        return 0
    try:
        import ctypes
        from ctypes import wintypes
    except Exception:
        return 0

    user32 = ctypes.windll.user32
    handles = list(_hidden_account_windows.pop(int(index), set())) if visible else []

    def is_primary_window(hwnd):
        """Ignore tiny helper/tooltip windows owned by the Dola process."""
        try:
            rect = wintypes.RECT()
            if not user32.GetWindowRect(hwnd, ctypes.byref(rect)):
                return False
            width = int(rect.right - rect.left)
            height = int(rect.bottom - rect.top)
            return width >= 500 and height >= 320
        except Exception:
            return False

    pids = _account_process_ids(params["base_port"] + int(index))
    if pids:
        discovered = []
        callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        def collect(hwnd, _lparam):
            pid = wintypes.DWORD()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if int(pid.value) not in pids:
                return True
            if not is_primary_window(hwnd):
                return True
            # EnumWindows also returns hidden top-level windows. When restoring
            # visibility we must include them, otherwise a window hidden during
            # an earlier run can never be brought back after the plugin restarts.
            if not visible and not user32.IsWindowVisible(hwnd):
                return True
            length = user32.GetWindowTextLengthW(hwnd)
            if length <= 0:
                return True
            title = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, title, length + 1)
            if title.value.strip():
                discovered.append(int(hwnd))
            return True

        user32.EnumWindows(callback_type(collect), 0)
        handles.extend(hwnd for hwnd in discovered if hwnd not in handles)
        if not visible and handles:
            _hidden_account_windows[int(index)] = set(handles)

    changed = 0
    command = 5 if visible else 0  # SW_SHOW / SW_HIDE
    for hwnd in handles:
        try:
            if user32.IsWindow(hwnd) and is_primary_window(hwnd):
                user32.ShowWindow(hwnd, command)
                changed += 1
        except Exception:
            pass
    return changed


def _apply_headless_mode(index, params):
    if not params.get("headless_mode"):
        changed = _set_account_windows_visible(index, params, True)
        if changed:
            _log(f"账号{index}未启用无头运行，已恢复显示本地 Dola 窗口")
        return 0
    changed = _set_account_windows_visible(index, params, False)
    if changed:
        _log(f"账号{index}已进入无头运行，隐藏 {changed} 个本地 Dola 窗口")
    else:
        _log(f"账号{index}已启用无头运行，但暂未找到可隐藏窗口")
    return changed


def _reveal_account_for_review(index, params, reason=None):
    if _account_safety_event.is_set():
        return
    changed = _set_account_windows_visible(index, params, True)
    detail = f"：{reason}" if reason else ""
    if changed:
        _log(f"账号{index}任务异常，已恢复显示本地 Dola 窗口{detail}")
    else:
        _log(f"账号{index}任务异常，本地 Dola 窗口保持显示{detail}")
    return changed


def _manager_paths(params):
    configured_text = str(params.get("manager_root") or "").strip().strip('"')
    candidates = []
    if configured_text:
        chosen=Path(configured_text).expanduser()
        resolved=_resolve_manager_launcher(chosen)
        if resolved is None:
            raise AccountUnavailable('所填工作台路径中找不到程序，请重新选择 Anne工作台.exe；未改用其他多开器。')
        return resolved
    else:
        running = _running_anne_workbench_roots()
        if len(running) > 1:
            raise AccountUnavailable('检测到多个正在运行的 Anne 工作台，请在设置中手动选择要使用的目录。')
        if running:
            return _resolve_manager_launcher(running[0])
        try:
            import winreg

            with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\DolaAuthorizedLauncher",
            ) as key:
                remembered_root = str(
                    winreg.QueryValueEx(key, "InstallRoot")[0] or ""
                ).strip()
            if remembered_root:
                candidates.append(Path(remembered_root))
        except OSError:
            pass
    candidates.extend(
        (
            _PLUGIN_DIR / "dola_manager",
            _PLUGIN_DIR / "manager",
            _PLUGIN_DIR.parent / "dola_manager",
            _PLUGIN_DIR.parent / "Dola长登码管理器",
            _PLUGIN_DIR.parent / "Dola多开器",
            _LEGACY_MANAGER_ROOT,
        )
    )
    unique = []
    seen = set()
    for candidate in candidates:
        marker = str(candidate).lower()
        if marker in seen:
            continue
        seen.add(marker)
        unique.append(candidate)
        resolved = _resolve_manager_launcher(candidate)
        if resolved is not None:
            return resolved
    # Return the intended portable location so error messages tell the user
    # exactly where a copied manager should be placed on another computer.
    intended = unique[0] if unique else _PLUGIN_DIR / "dola_manager"
    if intended.suffix.lower() == ".exe":
        return intended.parent, intended
    manager_root = intended
    return manager_root, manager_root / "Dola长登码管理器.exe"


def _running_anne_workbench_roots():
    """Find running Anne installations only when their process matches its service descriptor."""
    if os.name != "nt":
        return []
    try:
        import psutil
    except Exception:
        return []
    roots = {}
    for process in psutil.process_iter(["name", "exe"]):
        try:
            if str(process.info.get("name") or "").casefold() != "anne工作台.exe":
                continue
            executable = str(process.info.get("exe") or "").strip()
            if not executable:
                continue
            root = Path(executable).resolve().parent
            launcher = root / "Anne工作台.exe"
            if not launcher.is_file():
                continue
            descriptor = _read_workbench_descriptor(root)
            if descriptor is None or descriptor["pid"] != int(process.pid):
                continue
            _verify_workbench_identity(descriptor)
            roots[os.path.normcase(str(root))] = root
        except Exception:
            continue
    return list(roots.values())


def _launcher_sort_key(path):
    name = path.name.lower()
    if name == "anne工作台.exe":
        return 6, 0, name
    if name == "dola长登码管理器.exe":
        return 5, 0, name
    if name == "dola长登码管理器_授权版.exe":
        return 4, 0, name
    if name == "launcher.exe":
        return 3, 0, name
    version = re.fullmatch(r"launcher[_-]?v?(\d+)\.exe", name)
    if version:
        return 2, int(version.group(1)), name
    return 1, 0, name


def _launcher_in_directory(directory):
    if not directory.is_dir():
        return None
    for preferred_name in (
        "Anne工作台.exe",
        "Dola长登码管理器.exe",
        "Dola长登码管理器_授权版.exe",
        "launcher.exe",
    ):
        preferred = directory / preferred_name
        if preferred.is_file():
            return preferred
    try:
        launchers = [
            path
            for path in directory.glob("*.exe")
            if path.is_file()
            and (
                path.name.lower().startswith("launcher")
                or path.name.lower().startswith("dola长登码管理器")
            )
        ]
    except OSError:
        launchers = []
    if not launchers:
        return None
    return max(launchers, key=_launcher_sort_key)


def _resolve_manager_launcher(candidate):
    """Accept a launcher executable, its directory, or its parent directory."""
    if candidate.is_file():
        if candidate.suffix.lower() == ".exe":
            return candidate.parent, candidate
        return None

    launcher = _launcher_in_directory(candidate)
    if launcher is not None:
        return candidate, launcher

    if not candidate.is_dir():
        return None
    try:
        nested = []
        for child in candidate.iterdir():
            if not child.is_dir():
                continue
            child_launcher = _launcher_in_directory(child)
            if child_launcher is not None:
                nested.append((child, child_launcher))
    except OSError:
        nested = []
    if not nested:
        return None
    return max(nested, key=lambda item: _launcher_sort_key(item[1]))


def _manager_uses_local_api(manager_root, launcher):
    if re.fullmatch(r"launcher[_-]?v?\d+\.exe", launcher.name, re.I):
        return True
    core = manager_root / "_internal" / "launcher_core.py"
    try:
        source = core.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return False
    return "LOCAL_PORT = 8888" in source


def _detect_manager_base_port(params):
    try:
        manager_root, launcher = _manager_paths(params)
        if launcher.is_file() and _manager_uses_local_api(manager_root, launcher):
            return 9221
    except Exception:
        pass
    return 19221


def _manager_urlopen(request, timeout):
    """Loopback traffic must not inherit a browser/VPN system proxy."""
    binding=getattr(_manager_connection_context,'binding',None)
    pinned=False
    if binding:
        url=getattr(request,'full_url',request if isinstance(request,str) else '')
        parsed=urllib.parse.urlsplit(url)
        if parsed.scheme=='http' and parsed.hostname in {'127.0.0.1','localhost'} and parsed.port==binding['descriptor']['port']:
            pinned=True
            _verify_workbench_identity(binding['descriptor'])
            if isinstance(request,urllib.request.Request):
                request.add_header('X-Anne-Instance',binding['descriptor']['instance_id'])
    if pinned:
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self,*args,**kwargs):return None
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
    else:opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    return opener.open(request, timeout=timeout)


def _manager_api_base():
    binding=getattr(_manager_connection_context,'binding',None)
    required=getattr(_manager_connection_context,'required_root',None)
    if not binding and required is not None:
        if not _bind_running_workbench(required):
            raise AccountUnavailable('所选 Anne 工作台尚未连接；未向旧多开器发送操作。')
        binding=_manager_connection_context.binding
    return binding['base'] if binding else _MANAGER_API_ROOT


def _select_manager_context(params):
    # Per-call and per-worker routing: a panel poll or another generation must
    # never redirect an existing task when the selected installation changes.
    root,launcher=_manager_paths(params)
    _manager_connection_context.required_root=Path(root).resolve() if _anne_manager_required(root,launcher,params) else None
    _manager_connection_context.binding=None


def _anne_manager_required(manager_root,launcher,params):
    return (Path(launcher).name.lower()=='anne工作台.exe' or params.get('target_platform')=='doubao'
            or (Path(manager_root)/'_internal/desktop_shell.py').is_file())


def _read_workbench_descriptor(manager_root):
    root=Path(manager_root).resolve();path=root/'Data/desktop/service.json'
    for part in (path,*path.parents):
        if part.exists() and (part.is_symlink() or getattr(part.lstat(),'st_file_attributes',0)&0x400):
            raise AccountUnavailable('工作台连接信息目录不可使用链接，请重新选择安装目录。')
    try:
        with path.open('rb') as stream:raw=stream.read(8193)
    except FileNotFoundError:return None
    if len(raw)>8192:raise AccountUnavailable('工作台连接信息异常，请重启所选工作台。')
    try:descriptor=json.loads(raw)
    except ValueError:raise AccountUnavailable('工作台连接信息未就绪，请重启所选工作台。') from None
    install_id=hashlib.sha256(os.path.normcase(str(root)).encode('utf8')).hexdigest()
    if (not isinstance(descriptor,dict) or descriptor.get('app_id')!='anne-workbench'
            or type(descriptor.get('protocol')) is not int or descriptor['protocol']!=1
            or descriptor.get('installation_id')!=install_id
            or type(descriptor.get('port')) is not int or not 1<=descriptor['port']<=65535
            or type(descriptor.get('pid')) is not int or descriptor['pid']<=0
            or not re.fullmatch(r'[0-9a-f]{32}',str(descriptor.get('instance_id','')))
            or descriptor.get('edition') not in {'development','share'}
            or not isinstance(descriptor.get('capabilities'),list)
            or not all(isinstance(c,str) for c in descriptor['capabilities'])
            or not {'dola-manager','doubao-accounts'}.issubset(descriptor['capabilities'])):
        raise AccountUnavailable('工作台身份与所选目录不匹配，请重启该目录的 Anne工作台.exe。')
    return descriptor


def _verify_workbench_identity(descriptor):
    # GET only, direct loopback, and never follow a redirect to another service.
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self,*args,**kwargs):return None
    base='http://127.0.0.1:'+str(descriptor['port'])
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
    try:
        with opener.open(base+'/desktop/identity',timeout=3) as response:
            raw=response.read(8193)
        value=json.loads(raw) if len(raw)<=8192 else None
    except (OSError,ValueError):
        raise AccountUnavailable('所选 Anne 工作台接口尚未就绪或已重启；不会连接旧多开器，请重新连接。') from None
    fields=('app_id','protocol','installation_id','instance_id','port','pid','edition')
    if (not isinstance(value,dict) or value.get('success') is not True
            or any(type(value.get(k)) is not type(descriptor[k]) or value.get(k)!=descriptor[k] for k in fields)
            or not isinstance(value.get('capabilities'),list)
            or not all(isinstance(c,str) for c in value['capabilities'])
            or not {'dola-manager','doubao-accounts'}.issubset(value['capabilities'])):
        raise AccountUnavailable('本机端口属于其他工作台或旧多开器，已阻止误连；请重新连接所选工作台。')
    return base


def _bind_running_workbench(manager_root):
    _manager_connection_context.binding=None
    descriptor=_read_workbench_descriptor(manager_root)
    if descriptor is None:return False
    try:base=_verify_workbench_identity(descriptor)
    except AccountUnavailable:return False
    _manager_connection_context.binding={'base':base,'descriptor':descriptor}
    return True


def _workbench_process_matches(descriptor,launcher):
    if not descriptor or os.name!='nt':return False
    import ctypes
    from ctypes import wintypes
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
    kernel.OpenProcess.restype=wintypes.HANDLE
    kernel.QueryFullProcessImageNameW.argtypes=[wintypes.HANDLE,wintypes.DWORD,wintypes.LPWSTR,ctypes.POINTER(wintypes.DWORD)]
    kernel.CloseHandle.argtypes=[wintypes.HANDLE]
    handle=kernel.OpenProcess(0x1000,False,descriptor['pid'])
    if not handle:return False
    try:
        size=wintypes.DWORD(32768);buffer=ctypes.create_unicode_buffer(size.value)
        return bool(kernel.QueryFullProcessImageNameW(handle,0,buffer,ctypes.byref(size)) and
                    os.path.normcase(buffer.value)==os.path.normcase(str(Path(launcher).resolve())))
    finally:kernel.CloseHandle(handle)


def _ensure_anne_workbench(manager_root,launcher,params):
    if Path(launcher).name.lower()!='anne工作台.exe':
        raise AccountUnavailable('请在工作台路径中选择 Anne工作台.exe；旧 Dola 多开器不支持豆包接口。')
    binding=getattr(_manager_connection_context,'binding',None)
    expected=hashlib.sha256(os.path.normcase(str(Path(manager_root).resolve())).encode('utf8')).hexdigest()
    if binding and binding['descriptor']['installation_id']==expected:
        _verify_workbench_identity(binding['descriptor']);return
    _manager_connection_context.required_root=Path(manager_root).resolve()
    _manager_connection_context.binding=None
    if _bind_running_workbench(manager_root):return
    _check_stopped()
    process=None
    try:
        if not _workbench_process_matches(_read_workbench_descriptor(manager_root),launcher):
            process=subprocess.Popen([str(launcher)],cwd=str(manager_root),
                stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    except OSError as error:
        if getattr(error,'winerror',None)==740:
            raise AccountUnavailable('工作台要求管理员权限，请手动打开所选 Anne工作台.exe 后重试；无需重新授权。') from error
        raise AccountUnavailable('所选 Anne 工作台启动失败，请确认路径和运行组件完整。') from error
    # The workbench itself owns a per-installation lock. A legacy listener on
    # 8888 is left untouched; only the selected Anne instance is discovered.
    deadline=time.monotonic()+params['browser_start_timeout']
    while time.monotonic()<deadline:
        _check_stopped()
        if _bind_running_workbench(manager_root):return
        if process is not None and process.poll() not in (None,0):break
        time.sleep(.5)
    raise AccountUnavailable('所选工作台连接未就绪。请完成分享版授权，或更新并重启该目录的工作台；未连接旧多开器。')


def _manager_api_request(path, method="GET", data=None, timeout=15, safety_network_check=False):
    manual_check = safety_network_check and path == "/automation_network_check" and method == "POST"
    if not manual_check and not (_generation_stop_in_progress and path.startswith("/close_cici/")):
        _check_account_safety()
    body = None
    headers = {"Accept": "application/json"}
    if data is not None:
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json"
    request = urllib.request.Request(
        f"{_manager_api_base()}{path}",
        data=body,
        headers=headers,
        method=method,
    )
    with _manager_urlopen(request, timeout=timeout) as response:
        payload = json.loads(response.read().decode("utf-8", errors="replace"))
    if not isinstance(payload, dict):
        raise RuntimeError("本地 Dola 管理器返回了无效数据")
    return payload


def _manager_api_status():
    try:
        return _manager_api_request("/cici_status", timeout=4)
    except Exception:
        return None


def _ensure_manager_api(manager_root, launcher, params):
    if _anne_manager_required(manager_root,launcher,params):
        _manager_connection_context.required_root=Path(manager_root).resolve()
    _check_stopped()
    with _manager_api_lock:
        _check_stopped()
        if _anne_manager_required(manager_root,launcher,params):
            return _ensure_anne_workbench(manager_root,launcher,params)
        _manager_connection_context.binding=None
        _manager_connection_context.required_root=None
        if _manager_api_status() is not None:
            return
        if _port_open(8888):
            # A listener already exists. Retry readiness instead of spawning a
            # second elevated executable after one transient status failure.
            recheck_deadline = time.monotonic() + 10
            while time.monotonic() < recheck_deadline:
                _check_stopped()
                if _manager_api_status() is not None:
                    return
                time.sleep(0.5)
            raise AccountUnavailable(
                "多开器端口已打开，但本机状态接口暂未正常响应；未重复启动多开器。"
                "请确认打开的是对应多开器，保留管理页面后重试。"
            )
        creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        _check_stopped()
        try:
            process = subprocess.Popen(
                [str(launcher)],
                cwd=str(manager_root),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=creation_flags,
            )
        except Exception as error:
            if getattr(error, "winerror", None) == 740:
                raise AccountUnavailable(
                    "多开器要求管理员权限，字字暂时无法自动启动。"
                    "请先手动以管理员身份打开多开器并保留管理页面，再重试；无需重新授权。"
                ) from error
            raise AccountUnavailable(f"本地 Dola 管理器启动失败：{error}") from error
        deadline = time.monotonic() + params["browser_start_timeout"]
        while time.monotonic() < deadline:
            _check_stopped()
            if _manager_api_status() is not None:
                return
            if process.poll() not in (None, 0) and not _port_open(8888):
                break
            time.sleep(0.5)
    raise AccountUnavailable("本地 Dola 管理器接口 8888 未就绪")


def _make_room_for_account(index, params):
    _check_stopped()
    running = [
        candidate
        for candidate in _account_range(params)
        if candidate != index
        and _devtools_ready(params["base_port"] + candidate)
    ]
    if len(running) < 5:
        return
    with _account_condition:
        active = set(_active_slots)
        quota_exhausted = set(_batch_insufficient_quota)
    candidates = [
        candidate
        for candidate in running
        if candidate not in active
        and (
            candidate in quota_exhausted
            or _submitted_count(candidate) > 0
        )
    ]
    if not candidates:
        raise AccountUnavailable("已有 5 个 Dola 窗口正在使用，暂时没有可安全关闭的窗口")
    candidate = candidates[0]
    _log(
        f"为继续账号轮询，关闭已完成当前轮次的账号{candidate}窗口；"
        "后续轮次需要时会自动重新打开"
    )
    if not _close_account_browser(candidate, params):
        raise AccountUnavailable(f"无法关闭已完成的账号{candidate}窗口来释放位置")
    deadline = time.monotonic() + 20
    candidate_port = params["base_port"] + candidate
    while time.monotonic() < deadline:
        _check_stopped()
        if not _port_open(candidate_port):
            return
        time.sleep(0.5)
    raise AccountUnavailable(f"账号{candidate}窗口关闭超时，无法打开账号{index}")


def _refresh_manager_accounts(params, force=False):
    """Ask the workbench to re-read its account files (accounts added/removed)."""
    global _manager_accounts_refreshed
    if _manager_accounts_refreshed and not force:
        return None
    _manager_accounts_refreshed = True
    try:
        return _manager_api_request('/desktop/accounts/refresh', method='POST', timeout=30)
    except Exception as error:
        return {'success': False, 'error': str(error)}


def _ensure_account_browser(index, params):
    _check_stopped()
    port = params["base_port"] + index
    if _devtools_ready(port):
        return port

    # Account files can change while a batch runs; have the workbench re-read
    # them before starting a window so the plugin never needs a manual 更新列表.
    _refresh_manager_accounts(params)

    _make_room_for_account(index, params)
    _check_stopped()

    manager_root, launcher = _manager_paths(params)
    if not launcher.is_file():
        raise AccountUnavailable(f"找不到 Dola 管理器：{launcher}")

    if _manager_uses_local_api(manager_root, launcher):
        _ensure_manager_api(manager_root, launcher, params)
        _check_stopped()
        with _manager_api_lock:
            _check_stopped()
            status = _manager_api_status() or {}
            running = status.get("running") or []
            if index not in running:
                _check_stopped()
                result = None
                for attempt in (1, 2):
                    try:
                        result = _manager_api_request(
                            f"/switch/{int(index)}",
                            method="POST",
                            timeout=params["browser_start_timeout"],
                        )
                    except Exception as error:
                        raise AccountUnavailable(
                            f"账号{index}启动接口调用失败：{error}"
                        ) from error
                    _check_stopped()
                    if result.get("success"):
                        break
                    error_text = str(result.get("error") or "未知错误")
                    if attempt == 1 and ("账号和目录" in error_text or "刷新账号列表" in error_text):
                        _log(f"账号{index}的窗口信息与工作台不一致，已让工作台重读账号列表后重试")
                        _refresh_manager_accounts(params, force=True)
                        continue
                    raise AccountUnavailable(f"账号{index}启动失败：{error_text}")
        deadline = time.monotonic() + params["browser_start_timeout"]
        while time.monotonic() < deadline:
            _check_stopped()
            if _devtools_ready(port):
                return port
            time.sleep(0.2)
        probe = _devtools_probe(port)
        if probe["ready"]:
            return port
        raise _local_connection_error(index, port, probe["detail"])

    creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    _check_stopped()
    try:
        process = subprocess.Popen(
            [str(launcher), "--start-account", str(index)],
            cwd=str(manager_root),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=creation_flags,
        )
    except Exception as error:
        raise AccountUnavailable(f"账号{index}浏览器启动失败：{error}") from error

    deadline = time.monotonic() + params["browser_start_timeout"]
    while time.monotonic() < deadline:
        _check_stopped()
        if _devtools_ready(port):
            # Cookie restoration may still be in progress. Return as soon as
            # DevTools is reachable and let the adaptive page-ready detector
            # below decide the exact moment when creation can safely begin.
            return port
        if process.poll() not in (None, 0) and not _port_open(port):
            break
        time.sleep(1)
    probe = _devtools_probe(port)
    if probe["ready"]:
        return port
    raise _local_connection_error(index, port, probe["detail"])


def _dola_duration_route(url):
    try:
        parsed=urllib.parse.urlsplit(str(url or ''))
        if (parsed.scheme not in {'chrome','dola'} or parsed.hostname!='dola-chat'
                or parsed.username is not None or parsed.password is not None or parsed.port is not None):
            return None
        return parsed.path or '/',parsed.query,parsed.fragment
    except (TypeError,ValueError):
        return None


def _dola_duration_page_binding(page):
    """Bind the already selected task page, never another visible client."""
    if page is None:
        raise RuntimeError('时长设置缺少原任务页面，未自动选择其他窗口')
    _check_stopped()
    original=str(page.url or '')
    if _dola_duration_route(original) is None:
        raise RuntimeError('时长设置仅支持本账号的 Dola 客户端页面')
    session=None
    try:
        session=page.context.new_cdp_session(page)
        info=session.send('Target.getTargetInfo').get('targetInfo',{})
    finally:
        if session is not None:
            try:session.detach()
            except Exception:pass
    target=info.get('targetId')
    if (not isinstance(target,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',target)
            or info.get('type')!='page' or _dola_duration_route(info.get('url'))!=_dola_duration_route(original)
            or _dola_duration_route(page.url)!=_dola_duration_route(original)):
        raise RuntimeError('原任务页面已变化，未设置时长或发送任务')
    return dict(target_id=target,page_url=original)


def _enable_manager_video_duration(params, duration, account_index, page=None):
    manager_root, launcher = _manager_paths(params)
    if not launcher.is_file():
        raise RuntimeError(f"找不到 Dola 管理器：{launcher}")
    if _manager_uses_local_api(manager_root, launcher):
        _ensure_manager_api(manager_root, launcher, params)
        binding=_dola_duration_page_binding(page)
        if type(account_index) is not int or account_index<=0:
            raise RuntimeError('时长设置缺少有效的 Dola 账号编号')
        try:
            with _manager_api_lock:
                _check_stopped()
                result = _manager_api_request(
                    f"/desktop/dola/accounts/{account_index}/video-duration",
                    method="POST",
                    data=dict(binding,duration=int(duration),port=int(params['base_port'])+account_index,
                              model=str(params.get('model') or 'Seedance 2.5'),
                              aspect_ratio=str(params.get('aspect_ratio') or ''),
                              resolution=str(params.get('resolution') or '')),
                    timeout=90,
                )
        except Exception as error:
            if isinstance(error,urllib.error.HTTPError) and error.code==404:
                raise RuntimeError('工作台缺少账号绑定时长接口，请同步更新并重启工作台；未调用旧的全窗口时长入口') from error
            raise RuntimeError(
                f"本地 Dola {duration} 秒模式开启失败：{error}"
            ) from error
        if not result.get("success"):
            raise RuntimeError(
                f"本地 Dola {duration} 秒模式开启失败：{result.get('error') or '未知错误'}"
            )
        if (result.get('account_index')!=account_index or result.get('target_id')!=binding['target_id']
                or result.get('duration')!=int(duration) or result.get('verified') is not True
                or _dola_duration_route(page.url)!=_dola_duration_route(binding['page_url'])):
            raise RuntimeError('时长设置未通过原账号/页面回读核验，已停止，未发送任务')
        page._anne_dola_duration_binding=dict(binding,account_index=account_index,duration=int(duration))
        return result
    output = Path(tempfile.gettempdir()) / (
        f"zizi_dola_duration_{os.getpid()}_{threading.get_ident()}.json"
    )
    creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        completed = subprocess.run(
            [
                str(launcher),
                "--enable-video-duration",
                str(duration),
                str(output),
                str(account_index),
            ],
            cwd=str(manager_root),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=90,
            creationflags=creation_flags,
            check=False,
        )
        if not output.is_file():
            raise RuntimeError(
                f"本地 Dola 管理器没有返回 {duration} 秒开启结果"
            )
        with output.open("r", encoding="utf-8") as file:
            result = json.load(file)
        if completed.returncode != 0 or not isinstance(result, dict) or not result.get("success"):
            detail = result.get("error") if isinstance(result, dict) else result
            raise RuntimeError(f"本地 Dola {duration} 秒模式开启失败：{detail or '未知错误'}")
        return result
    except subprocess.TimeoutExpired as error:
        raise RuntimeError(f"本地 Dola {duration} 秒模式开启超时") from error
    finally:
        try:
            output.unlink()
        except OSError:
            pass


def _account_browser_closed(index, params, check_manager_status=False):
    """Confirm both the debug port and manager's running list are clear."""
    if _port_open(params["base_port"] + index):
        return False
    if not check_manager_status:
        return True
    status = _manager_api_status()
    if status is None:
        # The account debug port is already gone. A temporarily unavailable
        # manager must not turn a completed close into a false failure.
        return True
    running = set()
    for value in status.get("running") or []:
        try:
            running.add(int(value))
        except (TypeError, ValueError):
            continue
    return int(index) not in running


def _wait_account_browser_closed(
    index, params, check_manager_status=False, timeout=10
):
    deadline = time.monotonic() + max(1, timeout)
    stable_checks = 0
    while time.monotonic() < deadline:
        if _account_browser_closed(index, params, check_manager_status):
            stable_checks += 1
            if stable_checks >= 2:
                return True
        else:
            stable_checks = 0
        time.sleep(0.4)
    return _account_browser_closed(index, params, check_manager_status)


def _close_account_browser(index, params):
    if not _generation_stop_in_progress:
        _check_account_safety()
    manager_root, launcher = _manager_paths(params)
    if not launcher.is_file():
        return False
    if _manager_uses_local_api(manager_root, launcher):
        try:
            _ensure_manager_api(manager_root, launcher, params)
        except Exception as error:
            _log(f"关闭账号{index}窗口失败：{error}")
            return False
        last_error = None
        for attempt in range(1, 4):
            try:
                with _manager_api_lock:
                    result = _manager_api_request(
                        f"/close_cici/{int(index)}", method="POST", timeout=30
                    )
                if not result.get("success"):
                    last_error = result.get("error") or "管理器未确认关闭"
            except Exception as error:
                last_error = error
            if _wait_account_browser_closed(
                index,
                params,
                check_manager_status=True,
                timeout=8 if attempt < 3 else 12,
            ):
                return True
            if attempt < 3:
                _log(f"账号{index}关闭后仍在后台，正在重试 {attempt}/3")
        _log(f"关闭账号{index}窗口失败：{last_error or '窗口和后台仍未退出'}")
        return False

    creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    last_error = None
    for attempt in range(1, 4):
        output = Path(tempfile.gettempdir()) / (
            f"zizi_dola_close_{index}_{os.getpid()}_"
            f"{threading.get_ident()}_{attempt}.json"
        )
        try:
            completed = subprocess.run(
                [str(launcher), "--close-account", str(index), str(output)],
                cwd=str(manager_root),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=60,
                creationflags=creation_flags,
                check=False,
            )
            if completed.returncode != 0:
                last_error = f"关闭程序返回代码 {completed.returncode}"
            elif output.is_file():
                with output.open("r", encoding="utf-8") as file:
                    result = json.load(file)
                if not isinstance(result, dict) or not result.get("success"):
                    last_error = (
                        result.get("error")
                        if isinstance(result, dict)
                        else "关闭程序没有返回成功结果"
                    )
        except Exception as error:
            last_error = error
        finally:
            try:
                output.unlink()
            except OSError:
                pass
        if _wait_account_browser_closed(index, params, timeout=10):
            return True
        if attempt < 3:
            _log(f"账号{index}关闭后仍在后台，正在重试 {attempt}/3")
    _log(f"关闭账号{index}窗口失败：{last_error or '窗口和后台仍未退出'}")
    return False


def _close_idle_account_after_success(index, params, progress_callback=None):
    """Close a finished account while this task still owns its scheduler slot."""
    with _account_condition:
        active = _as_int(_active_slots.get(index, 0), 0, 0)
    if active > 1:
        _log(f"账号{index}仍有其他操作，暂不关闭窗口")
        return False

    _log(f"账号{index}视频已下载完成，当前无后续操作，正在关闭窗口和后台")
    if _close_account_browser(index, params):
        _log(f"账号{index}窗口和后台已确认退出；后续需要时会自动重新打开")
        if progress_callback is not None:
            _progress(progress_callback, f"视频已下载，账号{index}窗口和后台已退出", 100)
        return True

    _log(f"账号{index}视频已下载，但窗口或后台未能完全退出")
    if progress_callback is not None:
        _progress(progress_callback, f"视频已下载，账号{index}关闭失败，已保留窗口", 100)
    return False


def _page_text(page):
    _check_account_safety()
    try:
        return page.locator("body").inner_text(timeout=5000)
    except Exception:
        return ""


def _is_local_dola_page(page):
    url = str(getattr(page, "url", "") or "").lower()
    return url.startswith(
        ("dola://dola-chat/", "chrome://dola-chat/")
    )


def _conversation_route(url):
    """Return the stable local-chat identity without transient query values."""
    try:
        parsed = urllib.parse.urlsplit(str(url or ""))
    except Exception:
        return ("", "", "", "")
    fragment = str(parsed.fragment or "").split("?", 1)[0].rstrip("/")
    return (
        str(parsed.scheme or "").lower(),
        str(parsed.netloc or "").lower(),
        str(parsed.path or "").rstrip("/"),
        fragment,
    )


def _is_expected_conversation(page, expected_url):
    if not expected_url:
        return True
    return _conversation_route(getattr(page, "url", "")) == _conversation_route(
        expected_url
    )


def _is_specific_conversation_url(url):
    """A concrete Dola chat has an id after /chat/, unlike the blank composer."""
    route = _conversation_route(url)
    path = str(route[2] or "")
    return bool(re.search(r"/chat/[^/?#]+$", path, re.I))


def _conversation_render_snapshot(page):
    """Measure real message content above the composer, excluding the sidebar."""
    try:
        value = _account_safety_call(page.evaluate, 
            r"""() => {
              const visible = el => {
                if (!el) return false;
                const r = el.getBoundingClientRect();
                const s = getComputedStyle(el);
                return r.width > 0 && r.height > 0
                  && s.display !== 'none' && s.visibility !== 'hidden'
                  && Number(s.opacity) !== 0;
              };
              // Current builds render the composer as a plain contenteditable
              // without role="textbox"; accept every known composer shape.
              const boxes = Array.from(document.querySelectorAll(
                  '[role="textbox"],[contenteditable="true"],textarea'))
                .filter(visible);
              const composer = boxes[boxes.length - 1];
              if (!composer) {
                return {hasComposer: false, textChars: 0, blocks: 0, hasMedia: false};
              }
              const cr = composer.getBoundingClientRect();
              const minimumLeft = Math.max(180, cr.left - 80);
              const maximumBottom = cr.top - 12;
              const inConversation = el => {
                if (!visible(el)) return false;
                const r = el.getBoundingClientRect();
                return r.left >= minimumLeft && r.right <= window.innerWidth + 5
                  && r.top >= 55 && r.bottom <= maximumBottom;
              };
              // Dola renders some message bodies as deeply nested div/span
              // trees. Counting only container innerText can wrongly discard
              // a visible receipt because its immediate child also has text.
              // Walk the real visible text nodes instead, so every layout
              // variant is measured without double-counting parent content.
              const texts = [];
              const walker = document.createTreeWalker(
                document.body,
                NodeFilter.SHOW_TEXT
              );
              let node;
              let visited = 0;
              while ((node = walker.nextNode()) && visited++ < 6000) {
                const text = String(node.nodeValue || '')
                  .replace(/\s+/g, ' ').trim();
                if (text.length < 2) continue;
                const parent = node.parentElement;
                if (!parent || !inConversation(parent)) continue;
                if (parent.closest('button, input, textarea, [role="textbox"]')) continue;
                texts.push(text.slice(0, 2000));
              }
              const media = Array.from(document.querySelectorAll('video, canvas, img'))
                .some(el => {
                  if (!inConversation(el)) return false;
                  const r = el.getBoundingClientRect();
                  return r.width >= 90 && r.height >= 60;
                });
              const textChars = texts.reduce(
                (total, text) => total + text.length,
                0
              );
              return {
                hasComposer: true,
                textChars,
                blocks: texts.length,
                hasMedia: media
              };
            }"""
        )
    except Exception:
        return {"has_composer": False, "text_chars": 0, "blocks": 0, "has_media": False}
    if not isinstance(value, dict):
        return {"has_composer": False, "text_chars": 0, "blocks": 0, "has_media": False}
    return {
        "has_composer": bool(value.get("hasComposer")),
        "text_chars": _as_int(value.get("textChars"), 0, 0),
        "blocks": _as_int(value.get("blocks"), 0, 0),
        "has_media": bool(value.get("hasMedia")),
    }


def _conversation_render_ready(page):
    snapshot = _conversation_render_snapshot(page)
    if bool(
        snapshot["has_composer"]
        and (
            snapshot["has_media"]
            or (snapshot["blocks"] >= 1 and snapshot["text_chars"] >= 32)
        )
    ):
        return True
    if not snapshot["has_composer"]:
        return False
    # Safety net for Dola layout variants whose visible receipt text is drawn
    # inside a geometry wrapper the DOM counter cannot measure correctly.
    # A confirmed credit cost plus wait estimate is specific to a rendered,
    # accepted video task and cannot come from an empty chat shell.
    text = _page_text(page)[-12000:]
    credit_pattern = globals().get("_SUCCESS_CREDIT")
    wait_pattern = globals().get("_SUCCESS_WAIT")
    ready_pattern = globals().get("_READY_VIDEO_TEXT")
    if ready_pattern is not None and ready_pattern.search(text):
        return True
    return bool(
        credit_pattern is not None
        and wait_pattern is not None
        and credit_pattern.search(text)
        and wait_pattern.search(text)
    )


def _restore_expected_conversation(
    page,
    expected_url,
    timeout_ms=12000,
    prompt_markers=None,
):
    if not expected_url and not prompt_markers:
        return True
    _dismiss_rename_dialog(page)
    if (
        _conversation_render_ready(page)
        and _page_has_task_prompt(_page_text(page), prompt_markers)
    ):
        return True

    # A blank Dola shell already contains the sidebar history. Only click the
    # newest (first) row once. Never inspect the second row, restart the window,
    # or repeatedly click the same title.
    attempted = []
    per_chat_wait = min(max(3.0, timeout_ms / 2000), 6.0)
    for recent_index, order_name in ((0, "第一条"),):
        _log(f"找回视频时正在点击“最近”下面{order_name}对话")
        activated = _activate_recent_conversation(page, recent_index)
        if not activated:
            attempted.append(f"{order_name}未找到")
            continue
        title = str(activated.get("title") or f"最近{order_name}")
        attempted.append(f"{order_name}“{title}”")
        _log(f"已点击最近{order_name}对话“{title}”，正在核对本次完整提示词")

        deadline = time.monotonic() + per_chat_wait
        rendered_mismatch_since = None
        while time.monotonic() < deadline:
            _dismiss_rename_dialog(page)
            if _page_is_explicitly_logged_out(page):
                raise LoginExpired("点击最近任务对话时发现账号已退出登录")
            if _conversation_render_ready(page):
                if _page_has_task_prompt(_page_text(page), prompt_markers):
                    return True
                if rendered_mismatch_since is None:
                    rendered_mismatch_since = time.monotonic()
                elif time.monotonic() - rendered_mismatch_since >= 2:
                    break
            else:
                rendered_mismatch_since = None
            page.wait_for_timeout(500)
        _log(f"最近{order_name}对话没有本次完整提示词，不再检查其他最近对话")

    detail = "、".join(attempted) or "最近第一条不可点击"
    raise RecoveryPromptMismatch(
        f"已检查{detail}，没有看到本次分镜的完整提示词"
    )


def _restore_active_conversation_route(page, expected_url, timeout_ms=55000):
    """Return an active generation to its exact chat without opening Recents."""
    if not expected_url:
        return True
    deadline = time.monotonic() + max(1.0, timeout_ms / 1000)
    last_navigation = 0.0
    while time.monotonic() < deadline:
        _check_stopped()
        _dismiss_rename_dialog(page)
        if _page_is_explicitly_logged_out(page):
            raise LoginExpired("恢复当前任务对话时发现账号已退出登录")
        if _is_expected_conversation(page, expected_url):
            if _conversation_render_ready(page):
                return True
        elif time.monotonic() - last_navigation >= 2:
            last_navigation = time.monotonic()
            try:
                _account_safety_call(page.evaluate, 
                    """url => {
                      setTimeout(() => { window.location.href = url; }, 0);
                      return true;
                    }""",
                    expected_url,
                )
            except Exception:
                pass
        page.wait_for_timeout(500)
    return bool(
        _is_expected_conversation(page, expected_url)
        and _conversation_render_ready(page)
    )


def _refresh_expected_conversation(
    page,
    expected_url,
    settle_ms=2500,
    prompt_markers=None,
):
    """Refresh only the active task chat so an empty result card can hydrate."""
    if expected_url and not _is_expected_conversation(page, expected_url):
        if not _restore_active_conversation_route(
            page, expected_url, timeout_ms=12000
        ):
            return False
    try:
        _account_safety_call(page.reload, wait_until="domcontentloaded", timeout=30000)
    except Exception:
        # The local dola:// client can report ERR_ABORTED even after accepting
        # the refresh. Judge by the final route instead of the exception text.
        pass
    page.wait_for_timeout(max(500, int(settle_ms)))
    if expected_url and not _is_expected_conversation(page, expected_url):
        return _restore_active_conversation_route(
            page, expected_url, timeout_ms=55000
        )
    if _page_is_explicitly_logged_out(page):
        raise LoginExpired("刷新任务对话时发现账号已退出登录")
    if expected_url and not _conversation_render_ready(page):
        return _restore_active_conversation_route(
            page, expected_url, timeout_ms=55000
        )
    # The exact chat id was captured immediately after this submission. During
    # normal waiting it is the authoritative identity; Dola may collapse or
    # delay rendering the original prompt after a refresh, so do not start an
    # old-chat search or fail the task based on transient prompt text.
    return _conversation_render_ready(page) if expected_url else True


def _find_local_dola_page(browser_context):
    candidates = [page for page in browser_context.pages if _is_local_dola_page(page)]
    if not candidates:
        raise AccountUnavailable("本地 Dola 已启动，但没有找到 dola-chat 窗口")
    # Prefer the full chat page over small launcher/overlay views.
    candidates.sort(
        key=lambda page: (
            "/chat/" in str(page.url),
            len(_page_text(page)),
        ),
        reverse=True,
    )
    return candidates[0]


def _has_login_button(page):
    pattern = re.compile(
        r"^(Log In|Sign In|登录|登录/注册|立即登录|扫码登录|Continue with Google)$",
        re.I,
    )
    for role in ("button", "link"):
        try:
            locator = page.get_by_role(role, name=pattern)
            if any(locator.nth(index).is_visible() for index in range(locator.count())):
                return True
        except Exception:
            pass
    try:
        locator = page.locator('button, [role="button"], a')
        for index in range(locator.count()):
            item = locator.nth(index)
            if not item.is_visible():
                continue
            label = re.sub(r"\s+", " ", (item.inner_text() or "").strip())
            if pattern.fullmatch(label):
                return True
    except Exception:
        pass
    return False


def _page_is_explicitly_logged_out(page):
    if _has_login_button(page):
        return True
    has_visible_textbox = _visible_composer(page) is not None
    return _classify_page_access(
        _page_text(page), has_textbox=has_visible_textbox
    ) == "logged_out"


def _dola_composer_script():
    return r'''() => {
      const visible=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);
        return e.isConnected&&r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'&&
          !e.closest('[hidden],[inert],[aria-hidden="true"],[data-message-id]');};
      const candidates=[...document.querySelectorAll('textarea,[contenteditable="true"],[role="textbox"]')]
        .filter(e=>visible(e)&&!e.disabled&&!e.readOnly&&e.getAttribute('aria-disabled')!=='true'&&
          e.getAttribute('aria-readonly')!=='true'&&(e.tagName==='TEXTAREA'||e.isContentEditable));
      const editors=candidates.filter(e=>!candidates.some(other=>other!==e&&other.contains(e)));
      if(editors.length!==1)return null;
      const editor=editors[0],root=editor.closest('[data-chat-input],[data-testid="chat_input"],.guidance-input-surface');
      return root&&visible(root)?{editor,root}:null;
    }'''


def _dola_composer_node(page,part):
    if part not in {'editor','root'}:raise ValueError('Invalid composer part')
    return _account_safety_call(page.evaluate_handle,
        '() => {const c=('+_dola_composer_script()+')();return c?c.'+part+':null;}').as_element()


def _visible_composer(page):
    # Dola builds vary between role=textbox, textarea and contenteditable.
    # Search only editor-like nodes and exclude historical message editors;
    # never treat the sidebar search field as the task composer.
    try:return _dola_composer_node(page,'editor')
    except GenerationStopped:raise
    except Exception:return None


def _wait_for_dola_startup(page, params, progress_callback=None, account_index=None):
    """Start as soon as a logged-in composer is visibly stable."""
    timeout_seconds = params["startup_ready_timeout"]
    login_confirm_seconds = params["login_confirm_seconds"]
    started_at = time.monotonic()
    deadline = started_at + timeout_seconds
    logged_out_since = None
    ready_since = None
    login_button_hits = 0

    try:
        _account_safety_call(page.bring_to_front)
        page.wait_for_load_state("domcontentloaded", timeout=15000)
    except Exception:
        pass

    while time.monotonic() < deadline:
        _check_stopped()
        now = time.monotonic()
        elapsed = now - started_at
        text = _page_text(page)
        composer = _visible_composer(page)
        access = _classify_page_access(text, has_textbox=composer is not None)
        if access == "region":
            raise RegionUnavailable("Dola 返回“当前地区不可用”，请更换全局/TUN VPN节点")

        if _page_is_explicitly_logged_out(page):
            ready_since = None
            if logged_out_since is None:
                logged_out_since = now
            logged_out_for = now - logged_out_since
            # A rendered Log In button is unambiguous: two samples (~1 s) are enough, so the
            # scheduler rotates to the next account instead of idling for half a minute.
            if _has_login_button(page):
                login_button_hits += 1
                if login_button_hits >= 2:
                    raise LoginExpired(
                        f"本地 Dola 已显示登录按钮（{int(logged_out_for)} 秒），立即切换账号"
                    )
            else:
                login_button_hits = 0
            if logged_out_for >= login_confirm_seconds:
                raise LoginExpired(
                    f"本地 Dola 登录界面持续 {int(logged_out_for)} 秒，确认账号未登录"
                )
        else:
            logged_out_since = None
            login_button_hits = 0
            if composer is not None:
                if ready_since is None:
                    ready_since = now
                # Two consecutive observations are enough. Do not impose the
                # old fixed 20-second wait after the account is already usable.
                if now - ready_since >= 1:
                    _log(
                        f"账号{account_index}已识别登录成功且输入框可用，立即开始创作"
                    )
                    _account_login_confirmed(account_index)
                    _check_stopped()
                    return composer
            else:
                ready_since = None

        _progress(
            progress_callback,
            f"账号{account_index}等待 Dola 登录与输入框就绪 "
            f"({int(elapsed)}/{timeout_seconds}秒)",
            3,
        )
        page.wait_for_timeout(1000)

    # A late or unstable login screen is still ambiguous. Preserve the window
    # instead of rotating away from an account that may recover on a slow network.
    if _page_is_explicitly_logged_out(page) and logged_out_since is not None:
        logged_out_for = time.monotonic() - logged_out_since
        if logged_out_for >= login_confirm_seconds:
            raise LoginExpired(
                f"本地 Dola 登录界面持续 {int(logged_out_for)} 秒，确认账号未登录"
            )
    raise UiNotReady(
        f"Dola 在 {timeout_seconds} 秒内没有完成稳定加载；已保留当前窗口，不切换账号"
    )


def _raise_ui_not_ready(page, message):
    if _page_is_explicitly_logged_out(page):
        raise LoginExpired("本地 Dola 明确显示未登录")
    raise UiNotReady(message)


def _classify_page_access(text, has_textbox=False):
    normalized = re.sub(r"\s+", " ", str(text or "")).strip().lower()
    if any(
        token in normalized
        for token in (
            "not available in this country or region",
            "current region is not available",
            "service is not available in your region",
            "service is unavailable in your country or region",
            "not supported in your region",
            "region is currently unsupported",
            "当前地区不可用",
            "此国家或地区不可用",
        )
    ):
        return "region"
    # The local Dola login modal is rendered over a still-visible message box.
    # These modal-only phrases are therefore decisive even when a textbox exists.
    strong_login_tokens = (
        "log in to unlock more features",
        "continue with google",
        "continue with apple",
        "continue with email",
        "scan qr code with dola app",
        "qr code expired",
        "please log in to continue",
        "please sign in to continue",
        "登录以解锁更多功能",
        "使用 google 继续",
        "使用 dola app 扫描二维码",
    )
    if any(token in normalized for token in strong_login_tokens):
        return "logged_out"
    login_tokens = (
        "log in",
        "sign in",
        "sign up",
        "login with",
        "phone number login",
        "scan to log in",
        "手机号登录",
        "登录/注册",
        "立即登录",
        "扫码登录",
    )
    if not has_textbox and any(token in normalized for token in login_tokens):
        return "logged_out"
    return "ok"


def _wait_for_composer(page, timeout_ms=30000):
    deadline = time.monotonic() + timeout_ms / 1000
    while time.monotonic() < deadline:
        if _page_is_explicitly_logged_out(page):
            raise LoginExpired("本地 Dola 账号已退出登录")
        composer = _visible_composer(page)
        if composer is not None:
            return composer
        access = _classify_page_access(_page_text(page), False)
        if access == "region":
            raise RegionUnavailable("Dola 返回“当前地区不可用”，请更换全局/TUN VPN节点")
        if access == "logged_out":
            raise LoginExpired("账号登录已失效")
        page.wait_for_timeout(750)
    access = _classify_page_access(_page_text(page), False)
    if access == "region":
        raise RegionUnavailable("Dola 返回“当前地区不可用”，请更换全局/TUN VPN节点")
    if access == "logged_out":
        raise LoginExpired("账号登录已失效")
    raise UiNotReady("Dola 页面暂未出现输入框")


_NEW_CHAT_NAME = re.compile(
    r"^(?:New Chat|新对话|新的对话)(?:\s+Ctrl\s+(?:Shift\s+)?[NK])?$",
    re.I,
)
_EMPTY_CHAT_TEXT = re.compile(
    r"How can I assist you today\?|What can I help you with|"
    r"How can I help you(?: today)?|How may I help you|"
    r"What would you like to (?:do|create|explore)|"
    r"今天.{0,12}(?:帮|帮助|聊|做|创作).{0,12}(?:你|您)|"
    r"(?:你|您).{0,12}(?:今天|现在).{0,12}(?:想|需要).{0,12}(?:聊|做|创作)|"
    r"有什么(?:可以|能).{0,12}(?:帮|帮助)(?:你|您)|"
    r"我能(?:为你|为您|帮你|帮您).{0,16}|想聊点什么|"
    r"(?:嗨|你好)[！!，,\s]*(?:我是|这里是)?\s*Dola",
    re.I,
)
_READY_VIDEO_TEXT = re.compile(
    r"Your video is ready\.?|The video is ready\.?|"
    r"Your video has been (?:successfully )?generated\.?|"
    r"The video has finished generating\.?|"
    r"Video generation (?:is|has been) (?:complete|completed|successful)\.?|"
    r"(?:你|您)的视频(?:已经|已)?生成好(?:了)?|"
    r"(?:你|您)的视频(?:已经|已)?(?:生成完成|准备好)|"
    r"视频(?:已经|已)生成(?:完成|成功)",
    re.I,
)
_CONTENT_RESTRICTION_FAILED_TEXT = re.compile(
    # Dola can append this terminal reply long after a valid queue receipt,
    # without saying whether credits were refunded.
    r"(?:生成的|本次生成的|生成结果中的)\s*(?:音频|音乐|声音|视频|内容)"
    r"[\s\S]{0,50}(?:版权限制|版权保护|版权问题|版权风险|版权侵权)"
    r"[\s\S]{0,80}(?:"
    r"(?:更换|修改|调整|替换)[\s\S]{0,35}(?:输入|内容|素材|提示词)"
    r"[\s\S]{0,25}(?:重试|重新生成|再次尝试)|无法(?:生成|返回))|"
    r"(?:the\s+)?(?:generated|resulting)\s+(?:audio|music|soundtrack|video|content)"
    r"[\s\S]{0,80}(?:copyright(?:ed)?\s+(?:restrictions?|protection|issues?|"
    r"concerns?|infringement|content|material)|copyright)"
    r"[\s\S]{0,100}(?:"
    r"(?:change|modify|replace|adjust|revise)[\s\S]{0,50}"
    r"(?:input|content|prompt|material)[\s\S]{0,50}(?:try\s+again|retry|regenerate)|"
    r"(?:cannot|can't|unable\s+to)\s+(?:generate|return|provide))",
    re.I,
)
_EXPLICIT_GENERATION_FAILED_TEXT = re.compile(
    r"视频生成失败|生成视频失败|无法生成(?:该|此|这个)?视频|"
    r"\bvideo\s+generation\s+(?:has\s+)?failed\b|"
    r"\b(?:failed\s+to|(?:i\s+)?(?:cannot|can['’]t|could\s+not|"
    r"couldn['’]t|unable\s+to))\s+(?:generate|create)\s+"
    r"(?:(?:a|the|this|your)\s+)?video\b|"
    r"\b(?:something\s+went\s+wrong|an?\s+(?:unexpected\s+)?error\s+occurred)"
    r"[.!\s]{0,10}(?:please\s+)?(?:try\s+again|retry)\b",
    re.I,
)
_VIDEO_GENERATION_FAILED_TEXT = re.compile(
    _CONTENT_RESTRICTION_FAILED_TEXT.pattern + r"|" +
    _EXPLICIT_GENERATION_FAILED_TEXT.pattern + r"|生成额度未扣除|"
    r"(?:no\s+)?(?:video\s+generation\s+)?(?:credits?|quota|points?)"
    r"(?:\s+(?:were|was|have\s+been|has\s+been))?\s+"
    r"(?:not\s+(?:used|deducted|charged|consumed)|refunded|returned)|"
    r"生成内容中疑似包含[\s\S]{0,50}(?:侵权|违规)[\s\S]{0,120}"
    r"无法返回该内容[\s\S]{0,160}生成额度未扣除|"
    r"视频生成失败\s*[,，。；;:]?\s*生成额度未扣除|"
    r"视频生成失败\s*[,，。；;:]?\s*(?:额度|点数|积分).{0,12}(?:未扣除|已退回)|"
    r"video generation (?:has )?failed.{0,80}(?:credit|quota|point).{0,30}"
    r"(?:not (?:used|deducted)|refunded)|"
    r"failed to (?:generate|create) (?:the |this |your )?video.{0,80}"
    r"(?:credit|quota|point).{0,30}(?:not (?:used|deducted)|refunded)|"
    r"(?:i\s+)?(?:can(?:not|'t)|could(?:\s+not|n't)|unable\s+to)\s+"
    r"(?:generate|create)(?:\s+(?:the|this|your))?\s+video[\s\S]{0,120}"
    # Dola also states a plain number: "You have 0 video credits left today".
    r"(?:you\s+have\s+)?0\s+(?:video\s+)?credits?\s+(?:left|remaining)|"
    r"(?:you\s+)?still\s+have\s+0\s+(?:points?|video\s+credits?)|"
    r"(?:no|zero)\s+(?:video\s+)?credits?\s+"
    r"(?:were\s+|was\s+)?(?:used|deducted|charged|consumed)|"
    r"(?:suspected|may)[\s\S]{0,80}(?:copyright|policy|violat)"
    r"[\s\S]{0,160}(?:cannot|unable)[\s\S]{0,80}(?:return|provide)"
    r"[\s\S]{0,160}(?:credit|quota|point)[\s\S]{0,40}"
    r"(?:not (?:used|deducted)|refunded)",
    re.I,
)


def _video_element_count(page):
    """How many playable <video> nodes the page currently has."""
    try:
        return int(_account_safety_call(
            page.evaluate, "() => document.querySelectorAll('video').length") or 0)
    except Exception:
        return 0


def _ready_video_marker_count(text):
    return len(_READY_VIDEO_TEXT.findall(str(text or "")))


def _video_generation_failed_marker_count(text):
    return len(_VIDEO_GENERATION_FAILED_TEXT.findall(str(text or "")))


def _video_generation_failure_message(text):
    restriction = _CONTENT_RESTRICTION_FAILED_TEXT.search(str(text or ""))
    if restriction:
        detail = re.sub(r"\s+", " ", restriction.group(0)).strip()
        return f"Dola 明确提示生成的音频/视频涉及版权限制，需要更换输入内容后重试。原文：{detail}"
    if re.search(r"[A-Za-z]{3,}", str(text or "")):
        return "英文状态识别：Dola 明确表示无法生成视频或生成失败"
    return "Dola 已明确显示本次生成失败或被拦截"


def _normalized_task_text(value):
    return re.sub(r"\s+", " ", str(value or "")).strip()


def _task_prompt_markers(prompt, marker_length=36):
    """Keep the complete normalized prompt as the recovery identity."""
    source = _normalized_task_text(prompt)
    if not source:
        return ()
    return (source,)


def _page_has_task_prompt(text, markers):
    markers = tuple(item for item in (markers or ()) if item)
    if not markers:
        return True
    source = _normalized_task_text(text)
    return all(item in source for item in markers)


def _require_task_prompt(page, markers, timeout_ms=6000):
    """Require the complete submitted prompt before trusting a restored chat."""
    markers = tuple(item for item in (markers or ()) if item)
    if not markers:
        return True
    deadline = time.monotonic() + max(0, int(timeout_ms or 0)) / 1000
    while True:
        _dismiss_rename_dialog(page)
        if _page_has_task_prompt(_page_text(page), markers):
            return True
        if _page_is_explicitly_logged_out(page):
            raise LoginExpired("核对原任务提示词时发现账号已退出登录")
        if time.monotonic() >= deadline:
            raise RecoveryPromptMismatch(
                "已打开对话，但没有看到本次分镜的完整提示词"
            )
        page.wait_for_timeout(500)


_RECENT_VIDEO_CHAT_NAME = re.compile(
    r"^(?:视频生成(?:指令|对话|任务)?|AI\s*Video\s*Generation|"
    r"Video\s*Generation(?:\s*Instructions?)?)$",
    re.I,
)


def _dismiss_rename_dialog(page):
    """Close Dola's rename dialog if a recent-chat title was hit accidentally."""
    _check_stopped()
    try:
        return bool(
            _account_safety_call(page.evaluate, 
                r"""() => {
                  const visible = el => {
                    if (!el) return false;
                    const r = el.getBoundingClientRect();
                    const s = getComputedStyle(el);
                    return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none';
                  };
                  const title = Array.from(document.querySelectorAll('*')).find(el => {
                    const text = (el.textContent || '').trim();
                    return visible(el) && /^(?:编辑对话名称|Edit conversation name)$/i.test(text);
                  });
                  if (!title) return false;
                  let dialog = title.closest('[role="dialog"]');
                  if (!dialog) {
                    let node = title.parentElement;
                    while (node && node !== document.body) {
                      const text = node.innerText || '';
                      const r = node.getBoundingClientRect();
                      if (r.width > 250 && r.width < 1100 && /(?:取消|Cancel)/i.test(text) && /(?:确定|Confirm)/i.test(text)) {
                        dialog = node;
                        break;
                      }
                      node = node.parentElement;
                    }
                  }
                  if (!dialog) return false;
                  const buttons = Array.from(dialog.querySelectorAll('button,[role="button"]'));
                  const cancel = buttons.find(el => /^(?:取消|Cancel)$/i.test((el.innerText || el.textContent || '').trim()));
                  const close = buttons.find(el => /^(?:关闭|Close|×|x)$/i.test(((el.getAttribute('aria-label') || '') + ' ' + (el.innerText || el.textContent || '')).trim()));
                  const target = cancel || close;
                  if (!target) return false;
                  target.click();
                  return true;
                }"""
            )
        )
    except Exception:
        return False


def _recent_conversation_route_choices(page):
    """Return recent-chat routes without clicking their editable title text."""
    result = []
    seen = set()
    current_url = str(getattr(page, "url", "") or "")
    try:
        anchors = page.locator('a[href*="/chat/"]')
        count = min(anchors.count(), 100)
    except Exception:
        return result
    for number in range(count):
        try:
            item = anchors.nth(number)
            if not item.is_visible():
                continue
            href = str(item.get_attribute("href") or "").strip()
            if not href:
                continue
            href_parts = urllib.parse.urlsplit(href)
            current_parts = urllib.parse.urlsplit(current_url)
            if href_parts.scheme:
                target_url = href
            elif href.startswith("/") and current_parts.scheme:
                target_url = urllib.parse.urlunsplit(
                    (
                        current_parts.scheme,
                        current_parts.netloc,
                        href_parts.path,
                        href_parts.query,
                        href_parts.fragment,
                    )
                )
            elif current_parts.scheme:
                base_path = current_parts.path.rsplit("/", 1)[0]
                target_url = urllib.parse.urlunsplit(
                    (
                        current_parts.scheme,
                        current_parts.netloc,
                        f"{base_path}/{href_parts.path}",
                        href_parts.query,
                        href_parts.fragment,
                    )
                )
            else:
                target_url = urllib.parse.urljoin(current_url, href)
            if target_url in seen:
                continue
            seen.add(target_url)
            text = str(item.inner_text() or "").strip()
            box = item.bounding_box() or {}
            priority = 0 if _RECENT_VIDEO_CHAT_NAME.search(text) else 1
            result.append((priority, float(box.get("y", 999999)), target_url))
        except Exception:
            continue
    return sorted(result, key=lambda value: (value[0], value[1]))


def _activate_recent_conversation(page, recent_index=0):
    """Click one conversation by its order directly below the Recent label."""
    _dismiss_rename_dialog(page)

    recent_labels = []
    try:
        labels = page.get_by_text(re.compile(r"^(?:最近|Recent)$", re.I))
        count = min(labels.count(), 20)
    except Exception:
        return None
    for number in range(count):
        try:
            label = labels.nth(number)
            if not label.is_visible():
                continue
            box = label.bounding_box() or {}
            if not box:
                continue
            recent_labels.append(
                (
                    float(box.get("x", 999999)),
                    float(box.get("y", 999999)),
                    box,
                )
            )
        except Exception:
            continue
    if not recent_labels:
        return None
    # Prefer the left-most/top-most Recent heading. It belongs to the sidebar,
    # not any matching text that might appear inside the conversation body.
    _label_x, _label_y, label_box = min(
        recent_labels, key=lambda value: (value[0], value[1])
    )
    label_bottom = float(label_box.get("y", 0)) + float(label_box.get("height", 0))
    label_left = float(label_box.get("x", 0))

    choices = []
    # The Dola builds seen in the wild use either an anchor, a role button, or a
    # focusable div for a recent conversation. Inspect all three shapes, then
    # choose strictly by vertical position: the first row below "最近".
    selectors = (
        'a[href*="/chat/"]',
        'a, button, [role="button"], [role="link"], [tabindex]',
    )
    seen = set()
    for selector_priority, selector in enumerate(selectors):
        try:
            locator = page.locator(selector)
            count = min(locator.count(), 300)
        except Exception:
            continue
        for number in range(count):
            try:
                item = locator.nth(number)
                if not item.is_visible():
                    continue
                box = item.bounding_box() or {}
                if not box:
                    continue
                x = float(box.get("x", 999999))
                y = float(box.get("y", 999999))
                width = float(box.get("width", 0))
                height = float(box.get("height", 0))
                if y < label_bottom - 2 or y > label_bottom + 650:
                    continue
                if x > label_left + 520 or width < 70 or height < 22 or height > 110:
                    continue
                text = _normalized_task_text(item.inner_text())
                if not text or len(text) > 180:
                    continue
                if re.search(
                    r"^(?:最近|Recent|新对话|New chat|主对话|Main chat|"
                    r"编辑|重命名|Edit|Rename|取消|Cancel|确定|Confirm)$",
                    text,
                    re.I,
                ):
                    continue
                signature = (
                    round(x, 1),
                    round(y, 1),
                    round(width, 1),
                    round(height, 1),
                    text,
                )
                if signature in seen:
                    continue
                seen.add(signature)
                choices.append(
                    (y, selector_priority, x, number, item, text, box)
                )
            except Exception:
                continue
        if choices:
            # An actual chat anchor is safer than a broad focusable fallback.
            break
    if not choices:
        return None
    ordered = []
    for choice in sorted(choices, key=lambda value: value[:4]):
        if any(abs(choice[0] - existing[0]) < 4 for existing in ordered):
            continue
        ordered.append(choice)
    position = max(0, int(recent_index or 0))
    if position >= len(ordered):
        return None
    chosen = ordered[position]
    item = chosen[4]
    title = chosen[5]
    box = chosen[6]
    try:
        # A Playwright pointer click is trusted by the Electron renderer. Click
        # once in the left/middle of the row, away from its right-side menu.
        width = float(box.get("width", 0))
        height = float(box.get("height", 0))
        click_x = min(max(30.0, width * 0.35), max(30.0, width - 25.0))
        click_y = max(10.0, height / 2)
        _account_safety_call(item.click, 
            position={"x": click_x, "y": click_y},
            timeout=5000,
        )
        page.wait_for_timeout(700)
        _dismiss_rename_dialog(page)
        return {
            "title": title,
            "url": str(getattr(page, "url", "") or ""),
        }
    except Exception:
        _dismiss_rename_dialog(page)
        return None


def _open_matching_recent_conversation(page, markers, timeout_ms=18000):
    """Open a recent video chat only after its full task prompt is verified."""
    _dismiss_rename_dialog(page)
    current_url = str(getattr(page, "url", "") or "")
    if (
        _is_specific_conversation_url(current_url)
        and _page_has_task_prompt(_page_text(page), markers)
    ):
        return current_url

    overall_deadline = time.monotonic() + timeout_ms / 1000
    # The newest matching recent conversation is normally the first visible
    # video-generation route. Navigate by its href instead of clicking the
    # editable title, which Dola also uses to open its rename dialog.
    for _priority, _y, target_url in _recent_conversation_route_choices(page):
        if time.monotonic() >= overall_deadline:
            break
        try:
            _account_safety_call(page.evaluate, 
                """url => {
                  setTimeout(() => { window.location.href = url; }, 0);
                  return true;
                }""",
                target_url,
            )
        except Exception:
            continue
        _dismiss_rename_dialog(page)
        deadline = min(overall_deadline, time.monotonic() + 4)
        while time.monotonic() < deadline:
            if _page_is_explicitly_logged_out(page):
                raise LoginExpired("打开最近任务对话时发现账号已退出登录")
            current_url = str(getattr(page, "url", "") or "")
            if (
                _is_specific_conversation_url(current_url)
                and _page_has_task_prompt(_page_text(page), markers)
            ):
                _log("已自动打开并核对本次任务的最近生成对话")
                return current_url
            page.wait_for_timeout(500)
    return None


def _capture_submission_chat_url(page, markers, timeout_ms=12000):
    """Lock the route that received this submission; never search old chats."""
    deadline = time.monotonic() + timeout_ms / 1000
    current_url = str(getattr(page, "url", "") or "")
    while time.monotonic() < deadline:
        current_url = str(getattr(page, "url", "") or "")
        if _is_specific_conversation_url(current_url):
            if isinstance(getattr(page,'_anne_dola_upload_scope',None),dict):
                _record_dola_sent_chat(page)
            return current_url
        page.wait_for_timeout(500)
    # The success reply is already visible on this page. Searching recent
    # chats is unsafe because an older retry can contain the same prompt and an
    # unrelated completed video.
    return current_url


def _visible_topmost(locator):
    choices = []
    try:
        count = locator.count()
    except Exception:
        return None
    for number in range(count):
        try:
            item = locator.nth(number)
            if not item.is_visible():
                continue
            box = item.bounding_box() or {}
            choices.append((float(box.get("y", 999999)), number, item))
        except Exception:
            continue
    if not choices:
        return None
    return min(choices, key=lambda value: (value[0], value[1]))[2]


def _visible_topmost_matches(page, pattern, limit=6):
    """Visible elements whose own text matches, ordered top-most first."""
    script = (
        "(() => {"
        "  const re = new RegExp(" + json.dumps(pattern.pattern) + ", " + json.dumps(pattern.flags) + ");"
        "  const visible = e => {const r = e.getBoundingClientRect();"
        "    return r.width > 0 && r.height > 0 && getComputedStyle(e).visibility !== 'hidden'};"
        "  const out = [];"
        "  for (const e of document.querySelectorAll('button,[role=\"button\"],a,div,span')) {"
        "    if (!visible(e)) continue;"
        "    const text = (e.innerText || '').replace(/\\s+/g, ' ').trim();"
        "    if (!text || text.length > 32 || !re.test(text)) continue;"
        "    if ([...e.children].some(c => re.test((c.innerText || '').replace(/\\s+/g, ' ').trim()))) continue;"
        "    const r = e.getBoundingClientRect();"
        "    out.push({x: r.left + r.width / 2, y: r.top + r.height / 2});"
        "  }"
        "  out.sort((a, b) => a.y - b.y || a.x - b.x);"
        "  return out.slice(0, " + str(int(limit)) + ");"
        "})()"
    )
    try:
        rows = _account_safety_call(page.evaluate, script)
    except Exception:
        return []
    return [_PointHandle(row) for row in (rows or []) if isinstance(row, dict)]


class _PointHandle:
    """Minimal element stand-in so the caller can click a measured point."""

    def __init__(self, point):
        self._point = point

    def bounding_box(self):
        return {'x': self._point['x'], 'y': self._point['y'], 'width': 0.0, 'height': 0.0}


def _click_new_chat(page):
    """Click the fixed sidebar entry, not a similarly named recent chat."""
    _dismiss_rename_dialog(page)
    for role in ("button", "link"):
        try:
            item = _visible_topmost(page.get_by_role(role, name=_NEW_CHAT_NAME))
            if item is not None:
                _account_safety_call(item.click)
                _dismiss_rename_dialog(page)
                return True
        except Exception:
            pass
    # The sidebar entry is sometimes a plain DIV that get_by_role cannot see, and this
    # build labels it "New Chat Ctrl N". Click the topmost visible match instead: the
    # sidebar's New Chat sits above Pinned and Recents, so a recent conversation with
    # the same title can never be picked.
    try:
        for handle in _visible_topmost_matches(page, _NEW_CHAT_NAME):
            box = handle.bounding_box()
            if not box:
                continue
            _account_safety_call(page.mouse.click, box['x'] + box['width'] / 2,
                                 box['y'] + box['height'] / 2)
            _dismiss_rename_dialog(page)
            return True
    except Exception:
        pass
    return False


def _wait_for_empty_chat(
    page,
    previous_url="",
    previous_ready_markers=0,
    timeout_ms=22000,
):
    deadline = time.monotonic() + timeout_ms / 1000
    while time.monotonic() < deadline:
        _dismiss_rename_dialog(page)
        if _page_is_explicitly_logged_out(page):
            raise LoginExpired("本地 Dola 账号已退出登录")
        text = _page_text(page)
        current_url = str(getattr(page, "url", "") or "")
        composer = _visible_composer(page)
        # A fresh Dola conversation shows its greeting or resets its route. The
        # full page text also contains recent-chat titles, so allow unchanged
        # sidebar ready markers instead of demanding an absolute count of zero.
        route_changed = bool(previous_url and current_url != previous_url)
        ready_markers_cleared = (
            _ready_video_marker_count(text) <= int(previous_ready_markers or 0)
        )
        # This client's fresh blank chat keeps the /chat route and shows no greeting, so
        # "no message nodes at all" is the dependable signal that the chat is empty.
        no_messages = bool(_account_safety_call(
            page.evaluate,
            "() => !document.querySelector('[data-message-id]')"))
        if (
            composer is not None
            and _dola_composer_controls_state(page).get("ready")
            and ready_markers_cleared
            and (_EMPTY_CHAT_TEXT.search(text) or route_changed or no_messages)
        ):
            return composer
        page.wait_for_timeout(750)
    raise UiNotReady("无法确认已进入新的空白对话，已停止提交以避免误抓旧视频")


_MAIN_CHAT_NAME = re.compile(r"^(?:Main chat|主对话|主聊天)$", re.I)


def _click_sidebar_text(page, pattern):
    """Click one unambiguous sidebar label, excluding the editor and chat history."""
    script = r'''() => {
      const re = new RegExp(PATTERN, 'i'), c=(COMPOSER)();
      const visible=e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0&&
        getComputedStyle(e).visibility!=='hidden'&&!e.closest('[hidden],[inert],[aria-hidden="true"]');};
      const matches=[...document.querySelectorAll('button,a,[role="button"],span,div')].filter(e=>{
        if(!visible(e)||e.closest('[data-message-id],[role="dialog"],[data-testid="chat_input"],[data-chat-input],.guidance-input-surface'))return false;
        if(!re.test((e.innerText||'').trim())||[...e.children].some(n=>re.test((n.innerText||'').trim())))return false;
        const r=e.getBoundingClientRect();
        return c ? r.right<=c.root.getBoundingClientRect().left : !!e.closest('aside,nav,[role="navigation"],[data-testid="conversation-list-v2-item"]');
      });
      if(matches.length!==1)return null;
      const r=matches[0].getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2};
    }'''.replace('PATTERN', json.dumps(pattern.pattern)).replace('COMPOSER', _dola_composer_script())
    try:
        point = _account_safety_call(page.evaluate, script)
        if not isinstance(point, dict):
            return False
        _account_safety_call(page.mouse.click, point['x'], point['y'])
        return True
    except GenerationStopped:
        raise
    except Exception:
        return False


def _dola_composer_controls_state(page):
    """Read only the unique current composer; never mistake history for controls."""
    script = r'''() => {
      const c = (COMPOSER)();
      const visible = e => {const r=e.getBoundingClientRect(),s=getComputedStyle(e);
        return e.isConnected && r.width>0 && r.height>0 && s.display!=='none' &&
          s.visibility!=='hidden' && !e.closest('[hidden],[inert],[aria-hidden="true"],[data-message-id]');};
      if(!c) return {ready:false,draft:[...document.querySelectorAll('textarea,[contenteditable="true"]')].some(visible)};
      const text=(c.editor.value||c.editor.innerText||'').trim();
      const attached=[...c.root.querySelectorAll('input[type="file"]')].some(e=>e.files?.length) ||
        [...c.root.querySelectorAll('[data-testid="attachment-image-card"],[data-kind="image"]')].some(visible);
      const controls=[...c.root.querySelectorAll('[data-input-engine-actionbar-control-key]')]
        .some(e=>visible(e)&&/model|mode|video|image/i.test(e.getAttribute('data-input-engine-actionbar-control-key')||''));
      const entries=[...c.root.querySelectorAll('button,[role="button"],span,div')]
        .some(e=>visible(e)&&/^(Create Videos?|Video Generation|视频生成|生成视频|More|更多)$/i.test((e.innerText||'').trim()));
      return {ready:controls||entries,draft:!!text||!!attached};
    }'''.replace('COMPOSER', _dola_composer_script())
    try:
        state = _account_safety_call(page.evaluate, script)
        return state if isinstance(state, dict) else {'ready': False, 'draft': True}
    except GenerationStopped:
        raise
    except Exception:
        return {'ready': False, 'draft': True}


def _wake_composer(page, attempts=1):
    """Recover missing toolbar once via Main chat -> New Chat, before filling a task."""
    _check_stopped()
    if _page_is_explicitly_logged_out(page):
        raise LoginExpired("本地 Dola 账号已退出登录")
    state = _dola_composer_controls_state(page)
    if state.get('ready'):
        return True
    if state.get('draft'):
        raise UiNotReady("输入控件未就绪且已有草稿或附件，已保留内容并停止切换对话")
    _log("输入框下方控件未出现，先点 Main chat，再点 New Chat 恢复")
    if not _click_sidebar_text(page, _MAIN_CHAT_NAME):
        return False
    page.wait_for_timeout(1600)
    _check_stopped()
    if _page_is_explicitly_logged_out(page):
        raise LoginExpired("本地 Dola 账号已退出登录")
    if not _click_new_chat(page):
        return False
    deadline = time.monotonic() + 8
    while time.monotonic() < deadline:
        _check_stopped()
        if _page_is_explicitly_logged_out(page):
            raise LoginExpired("本地 Dola 账号已退出登录")
        if _dola_composer_controls_state(page).get('ready'):
            _log("新对话输入框和控件已就绪，继续任务")
            return True
        page.wait_for_timeout(400)
    return False


def _open_clean_chat(page, max_attempts=4):
    if not _is_local_dola_page(page):
        raise AccountUnavailable("连接到的不是本地 Dola 聊天窗口")
    if _page_is_explicitly_logged_out(page):
        raise LoginExpired("本地 Dola 账号已退出登录")
    _account_safety_call(page.bring_to_front)
    # Recover the toolbar as well as the editor before preparing a task.
    if not _wake_composer(page):
        raise UiNotReady("输入控件恢复失败，已停止提交，请检查 Main chat 和 New Chat 入口")
    if isinstance(getattr(page,'_anne_dola_upload_scope',None),dict):
        _record_dola_sent_chat(page)
    attempts = max(1, int(max_attempts or 1))
    last_error = None
    for attempt in range(1, attempts + 1):
        previous_url = str(getattr(page, "url", "") or "")
        previous_ready_markers = _ready_video_marker_count(_page_text(page))
        if not _click_new_chat(page):
            # Keep the documented shortcut only as a compatibility fallback.
            # The next step still has to prove that an empty chat was opened.
            _account_safety_call(page.keyboard.press, "Control+Shift+K")
        page.wait_for_timeout(1800)
        try:
            composer = _wait_for_empty_chat(
                page,
                previous_url,
                previous_ready_markers,
                22000,
            )
        except UiNotReady as error:
            last_error = error
            if _page_is_explicitly_logged_out(page):
                raise LoginExpired("本地 Dola 账号已退出登录") from error
            if attempt < attempts:
                _log(
                    f"第 {attempt}/{attempts} 次未能确认空白对话，"
                    "正在重新点击新建对话"
                )
                _wake_composer(page)
                continue
            break
        _confirm_dola_fresh_upload_chat(page)
        _log(f"已确认进入新的空白对话（第 {attempt}/{attempts} 次）")
        return composer
    raise UiNotReady(
        f"连续 {attempts} 次无法确认已进入新的空白对话，"
        "已停止提交以避免误抓旧视频"
    ) from last_error


def _video_model_ready(page):
    try:
        return page.locator('[data-input-engine-actionbar-control-key="video-model"]').count() > 0
    except Exception:
        return False


def _wait_video_model(page, timeout_ms):
    """Poll for the video composer; return as soon as it exists."""
    deadline = time.monotonic() + max(0.2, timeout_ms / 1000.0)
    while time.monotonic() < deadline:
        if _video_model_ready(page):
            return True
        page.wait_for_timeout(150)
    return _video_model_ready(page)


def _wait_sidebar(page, timeout_ms=15000):
    """Wait for the sidebar to render after a client start or a page reload."""
    deadline = time.monotonic() + timeout_ms / 1000.0
    pattern = re.compile(r"^(?:New Chat|新对话|AI Creation|AI创作)$", re.I)
    while time.monotonic() < deadline:
        try:
            if page.get_by_text(pattern).count():
                return True
        except Exception:
            pass
        page.wait_for_timeout(250)
    return False


def _composer_has_draft(page):
    """True when the composer already holds text or attachments (a retry keeps it)."""
    try:
        return bool(page.evaluate(
            '() => {const e=document.querySelector(\'[contenteditable="true"],textarea\');'
            'const text=((e?.innerText||e?.value||"")+"").trim();'
            'const cards=document.querySelectorAll('
            '\'[data-testid="attachment-image-card"],[data-kind="image"]\').length;'
            'return text.length>0||cards>0}'))
    except Exception:
        return False


def _click_element(page, item):
    """Real mouse click at the element's centre.

    Playwright's click() first demands that the element is visible, enabled and
    stable; the client's sidebar rows report "not enabled", which made every
    entry attempt time out. A coordinate click is still a real mouse event (the
    Video tab needs one) and skips those checks.
    """
    try:
        box = item.bounding_box()
    except Exception:
        return False
    if not box or not box.get('width') or not box.get('height'):
        return False
    page.mouse.click(box['x'] + box['width'] / 2, box['y'] + box['height'] / 2)
    return True


def _video_mode_active(page):
    """True when the composer already shows video mode (its ratio chip only exists there)."""
    try:
        # Video mode shows the model chip as "Seedance 2.0 Fast" together with a duration
        # chip such as "10s"; normal mode shows only "Fast" and no duration chip.
        return bool(_account_safety_call(
            page.evaluate,
            "() => {const t = document.body.innerText || '';"
            " return /Seedance|Dreamina/.test(t) && /\\b\\d+\\s*s\\b/.test(t);}"))
    except Exception:
        return False


def _enter_video_creation(page, force_navigation=False):
    """Click the composer's video entry once. It is a toggle, so it is never retried.

    A second click leaves video mode again, which is why the earlier retry loop produced
    an on/off/on flicker. If the first click does not take effect the caller fails the
    task rather than clicking again.
    """
    if not force_navigation and (_video_model_ready(page) or _video_mode_active(page)):
        return True
    chip_pattern = re.compile(r"^Create Videos?$", re.I)
    more_pattern = re.compile(r"^More$|^更多$", re.I)

    def wait_for_chip(pattern, timeout_ms=10000):
        deadline = time.monotonic() + timeout_ms / 1000
        while time.monotonic() < deadline:
            try:
                chip = page.get_by_text(pattern).last
                if chip is not None and _account_safety_call(chip.is_visible):
                    return chip
            except Exception:
                pass
            page.wait_for_timeout(250)
        return None

    _wait_sidebar(page)
    clicked = False
    chip = wait_for_chip(chip_pattern)
    if chip is not None and _account_safety_call(_click_element, page, chip):
        clicked = True
        _log("已点击输入框里的 Create Videos（开关只点一次）")
    else:
        # This build may keep the entry inside the composer's "More" overflow menu.
        overflow = wait_for_chip(more_pattern, 5000)
        if overflow is not None and _account_safety_call(_click_element, page, overflow):
            _log("Create Videos 不在外面，已点开 More 菜单")
            page.wait_for_timeout(700)
            inner = wait_for_chip(chip_pattern, 5000)
            if inner is not None and _account_safety_call(_click_element, page, inner):
                clicked = True
                _log("已点击 More 菜单里的 Create Videos（开关只点一次）")

    # Observe only: no second click, whatever happens.
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline:
        if _video_model_ready(page) or _video_mode_active(page):
            return True
        page.wait_for_timeout(400)
    if clicked:
        # The mode probe cannot recognise every build, so a missing confirmation is not a
        # failure: the upload and submit steps will report it precisely if the click
        # really did not take effect. Never click again - this button is a toggle.
        _log("已点过 Create Videos（开关只点一次），继续后续步骤")
    return bool(clicked)


def _click_video_mode(page):
    pattern = re.compile(r"^(?:Create Videos?|Video Generation|视频生成|生成视频)$", re.I)
    if _enter_video_creation(page):
        return True
    for role in ("button",):
        locator = page.get_by_role(role, name=pattern)
        try:
            count = locator.count()
            for number in range(count - 1, -1, -1):
                item = locator.nth(number)
                if item.is_visible():
                    _account_safety_call(item.click)
                    page.wait_for_timeout(1000)
                    return True
        except Exception:
            pass
    text_locator = page.get_by_text(pattern)
    try:
        for number in range(text_locator.count() - 1, -1, -1):
            item = text_locator.nth(number)
            if item.is_visible():
                _account_safety_call(item.click)
                page.wait_for_timeout(1000)
                return True
    except Exception:
        pass
    return False


def _wait_for_video_mode(page, params, progress_callback=None, account_index=None):
    """Wait on the current page for video capability without reloading it."""
    timeout_seconds = params["video_entry_timeout"]
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        if _page_is_explicitly_logged_out(page):
            raise LoginExpired("本地 Dola 账号已退出登录")
        access = _classify_page_access(
            _page_text(page), has_textbox=_visible_composer(page) is not None
        )
        if access == "region":
            raise RegionUnavailable("Dola 返回“当前地区不可用”，请更换全局/TUN VPN节点")
        try:
            cookie_button = _visible_topmost(
                page.get_by_role(
                    "button",
                    name=re.compile(r"^(?:OK|Accept(?: All)?|Allow|Got it)$", re.I),
                )
            )
            if cookie_button is not None:
                _account_safety_call(cookie_button.click)
                page.wait_for_timeout(300)
        except Exception:
            pass
        if _click_video_mode(page):
            return True
        _progress(
            progress_callback,
            f"账号{account_index}已登录，等待“视频生成”入口出现",
            5,
        )
        page.wait_for_timeout(1000)
    raise AccountUnavailable(
        f"账号{account_index}已登录，但等待 {timeout_seconds} 秒仍没有“视频生成”入口"
    )


def _click_matching_button(page, patterns):
    buttons = page.locator("button")
    try:
        count = buttons.count()
    except Exception:
        count = 0
    for number in range(count - 1, -1, -1):
        try:
            item = buttons.nth(number)
            if not item.is_visible():
                continue
            label = re.sub(r"\s+", " ", (item.inner_text() or "").strip())
            if any(pattern.search(label) for pattern in patterns):
                _account_safety_call(item.click)
                page.wait_for_timeout(450)
                return True
        except Exception:
            continue
    return False


def _click_visible_option(page, patterns):
    locator = page.locator(
        '[role="option"], [role="menuitem"], [role="menuitemradio"], '
        '[data-radix-collection-item], button, [role="button"]'
    )
    try:
        count = locator.count()
    except Exception:
        count = 0
    for number in range(count - 1, -1, -1):
        try:
            item = locator.nth(number)
            if not item.is_visible():
                continue
            label = re.sub(r"\s+", " ", (item.inner_text() or "").strip())
            if label and any(pattern.search(label) for pattern in patterns):
                _account_safety_call(item.click)
                page.wait_for_timeout(450)
                return True
        except Exception:
            continue
    return False


def _dola_actionbar_context(page):
    """Bind to one current composer, never history/sidebar/media toolbars."""
    _check_stopped()
    root = _account_safety_call(page.evaluate_handle, r"""() => {
      const visible = e => !!e && e.getClientRects().length &&
        getComputedStyle(e).visibility !== 'hidden' && !e.closest('[aria-hidden="true"]');
      const editors = [...document.querySelectorAll('[role="textbox"],.tiptap[contenteditable="true"],textarea[data-testid="chat_input_input"]')]
        .filter(e => visible(e) && !e.closest('[data-message-id]'));
      const roots = [...new Set(editors.map(e => e.closest('[data-chat-input],[data-testid="chat_input"]') ||
        e.closest('.guidance-input-surface')).filter(visible))];
      return roots.length === 1 ? roots[0] : null;
    }""").as_element()
    if root is None:
        raise UiNotReady("无法唯一确认当前 Dola 输入区，未点击参数菜单")
    return dict(page=page, root=root, url=page.url, overflow=None, control=None)


def _dola_actionbar_guard(context):
    _check_stopped()
    page, root = context['page'], context['root']
    if page.url != context['url'] or not _account_safety_call(root.evaluate, r"""root => {
      const visible = e => !!e && e.isConnected && e.getClientRects().length &&
        getComputedStyle(e).visibility !== 'hidden' && !e.closest('[aria-hidden="true"]');
      const roots = [...new Set([...document.querySelectorAll('[role="textbox"],.tiptap[contenteditable="true"],textarea[data-testid="chat_input_input"]')]
        .filter(e => visible(e) && !e.closest('[data-message-id]'))
        .map(e => e.closest('[data-chat-input],[data-testid="chat_input"]') || e.closest('.guidance-input-surface')).filter(visible))];
      return visible(root) && roots.length === 1 && roots[0] === root;
    }"""):
        raise UiNotReady("Dola 输入区或对话已变化，已停止参数选择")


def _dola_actionbar_menu(context, trigger):
    """Radix links its portals by aria-controls/aria-labelledby in Dola 2.29.10."""
    if trigger is None or not _account_safety_call(trigger.evaluate, 'e => e.isConnected'):
        return None
    if not _account_safety_call(trigger.evaluate,
            'e => !e.id || [...document.querySelectorAll("[id]")].filter(n => n.id === e.id).length === 1'):
        raise UiNotReady("Dola 参数菜单标识重复，未继续点击")
    matches = []
    for menu in context['page'].query_selector_all(
            '[role="menu"],[role="listbox"],[data-radix-menu-content],'
            '[data-slot="dropdown-menu-content"],[data-slot="dropdown-menu-sub-content"]'):
        if not menu.is_visible() or menu.get_attribute('data-state') == 'closed':
            continue
        if _account_safety_call(menu.evaluate, r"""(menu, trigger) => {
          const controlled = (trigger.getAttribute('aria-controls') || '').split(/\s+/);
          const labels = (menu.getAttribute('aria-labelledby') || '').split(/\s+/);
          const slot = menu.getAttribute('data-slot') || '';
          const radix = menu.hasAttribute('data-radix-menu-content');
          return (!!menu.id && controlled.includes(menu.id)) ||
            (!!trigger.id && labels.includes(trigger.id)) ||
            (radix && !!trigger.id && (menu.getAttribute('data-labelledby') || '').split(/\s+/).includes(trigger.id)) ||
            (slot === 'dropdown-menu-sub-content' && !!trigger.id && labels.includes(trigger.id));
        }""", trigger):
            matches.append(menu)
    if len(matches) > 1:
        raise UiNotReady("Dola 参数菜单关联不唯一，未继续点击")
    return matches[0] if matches else None


def _dola_actionbar_click(context, item, force=False):
    _dola_actionbar_guard(context)
    # Blueprint uses data-disabled="false"; Radix uses an empty boolean
    # data-disabled attribute. Only the literal false value enables it.
    data_disabled = item.get_attribute('data-disabled')
    if (not item.is_visible() or not item.is_enabled() or
            item.get_attribute('aria-disabled') == 'true' or
            (data_disabled is not None and data_disabled != 'false')):
        raise UiNotReady("Dola 参数控件不可用，未继续点击")
    # An uncertain click is never retried. In particular do not swallow a stop.
    _account_safety_call(item.click, timeout=1500, force=force)
    _dola_actionbar_guard(context)


def _dola_actionbar_overflow(context, phase):
    root = context['root']
    candidates = []
    selectors = (
        '[style*="--chat-input-tool-button-overflow-list-gap"] [data-slot="dropdown-menu-trigger"][aria-haspopup="menu"]',
        '[data-slot="dropdown-menu-trigger"][aria-haspopup="menu"],'
        '[data-slot="dropdown-menu-sub-trigger"][aria-haspopup="menu"],'
        'button[aria-haspopup="menu"], [role="button"][aria-haspopup="menu"]',
        # Dola 2.29.x briefly renders the ellipsis as a direct child of its
        # Blueprint overflow list before Radix adds aria-haspopup/controls.
        # Bind only that list's direct button; never broaden this to every
        # unlabeled button in the composer (the upload button is outside it).
        '[style*="--chat-input-tool-button-overflow-list-gap"] > button,'
        '[style*="--chat-input-tool-button-overflow-list-gap"] > [role="button"]',
    )
    all_items=[]
    for selector in selectors:
        all_items.extend(root.query_selector_all(selector))
    seen=[]
    for item in all_items:
        if any(_account_safety_call(item.evaluate, '(e, other) => e === other', old) for old in seen):
            continue
        seen.append(item)
        if item.is_visible() and _account_safety_call(item.evaluate, r"""e => {
          const list = e.closest('[style*="--chat-input-tool-button-overflow-list-gap"]');
          const label = (e.innerText || e.getAttribute('aria-label') || e.getAttribute('title') || '').trim();
          const cls = String(e.className || '');
          const inOverflowList = !!list && [...list.classList].some(c => c.startsWith('overflow-list-'));
          const looksLikeOverflow = /^(?:\.{3}|…)$/i.test(label) || /more|overflow/i.test(cls);
          return (inOverflowList || looksLikeOverflow) &&
            !e.closest('[class*="overflow-visible-item-"]') &&
            !e.hasAttribute('data-input-engine-actionbar-control-key') &&
            !e.closest('[role="menu"]') && (!label || /^(?:\.{3}|…|More|更多)$/i.test(label)) && !!e.querySelector('svg');
        }"""):
            candidates.append(item)
    if len(candidates) > 1:
        raise UiNotReady("Dola 输入区有多个折叠菜单，未猜测点击")
    if not candidates:
        return None
    trigger = candidates[0]
    context['overflow'] = trigger
    menu = _dola_actionbar_menu(context, trigger)
    if menu is not None:
        return menu
    clicked_key = 'overflow_clicked_' + phase
    menu_clicked_key = 'overflow_menu_clicked_' + phase
    bootstrap_key = 'overflow_bootstrap_' + phase
    semantic = (trigger.get_attribute('aria-haspopup') == 'menu' and
                trigger.get_attribute('data-slot') in ('dropdown-menu-trigger','dropdown-menu-sub-trigger'))
    if context.get(clicked_key):
        bootstrap = context.get(bootstrap_key)
        if not bootstrap or not semantic or context.get(menu_clicked_key):
            return None
        # The first plain Blueprint ellipsis only mounts the real Radix
        # trigger, CLOSED. Reacquire that trigger in the SAME original list,
        # then open it once. Never retry an already-clicked Radix trigger or
        # follow a replacement composer/list, even if labels look identical.
        if not _account_safety_call(bootstrap['list'].evaluate, r'''(list, values) => {
          const [root, old, current] = values;
          return list.isConnected && root.contains(list) &&
            current.closest('[style*="--chat-input-tool-button-overflow-list-gap"]') === list &&
            (!old.isConnected || current === old || current.contains(old));
        }''', [root, bootstrap['trigger'], trigger]):
            raise UiNotReady('Dola 折叠按钮在初始化时换了输入区，未继续点击')
    elif not semantic:
        container = _account_safety_call(trigger.evaluate_handle,
            '''e => e.closest('[style*="--chat-input-tool-button-overflow-list-gap"]')''').as_element()
        if container is None:
            return None
        context[bootstrap_key] = dict(list=container, trigger=trigger)
    context[clicked_key] = True
    if semantic:
        context[menu_clicked_key] = True
    if menu is None:
        _dola_actionbar_click(context, trigger)
        context['page'].wait_for_timeout(200)
        menu = _dola_actionbar_menu(context, trigger)
    return menu


def _dola_actionbar_control(context, control_key, patterns, overflow_menu=None):
    aliases = {'video-ratio': 'image-creation-chat-input-video-ration-button',
               'video-model': 'image-creation-chat-input-video-model-button',
               'video-duration': 'image-creation-chat-input-video-duration-button'}
    if control_key not in aliases:
        raise UiNotReady("未知 Dola 参数控件，未继续点击")
    regions = [(context['root'], False)] + ([(overflow_menu, True)] if overflow_menu is not None else [])
    keyed, fallback = [], []
    for region, in_menu in regions:
        nodes = region.query_selector_all('button,[role="button"],[role="menuitem"],div[aria-haspopup="menu"],[aria-haspopup="menu"],[data-slot="dropdown-menu-trigger"],[data-slot="dropdown-menu-sub-trigger"],[data-input-engine-actionbar-control-key]')
        for item in nodes:
            if not item.is_visible() or not _account_safety_call(item.evaluate,
                    '(e, region) => (e.closest("[role=menu],[role=listbox]") || null) === region',
                    region if in_menu else None):
                continue
            if item.get_attribute('data-input-engine-actionbar-control-key') == control_key or item.get_attribute('data-testid') == aliases[control_key]:
                keyed.append(item)
            elif in_menu or _account_safety_call(item.evaluate, 'e => !!e.closest("[style*=--chat-input-tool-button-overflow-list-gap]")'):
                label = re.sub(r'\s+', ' ', (item.inner_text() or '').strip())
                if any(pattern.search(label) for pattern in patterns):
                    fallback.append(item)
    matches = []
    for item in keyed or fallback:
        # Older layouts can put the semantic key on a wrapper while the
        # actual Radix trigger carries the testid. They are one control.
        trigger = _account_safety_call(item.evaluate_handle, r"""e => {
          const selector = '[aria-haspopup="menu"][aria-controls],[data-slot="dropdown-menu-trigger"],[data-slot="dropdown-menu-sub-trigger"]';
          const ancestor = e.closest(selector);
          if (ancestor) return ancestor;
          const children = [...e.querySelectorAll(selector)].filter(n => n.getClientRects().length);
          if (children.length) return children.length === 1 ? children[0] : null;
          return e.closest('button,[role="button"],[role="menuitem"]');
        }""").as_element()
        if trigger is None:
            raise UiNotReady("Dola 参数控件与菜单关联不明确，未继续点击")
        if not any(_account_safety_call(trigger.evaluate, '(e, other) => e === other', other) for other in matches):
            matches.append(trigger)
    if len(matches) > 1:
        raise UiNotReady("Dola 参数控件不唯一，未猜测选择")
    return matches[0] if matches else None


_ACTIONBAR_TEXT_PATTERNS = {
    # Keep this strict: a broad match would make the "already in video mode" check succeed
    # before the video button is clicked, which skips entering video mode altogether.
    'video-model': re.compile(r"Seedance|Dreamina|\bModel\b|模型", re.I),
    'video-duration': re.compile(r"^\d+\s*s$|^\d+\s*秒$|时长|[Dd]uration", re.I),
    'video-ratio': re.compile(r"^\d+\s*[:：]\s*\d+$|比例|[Rr]atio|自动|[Aa]uto", re.I),
}


def _click_actionbar_control_by_text(page, control_key):
    """Compatibility path for client builds without the actionbar control attributes.

    The 2.29 client renders the model / duration / ratio entries as plain text nodes
    ("Seedance 2.0 Fast", "10s", "16:9") with no data-input-engine-actionbar-control-key
    and no testid, so they are located by text and clicked at their own centre.
    """
    pattern = _ACTIONBAR_TEXT_PATTERNS.get(control_key)
    if pattern is None:
        return False
    for handle in _visible_topmost_matches(page, pattern, limit=8):
        box = handle.bounding_box()
        if not box:
            continue
        _account_safety_call(page.mouse.click, box['x'], box['y'])
        page.wait_for_timeout(250)
        return True
    return False


def _click_actionbar_control(page, control_key, patterns, timeout_ms=15000):
    context = _dola_actionbar_context(page)
    context.update(control_key=control_key, patterns=patterns)
    page._anne_dola_actionbar = context
    deadline = time.monotonic() + timeout_ms / 1000
    while time.monotonic() < deadline:
        _dola_actionbar_guard(context)
        control = _dola_actionbar_control(context, control_key, patterns)
        if control is None:
            menu = _dola_actionbar_overflow(context, 'select')
            control = _dola_actionbar_control(context, control_key, patterns, menu)
        if control is not None:
            context['control'] = control
            if _dola_actionbar_menu(context, control) is None:
                context['control_opened'] = True
                _dola_actionbar_click(context, control)
            return True
        page.wait_for_timeout(150)
    # No attribute-based control anywhere: this build labels them with plain text.
    return _click_actionbar_control_by_text(page, control_key)


def _dola_actionbar_options(context, menu, patterns, expected_value=None, allow_ratio_token=False):
    matches, exact = [], []
    for item in menu.query_selector_all('[role="option"],[role="menuitem"],[role="menuitemradio"],button,[data-testid="dropdown-menu-item"]'):
        if not item.is_visible() or not _account_safety_call(item.evaluate,
                '(e, menu) => e.closest("[role=menu],[role=listbox]") === menu', menu):
            continue
        if item.get_attribute('aria-haspopup') == 'menu':
            continue
        label = re.sub(r'\s+', ' ', (item.inner_text() or '').strip())
        if expected_value is not None:
            compact_label = re.sub(r'\s+', '', label).replace('：', ':')
            # Dola 2.29.10 sometimes decorates the option with a short
            # orientation label (e.g. “横屏 · 16:9”). Keep exact ratio-token
            # matching and still reject duplicate/ambiguous candidates.
            matched = compact_label == expected_value
            if (not matched and allow_ratio_token and
                    not re.match(r'^(?:not|不是|非)(?:\b|\d|[:：])', compact_label, re.I)):
                matched = bool(re.search(r'(?<!\d)'+re.escape(expected_value)+r'(?!\d)', compact_label))
        else:
            matched = bool(label) and any(pattern.search(label) for pattern in patterns)
            if matched and any(pattern.fullmatch(label) for pattern in patterns):
                exact.append(item)
        if matched:
            matches.append(item)
    matches = exact or matches
    if len(matches) > 1:
        raise UiNotReady("Dola 参数选项不唯一，未猜测选择")
    return matches


def _wait_visible_option(page, patterns, timeout_ms=10000, expected_value=None, allow_ratio_token=False):
    deadline = time.monotonic() + timeout_ms / 1000
    context = getattr(page, '_anne_dola_actionbar', None)
    if context is None:
        return False  # Never guess an unbound option elsewhere in the conversation.
    while time.monotonic() < deadline:
        _check_stopped()
        _dola_actionbar_guard(context)
        menu = _dola_actionbar_menu(context, context['control'])
        if menu is not None:
            matches = _dola_actionbar_options(context, menu, patterns, expected_value, allow_ratio_token)
            if matches:
                try:
                    _account_safety_call(matches[0].scroll_into_view_if_needed, timeout=1500)
                    page.wait_for_timeout(350)
                except Exception:
                    pass
                _dola_actionbar_click(context, matches[0], force=True)
                return True
        page.wait_for_timeout(150)
    return False


def _dola_actionbar_close_owned_menus(context):
    """Dismiss only this parameter's owned Radix chain, never arbitrary UI."""
    def owned_menu():
        if context.get('control_opened') or context.get('ratio_verify_opened'):
            menu = _dola_actionbar_menu(context, context['control'])
            if menu is not None:
                return menu
        if context.get('overflow_clicked_select') or context.get('overflow_clicked_verify'):
            return _dola_actionbar_menu(context, context['overflow'])
        return None
    for _ in range(2):
        _dola_actionbar_guard(context)
        menu = owned_menu()
        if menu is None:
            return True
        _account_safety_call(menu.focus)
        _dola_actionbar_guard(context)
        if not menu.is_visible() or not _account_safety_call(menu.evaluate,
                'e => e === document.activeElement || e.contains(document.activeElement)'):
            return False
        _account_safety_call(menu.press, 'Escape', timeout=1500)
        _dola_actionbar_guard(context)
        context['page'].wait_for_timeout(120)
    return owned_menu() is None


def _select_actionbar_ratio(page, aspect, timeout_ms=15000):
    """Select once, then verify current UI selection; never treat click as proof."""
    aspect = re.sub(r'\s+', '', aspect).replace('：', ':')
    if not re.fullmatch(r'\d+:\d+', aspect):
        raise UiNotReady("Dola 比例参数格式无效")
    patterns = (re.compile(r'^(?:比例|画幅|aspect(?: ratio)?|ratio)\s*.*', re.I),
                re.compile(r'^(?:auto|自动|\d+\s*[:：]\s*\d+)\s*[·•|/]\s*\d+\s*(?:s|秒)$', re.I),
                re.compile(r'^\d+\s*[:：]\s*\d+$'))
    if not _click_actionbar_control(page, 'video-ratio', patterns, timeout_ms):
        return False
    if not _wait_visible_option(page, (), timeout_ms, expected_value=aspect, allow_ratio_token=True):
        return False
    context = page._anne_dola_actionbar
    deadline = time.monotonic() + min(timeout_ms, 5000) / 1000
    verified_since = None
    while time.monotonic() < deadline:
        _dola_actionbar_guard(context)
        control = _dola_actionbar_control(context, 'video-ratio', patterns)
        if control is None:
            # Radix normally closes the overflow portal after selection. At
            # most one readback-only reopen; do not select the option again.
            menu = _dola_actionbar_overflow(context, 'verify')
            control = _dola_actionbar_control(context, 'video-ratio', patterns, menu)
        verified = False
        if control is not None:
            context['control'] = control
            label = (control.inner_text() or '').replace('：', ':')
            values = [re.sub(r'\s+', '', value) for value in re.findall(r'(?<!\d)\d+\s*:\s*\d+(?!\d)', label)]
            attr_values = [re.sub(r'\s+', '', str(control.get_attribute(name) or ''))
                           for name in ('data-value','data-selected-value','aria-label','title')]
            verified = values == [aspect] or aspect in attr_values
            if not verified:
                menu = _dola_actionbar_menu(context, control)
                if menu is None and not context.get('ratio_verify_opened'):
                    context['ratio_verify_opened'] = True
                    _dola_actionbar_click(context, control)
                elif menu is not None:
                    matches = _dola_actionbar_options(context, menu, (), aspect, allow_ratio_token=True)
                    selected = menu.query_selector_all(
                        '[data-selected="true"],[aria-checked="true"],[aria-selected="true"],'
                        '[data-checked="true"],[role="menuitemradio"][data-state="checked"],'
                        '[class*="border-dbx-text-highlight"],[class*="text-dbx-text-highlight"]')
                    selected = [item for item in selected if item.is_visible()]
                    verified = len(selected) == 1 and len(matches) == 1 and _account_safety_call(
                        selected[0].evaluate, '(e, candidate) => e === candidate', matches[0])
        if verified:
            if verified_since is None:
                verified_since = time.monotonic()
            elif time.monotonic() - verified_since >= .15:
                closed = _dola_actionbar_close_owned_menus(context)
                custom_panel = False
                try:
                    custom_panel = bool(_account_safety_call(
                        page.locator('[data-slot="dropdown-menu-content"],[data-slot="dropdown-menu-sub-content"],[data-radix-menu-content]').count
                    ))
                except Exception:
                    pass
                if not closed and custom_panel:
                    try:
                        _account_safety_call(page.keyboard.press, 'Escape', timeout=1500)
                        page.wait_for_timeout(120)
                    except Exception:
                        pass
                    closed = _dola_actionbar_close_owned_menus(context)
                return closed
        else:
            verified_since = None
        page.wait_for_timeout(100)
    return False


def _step_pause(page, params):
    _check_stopped()
    page.wait_for_timeout(params["step_delay_seconds"] * 1000)
    _check_stopped()


def _model_option_patterns(model):
    normalized = re.sub(r"\s+", " ", str(model or "").strip())
    patterns = [re.compile(re.escape(normalized), re.I)]
    compact = normalized.lower().replace("．", ".")
    if compact == "seedance 2.5":
        patterns.append(re.compile(r"(?:Seedance\s*)?2[.．]5\b", re.I))
    elif compact == "seedance 2.0 fast":
        patterns.append(
            re.compile(r"(?:Seedance\s*)?2[.．]0\s*Fast\b", re.I)
        )
    return tuple(patterns)


def _response_model_patterns(model):
    """Model names used in Dola receipts can be shorter than UI option names."""
    patterns = list(_model_option_patterns(model))
    normalized = re.sub(r"\s+", " ", str(model or "").strip()).lower()
    if normalized == "seedance 2.0 fast":
        # Dola currently calls Seedance 2.0 Fast simply "Seedance 2.0 model"
        # in some English queue receipts. Keep UI option matching strict and
        # allow this alias only while interpreting the returned receipt.
        patterns.append(re.compile(r"(?:Seedance\s*)?2[.．]0\s*(?:model)?\b", re.I))
    return tuple(patterns)


def _is_hidden_seedance_25(model):
    """True when the requested model is Seedance 2.5 (removed from the picker)."""
    compact = re.sub(r"\s+", " ", str(model or "").strip()).lower().replace("．", ".")
    return compact in {"seedance 2.5", "2.5", "seedance2.5"}


def _select_video_settings(page, params, account_index):
    model = str(params.get("model") or "Seedance 2.5").strip()
    duration = str(params.get("duration") or "30").strip().lower().rstrip("s秒 ")
    aspect = str(params.get("aspect_ratio") or "16:9").strip()
    # Dola's backend answers every resolution request with the same 720p rendition
    # (measured: the returned MP4 header says 1280x720 even when 1080P is asked for),
    # so no resolution is forced here.

    # No page control is clicked: model, duration and ratio are all written into the
    # outgoing ability_param by the manager's request hook. Clicking the model entry on
    # this build matched near the "..." overflow and opened a menu, and the ratio chip
    # must never be toggled either.
    _log(f"模型 {model} / {duration}秒 / {aspect} 全部由提交参数强制写入，不点击任何页面参数控件")
    _step_pause(page, params)

    if duration in {"15", "30"}:
        # The manager injects the selected duration into the current creation
        # request. Re-entering video mode for a retry can rebuild that request
        # with Dola's normal 15-second default, so this must run before every
        # submission instead of being cached once per page.
        _enable_manager_video_duration(params, int(duration), account_index, page=page)
        page.wait_for_timeout(500)
    else:
        duration_control = (
            re.compile(r"^\d+\s*s$", re.I),
            re.compile(r"^\d+\s*秒$", re.I),
            re.compile(r"^时长\s*.*", re.I),
            re.compile(r"^duration\s*.*", re.I),
        )
        if not _click_actionbar_control(page, "video-duration", duration_control):
            _raise_ui_not_ready(page, "本地 Dola 没有找到时长选择按钮")
        duration_patterns = (
            re.compile(rf"{re.escape(duration)}\s*s", re.I),
            re.compile(rf"{re.escape(duration)}\s*秒", re.I),
            re.compile(rf"{re.escape(duration)}", re.I),
        )
        if not _wait_visible_option(page, duration_patterns):
            _raise_ui_not_ready(page, f"本地 Dola 没有找到 {duration} 秒选项")
    _step_pause(page, params)

    # The aspect ratio travels inside the request itself (ability_param.ratio),
    # which the manager's request hook writes; the page control is never clicked.
    if aspect:
        _log(f"比例 {aspect} 由提交参数强制写入，不点击页面比例控件")
    _step_pause(page, params)


_QUOTA_PATTERNS = (
    re.compile(r"今日\s*剩余\s*(\d+)\s*个?\s*视频生成额度", re.I),
    re.compile(r"剩余\s*(\d+)\s*个?\s*视频生成额度", re.I),
    re.compile(r"(?:today[^\n]{0,80})?remaining\s*(\d+)\s*video(?: generation)? credits?", re.I),
    re.compile(r"(\d+)\s*video(?: generation)? credits?\s*remaining", re.I),
    re.compile(r"(?:you\s+)?still\s+have\s+(\d+)\s+(?:points?|video(?: generation)? credits?)\s+left\s+today", re.I),
    re.compile(r"(\d+)\s+(?:points?|video(?: generation)? credits?)\s+left\s+today", re.I),
    re.compile(r"(\d+)\s+(?:points?|video(?: generation)? credits?|credits?)\s+remain(?:s|ing)?(?:\s+today)?", re.I),
    re.compile(r"(?:remaining|available)\s+(?:points?|video(?: generation)? credits?|credits?)\s*(?:are|is|:)?\s*(\d+)", re.I),
    re.compile(
        r"(?:today\s+)?(?:you\s+)?have\s+(\d+)\s+"
        r"(?:points?|video(?: generation)? credits?|credits?)\s+"
        r"(?:remaining|left|available)(?:\s+today)?",
        re.I,
    ),
    re.compile(
        r"(\d+)\s+(?:video(?: generation)?\s+)?credits?\s+available\s+today",
        re.I,
    ),
    re.compile(
        r"today(?:'s)?\s*(?:remaining\s*)?(?:video(?: generation)?\s*)?credits?"
        r"\s*(?:are|is|:)?\s*(\d+)",
        re.I,
    ),
    re.compile(
        r"(?:remaining|left)\s*(?:video(?: generation)?\s*)?credits?"
        r"\s*(?:are|is|:)?\s*(\d+)",
        re.I,
    ),
    re.compile(
        r"(?:you\s+have|there\s+are)\s*(\d+)\s*(?:video(?: generation)?\s*)?"
        r"credits?\s*(?:remaining|left)(?:\s+today)?",
        re.I,
    ),
)


def _extract_latest_quota(text):
    matches = []
    source = str(text or "")
    for pattern in _QUOTA_PATTERNS:
        for match in pattern.finditer(source):
            matches.append((match.start(), int(match.group(1))))
    if not matches:
        return None
    return max(matches, key=lambda item: item[0])[1]


def _check_video_quota(page, params, progress_callback):
    if not params.get("check_quota", True):
        return None
    _progress(progress_callback, "读取本地 Dola 视频额度", 3)
    page_text = _page_text(page)
    credit_error_check = globals().get("_is_credit_shortfall_failure")
    if credit_error_check is not None and credit_error_check(page_text):
        _log(
            "当前对话的额度数字来自 Dola‘无法生成’错误回执，"
            "忽略该数字，不判定账号额度不足"
        )
        return None
    latest_known = _extract_latest_quota(page_text)
    if latest_known is None:
        _log("页面没有已有额度数字；不会向 Dola 发消息查询，按插件今日成功次数继续调度")
        return None
    required = params["required_credits"]
    _log(f"本地 Dola 当前剩余 {latest_known} 个视频额度，本任务需要 {required} 个")
    _progress(progress_callback, f"当前额度 {latest_known}，任务需要 {required}", 4)
    if latest_known < required:
        raise InsufficientQuota(
            f"当前剩余 {latest_known} 个视频生成额度，少于本任务所需 {required} 个"
        )
    return latest_known


class _ProjectDataStub:
    """Minimal state holder used while reading the current project's data.ini."""


class _ProjectReferenceUnpickler(pickle.Unpickler):
    """Read only 字字 project data classes; never import arbitrary pickle globals."""

    _SAFE_BUILTINS = {
        "set": set,
        "frozenset": frozenset,
        "bytes": bytes,
        "bytearray": bytearray,
    }

    def find_class(self, module, name):
        if module == "comm_self.glob":
            return _ProjectDataStub
        if module == "builtins" and name in self._SAFE_BUILTINS:
            return self._SAFE_BUILTINS[name]
        raise pickle.UnpicklingError(f"不允许读取项目数据类型：{module}.{name}")


def _project_reference_items(context):
    """Recover manual reference items that older host builds omit from context."""
    unique_name = str((context or {}).get("unique_name") or "").strip()
    if not unique_name:
        return None, []
    roots = []
    for name in ("output_dir", "project_path"):
        value = (context or {}).get(name)
        if not value:
            continue
        try:
            root = Path(os.fspath(value)).resolve()
        except (OSError, TypeError, ValueError):
            continue
        if root.is_file():
            root = root.parent
        for candidate in (root, root.parent):
            if candidate not in roots:
                roots.append(candidate)
    for root in roots:
        data_path = root / "data.ini"
        if not data_path.is_file():
            continue
        try:
            parser = configparser.RawConfigParser()
            parser.read(data_path, encoding="utf-8")
            payload = parser.get("image_viewer", unique_name, fallback="").strip()
            if not payload:
                continue
            raw = base64.urlsafe_b64decode(payload.encode("ascii") + b"===")
            record = _ProjectReferenceUnpickler(io.BytesIO(raw)).load()
            items = getattr(record, "reference_items", None)
            if isinstance(items, (list, tuple)):
                return root, list(items)
        except Exception as error:
            _log(f"读取分镜手动参考项失败：{error}")
    return None, []


def _reference_paths(context):
    result = []
    seen = set()
    image_extensions = {
        ".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif", ".tif", ".tiff", ".avif"
    }

    def add(value, base_dir=None):
        if not value:
            return
        if isinstance(value, dict):
            for key in ("path", "file_path", "image_path", "local_path", "url"):
                if value.get(key):
                    add(value.get(key), base_dir)
                    return
            return
        if isinstance(value, (list, tuple)):
            for item in value:
                add(item, base_dir)
            return
        if not isinstance(value, (str, bytes, os.PathLike)):
            return
        try:
            path = Path(os.fspath(value))
            if base_dir is not None and not path.is_absolute():
                path = Path(base_dir) / path
            path = path.resolve()
        except (OSError, TypeError, ValueError):
            return
        if path.suffix.lower() not in image_extensions or not path.is_file():
            return
        key = os.path.normcase(str(path))
        if key not in seen:
            seen.add(key)
            result.append(str(path))

    def sort_key(item):
        key = item[0]
        try:
            return (0, int(key))
        except (TypeError, ValueError):
            return (1, str(key))

    def add_mapping(mapping):
        if isinstance(mapping, dict):
            for _, value in sorted(mapping.items(), key=sort_key):
                add(value)
        elif isinstance(mapping, (list, tuple)):
            add(mapping)

    references = context.get("reference_images") or {}
    if isinstance(references, (list, tuple)):
        add(references)
    elif isinstance(references, dict):
        found_named_mapping = False
        for name in (
            "参考图片MAP",
            "reference_images_map",
            "reference_map",
            "ref_map",
            "references",
            "reference_items",
        ):
            if name in references:
                found_named_mapping = True
                add_mapping(references.get(name))
        if not found_named_mapping:
            numeric = []
            for key, value in references.items():
                try:
                    numeric.append((int(key), value))
                except (TypeError, ValueError):
                    continue
            for _, value in sorted(numeric):
                add(value)
        for name in ("首帧", "尾帧", "first_frame", "end_frame"):
            add(references.get(name))

    for name in (
        "reference_items",
        "reference_image_paths",
        "first_frame_path",
        "end_frame_path",
        "first_frame_image_path",
        "end_frame_image_path",
    ):
        add(context.get(name))

    project_root, project_items = _project_reference_items(context)
    before_project_count = len(result)
    for item in project_items:
        if isinstance(item, dict) and str(item.get("media_type") or "image").lower() != "image":
            continue
        add(item, project_root)
    if len(result) > before_project_count:
        _log(
            f"已从字字当前分镜补齐 {len(result) - before_project_count} 张手动参考图；"
            f"本次共上传 {len(result)} 张"
        )
    elif result:
        _log(f"本次识别到 {len(result)} 张参考图")
    return result


def _limit_reference_paths(paths, params):
    values = list(paths or ())
    limit = _model_reference_limit((params or {}).get("model"))
    if len(values) <= limit:
        return values
    _log(
        f"{(params or {}).get('model') or '当前模型'} 最多支持 {limit} 张参考图；"
        f"本次识别到 {len(values)} 张，按原顺序使用前 {limit} 张"
    )
    return values[:limit]


def _mark_asset_button(page):
    # Never infer upload from an arbitrary SVG icon near the editor.
    return bool(_account_safety_call(page.evaluate,'() => {const c=('+_dola_composer_script()+')();'+r'''
      document.querySelectorAll('[data-dola-asset-button]').forEach(e=>e.removeAttribute('data-dola-asset-button'));
      if(!c)return false;
      // The current client renders the image entry as a plain DIV ("Add image"),
      // so divs/spans are scanned too. Label matches win over the icon testid.
      const rows=[...c.root.querySelectorAll('button,[role="button"],div,span')].filter(e=>{
        if(!e.getClientRects().length||e.disabled||e.closest('[data-kind],[data-message-id]')||
          e.hasAttribute('data-input-engine-actionbar-control-key')||e.id==='flow-end-msg-send'||
          e.getAttribute('data-testid')==='chat_input_send_button')return false;
        const text=(e.innerText||'').trim();
        if([...e.children].some(child=>(child.innerText||'').trim()===text&&text))return false;
        return true;
      });
      const label=e=>(e.getAttribute('aria-label')||e.getAttribute('title')||e.innerText||'').trim();
      const byLabel=rows.filter(e=>/^(?:Add image|Add files?|Upload(?: files?| images?)?|Attach(?: files?)?|添加附件|上传图片|添加图片|上传文件)$/i.test(label(e)));
      const byTestid=rows.filter(e=>/^(?:upload_file_button|image-creation-chat-input-upload-button)$/i.test((e.getAttribute('data-testid')||'').trim()));
      const chosen=byLabel.length===1?byLabel:byTestid.length===1?byTestid:[];
      if(chosen.length!==1)return false;
      chosen[0].setAttribute('data-dola-asset-button','1');return true;
    }'''))


def _set_input_files_via_local_cdp(page, target, paths):
    """Let the local Chromium process read files directly, bypassing 50MB transfer."""
    _assert_dola_upload_allowed(page)
    marker = "data-dola-direct-file-input"
    try:
        page.locator(f'[{marker}="1"]').evaluate_all(
            "(elements, name) => elements.forEach(el => el.removeAttribute(name))",
            marker,
        )
    except Exception:
        pass
    _account_safety_call(target.evaluate, "(el, name) => el.setAttribute(name, '1')", marker)
    session = page.context.new_cdp_session(page)
    try:
        document = session.send("DOM.getDocument", {"depth": 0})
        root = (document or {}).get("root") or {}
        node = session.send(
            "DOM.querySelector",
            {
                "nodeId": root.get("nodeId"),
                "selector": f'input[type="file"][{marker}="1"]',
            },
        )
        node_id = (node or {}).get("nodeId")
        if not node_id:
            raise RuntimeError("没有定位到本地文件上传控件")
        session.send(
            "DOM.setFileInputFiles",
            {
                "nodeId": node_id,
                "files": [str(Path(value).resolve()) for value in paths],
            },
        )
    finally:
        try:
            session.detach()
        except Exception:
            pass


def _assign_input_files(page, target, paths):
    _assert_dola_upload_allowed(page)
    try:
        _account_safety_call(target.set_input_files, paths)
        return
    except Exception as error:
        message = str(error or "")
        if "cannot transfer files larger than 50mb" not in message.lower():
            raise
    total_mb = sum(Path(value).stat().st_size for value in paths) / (1024 * 1024)
    _log(
        f"参考图合计 {total_mb:.1f}MB，超过普通上传通道50MB限制；"
        "改由本机 Dola 窗口直接读取文件"
    )
    _set_input_files_via_local_cdp(page, target, paths)


def _set_files_on_available_input(page, paths, timeout_ms=6000):
    """Attach the references to the page's own file input.

    Same shape as the reference Dola workbench: look for input[type=file] and hand
    the files straight to it — no button press, no OS dialog. The lookup is not
    limited to the composer subtree (the input can live just outside it), and the
    accept filter only ranks candidates, it never rejects the only input found.
    """
    deadline = time.monotonic() + max(0.0, timeout_ms / 1000.0)
    while True:
        root = _dola_composer_node(page, 'root')
        groups = []
        if root is not None:
            groups.append(root.query_selector_all('input[type="file"]'))
        try:
            groups.append(page.query_selector_all('input[type="file"]'))
        except Exception:
            pass
        for inputs in groups:
            if not inputs:
                continue
            preferred = [item for item in inputs if (not item.get_attribute('accept') or
                         re.search(r'image|\.(png|jpe?g|webp)', item.get_attribute('accept') or '', re.I))]
            candidates = preferred or list(inputs)
            if len(candidates) > 1 and preferred:
                candidates = preferred
            target = candidates[0]
            if len(paths) > 1 and target.get_attribute('multiple') is None and not preferred:
                continue
            _assign_input_files(page, target, paths)
            return True
        if time.monotonic() >= deadline:
            return False
        page.wait_for_timeout(300)


_UPLOAD_URL_HINT = re.compile(
    r"upload|image|media|asset|attachment|file|object|storage|tos|s3|cos|oss",
    re.I,
)


def _is_upload_request(request):
    try:
        method = str(request.method or "").upper()
        resource_type = str(request.resource_type or "").lower()
        url = str(request.url or "")
    except Exception:
        return False
    if method in {"PUT", "PATCH"}:
        return True
    if (
        resource_type in {"xhr", "fetch"}
        and method == "POST"
        and _UPLOAD_URL_HINT.search(url)
    ):
        return True
    return bool(_UPLOAD_URL_HINT.search(url)) and resource_type in {
        "xhr", "fetch", "image", "other"
    }


def _dola_upload_snapshot_script():
    return '() => { const input=('+_dola_composer_script()+')();'+r'''
      if(!input)return {found:false,items:[],cardCount:0,unknown:1,canSubmit:false,busy:true};
      const surface=input.root,visible=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);
        return e.isConnected&&r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden';};
      const nodes=[...surface.querySelectorAll('[data-testid="attachment-image-card"],[data-kind="image"],[class*="thumb-card-"]')]
        .filter(visible).filter(e=>!e.closest('[data-message-id]'));
      const cards=nodes.filter(e=>!nodes.some(p=>p!==e&&p.contains(e)));
      const items=[],seen=new Map();let unknown=0;
      function committedChain(fiber){
        const path=[],visited=new Set();
        for(let n=fiber;n;n=n.return){if(visited.has(n)||path.length>=256)return null;visited.add(n);path.push(n);}
        if(!path.length)return null;
        const root=path.at(-1),current=root.stateNode?.current;
        if(!current)return root.tag===3||path.some(n=>n.alternate)?null:path;
        if(current!==root&&current!==root.alternate)return null;
        const result=[current];let parent=current,budget=8192;
        for(let i=path.length-2;i>=0;i--){let match=null;
          for(let child=parent.child;child;child=child.sibling){if(--budget<=0)return null;
            if(child===path[i]||child===path[i].alternate){match=child;break;}}
          if(!match)return null;result.push(match);parent=match;
        }return result.reverse();
      }
      function add(value){
        if(!value||value.type!=='image'){unknown++;return;}
        const parseState=value.parseState ?? value.fileParseState ?? value.file_parse_state;
        const reviewState=value.reviewState ?? value.review_state ?? value.fileReviewState ?? value.file_review_state;
        const item={name:String(value.fileName||''),identity:String(value.localKey||value.fileKey||''),
          percent:Number(value.uploadPercent||0),status:String(value.status||''),hasKey:!!value.fileKey,
          parseState:parseState==null?null:parseState,reviewState:reviewState==null?null:reviewState,
          parseStatePresent:parseState!=null,reviewStatePresent:reviewState!=null,
          skipParseGate:value.skipParseGate===true};
        if(!item.name||!item.identity||!Number.isFinite(item.percent)){unknown++;return;}
        if(seen.has(item.identity)){if(JSON.stringify(seen.get(item.identity))!==JSON.stringify(item))unknown++;return;}
        seen.set(item.identity,item);items.push(item);
      }
      for(const card of cards.slice(0,32)){
        const chain=committedChain(card[Object.keys(card).find(k=>k.startsWith('__reactFiber'))]);
        let found=false;
        for(const f of (chain||[]).slice(0,20)){
          if(f.stateNode instanceof Element&&f.stateNode!==card&&!surface.contains(f.stateNode))break;
          const p=f.memoizedProps||{};
          if(p.attachmentState?.type==='image'){add(p.attachmentState);found=true;break;}
          if(Array.isArray(p.attachmentStates)){p.attachmentStates.forEach(add);found=true;break;}
          if(f.stateNode===surface)break;
        }
        if(!found)unknown++;
      }
      const busy=[...surface.querySelectorAll('[role="progressbar"],[aria-busy="true"],[data-state="loading"]')].some(visible);
      const buttons=[...surface.querySelectorAll('[data-testid="chat_input_send_button"],#flow-end-msg-send')].filter(visible);
      const canSubmit=buttons.length===1&&!buttons[0].disabled&&buttons[0].getAttribute('aria-disabled')!=='true';
      return {found:true,items,cardCount:cards.length,unknown:unknown+(cards.length>32?1:0),canSubmit,busy,
        selectedFileCount:[...surface.querySelectorAll('input[type="file"]')].reduce((n,e)=>Math.max(n,e.files?.length||0),0)};
    }'''


def _upload_ui_busy(page):
    state=_composer_upload_state(page)
    return (not state.get('found') or bool(state.get('busy') or state.get('unknown')) or
            any(x.get('status')!='Normal' or x.get('percent',0)<100 or not x.get('hasKey')
                for x in state.get('items',[])))


def _attachment_state_code(value):
    if isinstance(value,bool):
        return int(value)
    if isinstance(value,(int,float)) and int(value)==value:
        return int(value)
    text=str(value or '').strip().lower().replace('_','')
    return {'default':0,'processing':3,'success':1,'succeeded':1,'complete':1,
            'completed':1,'failed':2,'error':2}.get(text)


def _dola_attachment_failure(state):
    for item in state.get('items',[]):
        if item.get('parseStatePresent') and not item.get('skipParseGate'):
            code=_attachment_state_code(item.get('parseState'))
            if code==2:
                return 'Dola 素材预处理失败'
        if item.get('reviewStatePresent') and _attachment_state_code(item.get('reviewState'))==2:
            return 'Dola 素材审核未通过'
    return None


def _composer_upload_state(page):
    """Read current committed attachment metadata, not all nearby images."""
    try:
        state=_account_safety_call(page.evaluate,_dola_upload_snapshot_script())
        if not isinstance(state,dict):raise ValueError('unavailable')
        return dict(state,thumbnail_count=int(state.get('cardCount',0)),
                    selected_file_count=int(state.get('selectedFileCount',0)))
    except GenerationStopped:raise
    except Exception:
        return dict(found=False,items=[],thumbnail_count=0,selected_file_count=0,
                    unknown=1,busy=True,canSubmit=False)


def _mark_submit_button(page):
    return bool(_account_safety_call(page.evaluate,'() => {const c=('+_dola_composer_script()+')();'+r'''
      document.querySelectorAll('[data-dola-send-button]').forEach(e=>e.removeAttribute('data-dola-send-button'));
      if(!c)return false;
      const buttons=[...c.root.querySelectorAll('[data-testid="chat_input_send_button"],#flow-end-msg-send')]
        .filter(e=>e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden');
      if(buttons.length!==1||buttons[0].disabled||buttons[0].getAttribute('aria-disabled')==='true')return false;
      buttons[0].setAttribute('data-dola-send-button','1');return true;
    }'''))


def _composer_can_submit(page):
    return _composer_upload_state(page).get('canSubmit') is True


def _dola_attachment_signature(state,paths):
    from collections import Counter
    items=state.get('items',[])
    if (not state.get('found') or state.get('unknown') or state.get('busy') or not state.get('canSubmit')
            or state.get('thumbnail_count')!=len(paths) or len(items)!=len(paths)
            or Counter(x.get('name') for x in items)!=Counter(Path(p).name for p in paths)
            or any(x.get('status')!='Normal' or x.get('percent',0)<100 or not x.get('hasKey') or not x.get('identity')
                   or (x.get('parseStatePresent') and not x.get('skipParseGate') and _attachment_state_code(x.get('parseState'))!=1)
                   or (x.get('reviewStatePresent') and _attachment_state_code(x.get('reviewState')) not in (0,1))
                   for x in items)):
        return None
    return tuple(sorted((str(x['name']),str(x['identity'])) for x in items))


def _dola_draft_snapshot(page):
    value=_account_safety_call(page.evaluate,'() => {const c=('+_dola_composer_script()+')();'+r'''
      if(!c)return null;
      return {text:c.editor.tagName==='TEXTAREA'?c.editor.value:c.editor.innerText,
        message_ids:[...document.querySelectorAll('[data-message-id]')].map(e=>e.getAttribute('data-message-id'))};
    }''')
    if not isinstance(value,dict):raise PreparationUnconfirmed('当前输入区无法确认，图文草稿保留，未发送')
    return (hashlib.sha256(str(value.get('text','')).replace('\r\n','\n').replace('\r','\n').encode('utf8')).hexdigest(),
            frozenset(value.get('message_ids',[])))



def _dola_upload_chat_id(url):
    route=_dola_duration_route(url)
    if route is None:return None
    path=route[0].rstrip('/')
    if route[2].startswith('/chat/'):
        path=route[2].split('?',1)[0].rstrip('/')
    match=re.fullmatch(r'/chat/((?:local_)?[A-Za-z0-9_-]+)',path)
    return match.group(1) if match else None


def _dola_upload_journal(update=None):
    # Separate from daily quota/recovery state: clearing those must never
    # unlock a sent chat. Only hashes and booleans are persisted.
    path=_PLUGIN_DIR/'data'/'dola-sent-chats.json'
    with _state_lock:
        try:
            state=json.loads(path.read_text(encoding='utf8')) if path.exists() else {'sent':{},'pending':{}}
            if (not isinstance(state,dict) or set(state)!={'sent','pending'} or
                    any(not isinstance(state[k],dict) for k in state)):
                raise ValueError('invalid journal')
            if update is not None:
                update(state)
                path.parent.mkdir(parents=True,exist_ok=True)
                temporary=path.with_suffix('.tmp')
                temporary.write_text(json.dumps(state,sort_keys=True),encoding='utf8')
                os.replace(temporary,path)
            return state
        except Exception as error:
            raise PreparationUnconfirmed('无法确认本对话的提交记录，已停止上传和发送；请保留原窗口') from error


def _bind_dola_upload_scope(page,params,account_index):
    try:
        manager,_=_manager_paths(params)
    except NameError:
        manager=Path(str(params.get('manager_root') or 'synthetic-manager'))
    if type(account_index) is not int or account_index<=0:
        raise PreparationUnconfirmed('缺少本次素材的账号绑定，未上传')
    identity=[os.path.normcase(str(Path(manager).resolve())),account_index,int(params['base_port'])+account_index]
    owner=hashlib.sha256(json.dumps(identity).encode('utf8')).hexdigest()
    old=getattr(page,'_anne_dola_upload_scope',None)
    if isinstance(old,dict) and old['owner']!=owner:
        raise PreparationUnconfirmed('素材绑定的账号已改变，未上传或发送')
    page._anne_dola_upload_scope={'owner':owner}


def _dola_upload_keys(page):
    scope=getattr(page,'_anne_dola_upload_scope',None)
    if not isinstance(scope,dict):
        raise PreparationUnconfirmed('缺少本次素材的对话绑定，未上传或发送')
    if _dola_duration_route(page.url) is None:
        raise PreparationUnconfirmed('原 Dola 页面已变化，未上传或发送')
    owner=scope['owner'];chat=_dola_upload_chat_id(page.url)
    key=hashlib.sha256((owner+'|'+chat).encode('utf8')).hexdigest() if chat else None
    return owner,key


def _assert_dola_upload_allowed(page):
    owner,key=_dola_upload_keys(page)
    state=_dola_upload_journal()
    if owner in state['pending'] or (key is not None and key in state['sent']):
        raise PreparationUnconfirmed('本账号的原对话已点击发送，禁止再次上传素材或重发图文；请等待原任务结果')


def _mark_dola_submission_locked(page):
    owner,key=_dola_upload_keys(page)
    def reserve(state):
        if owner in state['pending'] or (key is not None and key in state['sent']):
            raise PreparationUnconfirmed('本对话已提交，未重复发送')
        state['pending'][owner]=True
        if key is not None:state['sent'][key]=True
    # Persist BEFORE clicking: a click timeout cannot establish that nothing
    # was sent. A later draft snapshot cannot reset this reservation.
    _dola_upload_journal(reserve)


def _record_dola_sent_chat(page):
    owner,key=_dola_upload_keys(page)
    if key is None:return
    def record(state):
        if owner in state['pending']:state['sent'][key]=True
    _dola_upload_journal(record)


def _confirm_dola_fresh_upload_chat(page):
    scope=getattr(page,'_anne_dola_upload_scope',None)
    if not isinstance(scope,dict):return  # Read-only recovery callers.
    route=_dola_duration_route(page.url)
    if route is None or route[0] not in {'/','/chat','/chat/'} or route[2]:
        raise PreparationUnconfirmed('未确认新的空白对话，原对话上传锁保留')
    state=_account_safety_call(page.evaluate,'() => {const c=('+_dola_composer_script()+')();'+r'''
      if(!c)return false;
      const text=c.editor.tagName==='TEXTAREA'?c.editor.value:c.editor.innerText;
      return !String(text||'').trim() && !document.querySelector('[data-message-id]') &&
        !c.root.querySelector('[data-kind],[data-testid="attachment-image-card"],[class*="thumb-card-"],[data-testid="attachment_area"]') &&
        [...c.root.querySelectorAll('input[type="file"]')].every(e=>!e.files?.length);
    }''')
    if state is not True:
        raise PreparationUnconfirmed('新对话仍有文字或附件，未解除原对话上传锁')
    owner=scope['owner']
    if owner in _dola_upload_journal()['pending']:
        _dola_upload_journal(lambda journal:journal['pending'].pop(owner,None))


def _remember_dola_draft(page,paths):
    _assert_dola_upload_allowed(page)
    text,ids=_dola_draft_snapshot(page)
    page._anne_dola_draft_guard=dict(url=page.url,text=text,message_ids=ids,paths=list(paths),attachments=None)


def _assert_dola_draft(page,require_upload=False):
    guard=getattr(page,'_anne_dola_draft_guard',None)
    if not isinstance(guard,dict):return
    if page.url!=guard['url']:
        raise PreparationUnconfirmed('准备期间对话已改变，原任务保留，不自动重传')
    text,ids=_dola_draft_snapshot(page)
    if text!=guard['text'] or ids!=guard['message_ids']:
        raise PreparationUnconfirmed('准备期间输入文字或消息已改变，未补发或重复上传')
    if require_upload and guard['paths']:
        current=_dola_attachment_signature(_composer_upload_state(page),guard['paths'])
        if current is None or current!=guard['attachments']:
            raise PreparationUnconfirmed('发送前图片数量、身份或上传状态已变化，草稿保留，未发送')


def _wait_for_reference_uploads(page, paths, params, tracker, account_index=None):
    started=_active_wait_clock()
    stable_since=None;last_report=None;last_report_at=started;last_state={}
    while True:
        _check_stopped()
        now=_active_wait_clock()
        if now-started>=params['upload_timeout']:break
        _assert_dola_draft(page)
        state=_composer_upload_state(page);last_state=state
        failure=_dola_attachment_failure(state)
        if failure:
            raise PreparationUnconfirmed(f'{failure}；已保留素材，不发送、不自动重传')
        ready=_dola_attachment_signature(state,paths)
        done=sum(x.get('status')=='Normal' and x.get('percent',0)>=100 and x.get('hasKey')
                 for x in state.get('items',[]))
        progress=(state.get('thumbnail_count',0),done,bool(state.get('unknown')))
        if progress!=last_report or now-last_report_at>=10:
            _log(f'账号{account_index} 素材卡片 {progress[0]}/{len(paths)}，上传完成 {done}/{len(paths)}'
                 +('，附件状态待确认' if progress[2] else ''))
            last_report=progress;last_report_at=now
        if ready is not None:
            if stable_since is None:stable_since=now
            elif now-stable_since>=max(1,min(3,params['step_delay_seconds'])):
                guard=getattr(page,'_anne_dola_draft_guard',None)
                if isinstance(guard,dict):guard['attachments']=ready
                _log(f'账号{account_index} {len(paths)} 张图片上传状态和发送控件已确认')
                return
        else:stable_since=None
        page.wait_for_timeout(250)
    raise UploadNotReady(f'等待 {len(paths)} 张图片确认超时：当前卡片 {last_state.get("thumbnail_count",0)} 张；'
                         '原图文草稿已保留，不自动新建对话或重传。')


def _mark_asset_menu_item(page):
    """Resolve one image item in the current composer's own or linked menu."""
    return bool(_account_safety_call(page.evaluate, '() => {const c=('+_dola_composer_script()+')();'+r'''
      document.querySelectorAll('[data-dola-asset-menu-item]').forEach(e=>e.removeAttribute('data-dola-asset-menu-item'));
      if(!c)return false;
      const trigger=document.querySelector('[data-dola-asset-button="1"]');
      if(!trigger||!c.root.contains(trigger))return false;
      const visible=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);
        return e.isConnected&&r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'&&
          !e.closest('[hidden],[inert],[aria-hidden="true"],[data-message-id]');};
      const controls=(trigger.getAttribute('aria-controls')||'').split(/\s+/).filter(Boolean);
      const menus=[...document.querySelectorAll('[role="menu"]')].filter(e=>visible(e)&&
        (c.root.contains(e)||controls.includes(e.id)||(trigger.id&&
          (e.getAttribute('aria-labelledby')||'').split(/\s+/).includes(trigger.id))));
      const labels=/^(?:Add image|Add images|Upload images?|添加图片|上传图片)$/i;
      const matches=new Set();
      for(const menu of menus){
        for(const node of menu.querySelectorAll('[role="menuitem"],button,div,span')){
          if(!visible(node)||!labels.test((node.getAttribute('aria-label')||node.innerText||'').trim()))continue;
          if([...node.children].some(e=>labels.test((e.innerText||'').trim())))continue;
          const item=node.closest('[role="menuitem"],button')||node;
          if(!menu.contains(item)||!visible(item)||item.disabled||item.hasAttribute('data-disabled')||
            item.getAttribute('aria-disabled')==='true'||item===trigger||trigger.contains(item))continue;
          matches.add(item);
        }
      }
      if(matches.size!==1)return false;
      [...matches][0].setAttribute('data-dola-asset-menu-item','1');return true;
    }'''))


def _choose_dola_reference_files(page, button, paths, timeout_ms=8000):
    """Intercept the chooser across both + and Add image; assign a file batch once."""
    choosers=[]
    def capture(chooser):
        choosers.append(chooser)
    page.on('filechooser',capture)
    try:
        _check_stopped()
        _assert_dola_upload_allowed(page)
        _assert_dola_draft(page)
        if not _click_element(page,button):
            raise PreparationUnconfirmed('上传入口不可点击，已保留草稿')
        menu_clicked=False
        deadline=time.monotonic()+max(0.0,timeout_ms/1000.0)
        while True:
            _check_stopped()
            _assert_dola_upload_allowed(page)
            _assert_dola_draft(page)
            if choosers:
                if len(choosers)!=1:
                    raise PreparationUnconfirmed('出现多个文件选择入口，草稿保留；未重复上传')
                _account_safety_call(choosers[0].set_files,paths)
                return
            if _set_files_on_available_input(page,paths,timeout_ms=0):
                return
            if not menu_clicked and _mark_asset_menu_item(page):
                menu_clicked=True
                _assert_dola_upload_allowed(page)
                _assert_dola_draft(page)
                if not _click_element(page,page.locator('[data-dola-asset-menu-item="1"]')):
                    raise PreparationUnconfirmed('添加图片菜单不可点击，已保留草稿')
                continue
            if time.monotonic()>=deadline:
                raise PreparationUnconfirmed('附件选择结果不确定，草稿保留；未再次点击上传')
            page.wait_for_timeout(150)
    finally:
        page.remove_listener('filechooser',capture)



def _upload_references(page, paths, params, account_index=None):
    _check_stopped()
    if not paths:
        return
    _assert_dola_upload_allowed(page)
    _assert_dola_draft(page)
    initial=_composer_upload_state(page)
    if (not initial.get('found') or initial.get('thumbnail_count') or
            initial.get('selected_file_count')):
        raise PreparationUnconfirmed('当前输入区已有附件或归属未确认，保留草稿，不重复上传')
    tracker = {
        "pending": set(),
        "seen": 0,
        "last_activity": time.monotonic(),
    }

    def request_started(request):
        if not _is_upload_request(request):
            return
        tracker["pending"].add(id(request))
        tracker["seen"] += 1
        tracker["last_activity"] = time.monotonic()

    def request_finished(request):
        key = id(request)
        if key in tracker["pending"]:
            tracker["pending"].discard(key)
            tracker["last_activity"] = time.monotonic()

    page.on("request", request_started)
    page.on("requestfinished", request_finished)
    page.on("requestfailed", request_finished)
    try:
        try:
            files_selected = _set_files_on_available_input(page, paths)
        except Exception as error:
            message = str(error or "")
            if "set_input_files" not in message or "timeout" not in message.lower():
                raise
            prefix = f"账号{account_index} " if account_index is not None else ""
            _log(
                f"{prefix}上传控件回调超时，继续按页面图片进度确认，"
                "不会立即新建对话"
            )
            _wait_for_reference_uploads(page, paths, params, tracker, account_index)
            return
        if files_selected:
            _wait_for_reference_uploads(page, paths, params, tracker, account_index)
            return

        # Keep chooser interception active while opening + and then Add image.
        try:
            page.evaluate('() => {const a=document.activeElement;if(a&&a.blur)a.blur();}')
            page.wait_for_timeout(400)
        except GenerationStopped:
            raise
        except Exception:
            pass
        if not _mark_asset_button(page):
            raise PreparationUnconfirmed("没有找到资产上传入口，已保留草稿")
        _choose_dola_reference_files(page,page.locator('[data-dola-asset-button="1"]'),paths)
        _wait_for_reference_uploads(page,paths,params,tracker,account_index)

    finally:
        for event, callback in (
            ("request", request_started),
            ("requestfinished", request_finished),
            ("requestfailed", request_finished),
        ):
            try:
                page.remove_listener(event, callback)
            except Exception:
                pass


def _submission_prompt(prompt, params):
    prompt = str(prompt or "").strip()
    if not params["append_parameters"]:
        return prompt
    suffix = (
        f"请使用 {params.get('model') or 'Seedance 2.5'}，生成"
        f"{params.get('duration') or '30'}秒、{params.get('aspect_ratio') or '16:9'}视频。"
    )
    if suffix in prompt:
        return prompt
    return f"{prompt}\n\n{suffix}"


def _fill_prompt(composer, prompt):
    _check_stopped()
    _account_safety_call(composer.click)
    try:
        _account_safety_call(composer.fill, prompt)
    except Exception:
        _account_safety_call(composer.press, "Control+A")
        composer.press_sequentially(prompt, delay=0)


def _try_select_visible_setting(page, value):
    value = str(value or "").strip()
    if not value:
        return False
    selects = page.locator("select")
    try:
        for number in range(selects.count()):
            item = selects.nth(number)
            options = item.locator("option")
            for option_number in range(options.count()):
                option = options.nth(option_number)
                label = (option.inner_text() or "").strip()
                option_value = option.get_attribute("value") or ""
                if value.lower() in label.lower() or value == option_value:
                    _account_safety_call(item.select_option, index=option_number)
                    return True
    except Exception:
        pass
    exact = page.get_by_text(re.compile(rf"^{re.escape(value)}$", re.I))
    try:
        for number in range(exact.count() - 1, -1, -1):
            item = exact.nth(number)
            if item.is_visible():
                _account_safety_call(item.click)
                page.wait_for_timeout(350)
                return True
    except Exception:
        pass
    return False


def _click_send(page, composer):
    _assert_dola_upload_allowed(page)
    _check_stopped()
    marked = _mark_submit_button(page)
    _check_account_safety()
    if marked:
        button = page.locator('[data-dola-send-button="1"]')
        _mark_dola_submission_locked(page)
        try:
            _account_safety_call(button.click)
        finally:
            _record_dola_sent_chat(page)
        return
    raise PreparationUnconfirmed('原输入区的发送按钮尚未就绪，保留草稿，不猜测按回车')






_SUCCESS_CREDIT = re.compile(
    r"(?:将)?消耗\s*\d+\s*个?\s*视频生成额度|"
    r"(?:will\s+)?consum(?:e|es|ing)\s*\d+\s*"
    r"(?:video(?: generation)?\s*)?(?:points?|credits?)|"
    r"\d+\s*(?:video(?: generation)?\s*)?(?:points?|credits?)\s*"
    r"(?:will be )?(?:used|consumed|deducted|charged)|"
    r"(?:will\s+)?(?:use|cost|deduct|charge)\s*\d+\s*"
    r"(?:video(?: generation)?\s*)?(?:points?|credits?)|"
    r"requires?\s*\d+\s*(?:video(?: generation)?\s*)?(?:points?|credits?)",
    re.I,
)
_SUCCESS_WAIT = re.compile(
    r"(?:预计|预估).{0,20}\d+\s*分钟|"
    r"estimated\s+wait(?:ing)?\s+time\s+(?:of\s+)?\d+\s*(?:minutes?|mins?)|"
    r"wait(?:ing)?.{0,20}\d+\s*(?:minutes?|mins?)|"
    r"(?:be\s+)?ready\s+in\s+\d+\s*(?:minutes?|mins?)|"
    r"estimated\s+(?:generation|processing)\s+time.{0,20}\d+\s*(?:minutes?|mins?)|"
    r"estimated\s+to\s+(?:take|need)\s+\d+\s*(?:minutes?|mins?)|"
    r"(?:generation|processing)\s+(?:will|may)\s+take\s+\d+\s*(?:minutes?|mins?)|"
    r"(?:it|this)\s+(?:will|may)\s+take.{0,20}\d+\s*(?:minutes?|mins?)|"
    r"please\s+(?:allow|wait).{0,20}\d+\s*(?:minutes?|mins?)",
    re.I,
)
_PLAN_ANNOUNCEMENT = re.compile(
    # Any reply that asks the user to choose or to reply is not a receipt: the task
    # must start a new chat and resubmit. Kept broad on purpose, and always used
    # together with "no waiting-time line" so real receipts are never misread.
    r"请确认|需要先确认|先确认一下|您看我是选择|选择哪种方式|您回复|回复选项|请回复|"
    r"我建议按|我建议|建议按|无法完整承载|无法完整|精简版|精简连贯版|"
    r"单次视频生成最长支持|单条视频支持|目前单次|超出.{0,12}(?:最长|上限|限制)|"
    r"拆分成两条|拆成两条|分成两段|合并压缩|先生成第一条|"
    r"would\s+you\s+like|do\s+you\s+want\s+me|shall\s+I\s+(?:proceed|generate)|"
    r"proceed\s+with|exceeds?\s+the\s+(?:current\s+)?maximum|nearest\s+supported|"
    r"reply\s+(?:with\s+)?[A-Z]|choose\s+(?:an?\s+)?option|please\s+confirm|"
    r"only\s+two\s+videos?\s+can\s+be\s+generated|i'?ll\s+start\s+by\s+generating|"
    r"the\s+requested\s+timing\s+sums?\s+to|within\s+the\s+supported|"
    r"只能同时生成|只会一次生成|我将开始生成",
    re.I,
)


def _format_elapsed_wait(seconds):
    total = max(0, int(float(seconds or 0)))
    # Keep the progress text stable for ten seconds so the generation log is
    # informative without receiving a new line every two-second poll.
    total = (total // 10) * 10
    hours, remainder = divmod(total, 3600)
    minutes, seconds = divmod(remainder, 60)
    if hours:
        return f"{hours}小时{minutes:02d}分{seconds:02d}秒"
    if minutes:
        return f"{minutes}分{seconds:02d}秒"
    return f"{seconds}秒"


def _waiting_progress_text(prefix, status, elapsed):
    return f"{prefix}{status}｜已等待 {_format_elapsed_wait(elapsed)}"


_STRICT_GENERATE_VIDEO = re.compile(
    r"(?:将|会|正在|开始|准备)?(?:为.{0,12})?生成.{0,40}?视频|"
    r"(?:will\s+|am\s+|is\s+|are\s+|start(?:ing)?\s+to\s+)?"
    r"(?:generate|generating|create|creating)\s+.{0,50}?video",
    re.I,
)
_ENGLISH_DISPATCH_RECEIPT = re.compile(
    r"\bi(?:['’]ll|\s+will|\s+am\s+going\s+to)\s+"
    r"(?:now\s+)?(?:start|begin)?\s*(?:(?:by|with|to)\s+)?"
    r"(?:generat(?:e|ing)|creat(?:e|ing)|produc(?:e|ing))"
    r"[\s\S]{0,120}\b(?:video|clip|segment)s?\b|"
    r"\bi(?:['’]ve|\s+have)\s+(?:now\s+)?started\s+"
    r"(?:generating|creating|producing)[\s\S]{0,120}"
    r"\b(?:video|clip|segment)s?\b|"
    r"\b(?:your|the|this)\s+(?:video\s+)?(?:generation\s+)?"
    r"(?:task|request|video)\s+(?:has\s+been|is|was)\s+"
    r"(?:successfully\s+)?(?:queued|submitted|started|accepted|"
    r"being\s+generated|in\s+progress)\b|"
    r"\bstarting\s+(?:the\s+|your\s+|this\s+)?video\s+generation\s+now\b|"
    r"\b(?:the|your|this)\s+video\s+(?:will|is\s+going\s+to)\s+be\s+generated\b"
    r"[\s\S]{0,500}\bi(?:['’]ll|\s+will)\s+send\s+it\s+to\s+you\b",
    re.I,
)
_NON_SUCCESS_RESPONSE = re.compile(
    r"暂时无法生成|无法生成(?:该|此|这个)?视频|"
    r"无法生成你|无法为你生成|不能生成|不能为你生成|"
    r"出了点问题.{0,30}(?:稍后|重试)|"
    r"出现(?:了)?(?:一点|一些)?问题.{0,30}(?:稍后|重试)|"
    r"请尝试输入其他要求|请换一个要求|我会尽力为你提供帮助|"
    r"抱歉.{0,80}(?:无法|不能|做不到)|"
    r"(?:cannot|can't|unable\s+to|won't)\s+(?:generate|create)|"
    r"(?:temporarily\s+)?(?:cannot|can't|unable\s+to)\s+(?:help\s+with|assist\s+with)|"
    r"try\s+(?:a\s+)?(?:different|another)\s+(?:request|prompt|topic)|"
    r"try\s+(?:changing|rephrasing)\s+(?:the\s+)?(?:request|prompt|topic)|"
    r"(?:something\s+went\s+wrong|an?\s+(?:unexpected\s+)?error\s+occurred)"
    r".{0,40}(?:try\s+again|later)|"
    r"(?:help|assist)\s+with\s+something\s+else",
    re.I,
)
_VIDEO_DISPLAY_BLOCKED_RESPONSE = re.compile(
    r"(?:无法|不能|没法|不便)(?:向你|为你)?(?:展示|显示|提供|播放)"
    r".{0,80}(?:生成的?视频|视频).{0,100}"
    r"(?:版权|政策|违规|受限|不符合)|"
    r"(?:generated\s+video|video).{0,120}"
    r"(?:copyright(?:ed)?|policy[-\s]?violating|content\s+policy|restricted)"
    r".{0,100}(?:can't|cannot|unable|not able|won't)\s+(?:show|display|provide|play)|"
    r"(?:can't|cannot|unable|not able)\s+(?:show|display|provide|play)"
    r".{0,140}(?:copyright(?:ed)?|policy[-\s]?violating|content\s+policy|restricted)|"
    r"(?:没有|未|未曾|不会)(?:消耗|扣除|使用).{0,25}(?:额度|积分)|"
    r"no\s+(?:credits?|points?)\s+(?:were|was)\s+(?:used|consumed|deducted)"
    r"(?:\s+for\s+(?:this|the)\s+video)?",
    re.I,
)
_CONSUMED_CREDIT_PATTERNS = (
    re.compile(r"(?:将|需要|需)?消耗\s*(\d+)\s*个?\s*视频生成额度", re.I),
    re.compile(r"(?:will\s+)?consum(?:e|es|ing)\s*(\d+)\s*(?:video(?: generation)?\s*)?(?:points?|credits?)", re.I),
    re.compile(r"(\d+)\s*(?:video(?: generation)?\s*)?(?:points?|credits?)\s*(?:will be )?(?:used|consumed|deducted|charged)", re.I),
    re.compile(r"(?:will\s+)?(?:use|cost|deduct|charge)\s*(\d+)\s*(?:video(?: generation)?\s*)?(?:points?|credits?)", re.I),
)


def _extract_consumed_credits(text):
    matches = []
    source = str(text or "")
    for pattern in _CONSUMED_CREDIT_PATTERNS:
        for match in pattern.finditer(source):
            matches.append((match.start(), int(match.group(1))))
    if not matches:
        return None
    return max(matches, key=lambda item: item[0])[1]


def _remember_account_balance(index, text):
    """Store the remaining credits Dola reported for this account."""
    try:
        value = _extract_latest_quota(text)
    except Exception:
        return None
    if value is None or int(index) <= 0:
        return None
    with _state_lock:
        state = _load_state_unlocked()
        balances = state.setdefault("credits", {})
        balances[str(int(index))] = int(value)
        state["credits_day"] = _quota_day()
        _save_state_unlocked(state)
    return int(value)


def _record_consumed_credits(params, text):
    consumed = _extract_consumed_credits(text)
    if consumed is None or consumed <= 0:
        return None
    fixed = _fixed_model_credit_cost(params.get("model"))
    if fixed is not None:
        params["required_credits"] = fixed
        if consumed != fixed:
            _log(
                f"Dola 回执的额度数字 {consumed} 与固定规则不符，"
                f"已忽略；{params.get('model')} 仍按 {fixed} 个额度计算"
            )
        return fixed
    key = _credit_cost_key(params)
    with _state_lock:
        _observed_credit_costs[key] = consumed
    params["required_credits"] = consumed
    _log(
        f"已从 Dola 回执识别实际消耗：{params.get('model')} "
        f"{params.get('duration')}秒 = {consumed} 个额度"
    )
    return consumed
_NEW_CHAT_TEXT = re.compile(
    r"请确认|确认后.*生成|是否按.*生成|请回复|回复.{0,30}(?:确认|同意|继续)|"
    r"发送.{0,20}(?:确认|回复)|请告诉我.{0,30}(?:确认|继续)|"
    r"目前支持\s*4\s*到\s*15\s*秒|"
    r"支持\s*4\s*至\s*15\s*秒|"
    r"请求的.{0,30}(?:时长|比例).{0,30}不支持|超过.{0,30}15\s*秒|"
    r"(?:please\s+confirm|once\s+you\s+confirm|need\s+your\s+confirmation)|"
    r"confirm.*generate|supports?\s*4\s*(?:to|-|through)\s*15\s*seconds|"
    r"video\s+generation\s+currently\s+supports?\s+(?:durations?\s+)?from\s+4\s+to\s+15\s+seconds?|"
    r"duration\s+you\s+requested.{0,50}(?:not\s+supported|exceeds)|"
    r"(?:the\s+)?total\s+duration\s+is\s+\d+\s*seconds?"
    r"[\s\S]{0,100}exceeds[\s\S]{0,80}(?:15[-\s]?second|per\s+video|limit)|"
    r"only\s+(?:one|two|\d+)\s+videos?\s+can\s+be\s+generated\s+at\s+a\s+time|"
    r"(?:generate|split).{0,40}(?:two|three|multiple|\d+)\s+"
    r"(?:consecutive\s+)?(?:clips?|segments?)|"
    r"nearest\s+supported\s+duration[\s\S]{0,40}15\s*seconds?|"
    r"(?:aspect\s+ratio|ratio)\s+(?:you\s+requested\s+)?(?:is\s+)?not\s+supported|"
    r"(?:reply|respond).{0,30}(?:confirm|yes|continue|proceed)|"
    r"(?:would\s+you\s+like|shall\s+i|should\s+i|do\s+you\s+want\s+me\s+to)"
    r".{0,40}(?:generate|create|continue|proceed|start)",
    re.I,
)
_CONFIRMATION_TEXT = re.compile(
    # Conditional promises are not queue receipts: "如果确认，我就...生成".
    # Keep this separate from duration/parameter descriptions, which alone
    # do not prove that Dola is asking for another user response.
    r"(?:如果|假如|若)(?:你|您)?(?:确认|同意|认可)"
    r"[^。！？!?]{0,80}(?:生成|制作|开始)|"
    r"(?:确认|同意)(?:无误)?(?:的话|之后|以后)"
    r"[^。！？!?]{0,80}(?:生成|制作|开始)|"
    r"请确认|确认后.*生成|是否按.*生成|请回复|"
    r"回复.{0,30}(?:确认|同意|继续)|发送.{0,20}(?:确认|回复)|"
    r"请告诉我.{0,30}(?:确认|继续)|"
    r"(?:please\s+confirm|once\s+you\s+confirm|need\s+your\s+confirmation)|"
    r"confirm.*generate|(?:reply|respond).{0,30}(?:confirm|yes|continue|proceed)|"
    r"(?:would\s+you\s+like|shall\s+i|should\s+i|do\s+you\s+want\s+me\s+to)"
    r".{0,40}(?:generate|create|continue|proceed|start)",
    re.I,
)
_PORTRAIT_PROTECTION_TEXT = re.compile(
    r"真人肖像|肖像保护|肖像权|公众人物|real person|real people|"
    r"portrait protection|likeness protection|"
    r"doesn'?t\s+support\s+generating\s+videos\s+from\s+images|"
    r"create\s+a\s+video\s+from\s+text|"
    r"likeness protection|identity protection|face likeness|image rights|"
    r"public figure|private individual|celebrity likeness",
    re.I,
)
_MANUAL_TEXT = re.compile(
    r"安全政策|违规|不符合.*规范|风险内容|safety policy|policy violation|"
    r"content policy|community guidelines?|restricted content|unsafe content|"
    r"(?:does not|doesn't|may not) comply with.{0,40}(?:policy|guidelines?)|"
    r"copyright infringement",
    re.I,
)
_PROMPT_POLICY_WARNING_MARKERS = (
    re.compile(
        r"我注意到(?:你|您).{0,60}(?:提供|创作).{0,80}"
        r"(?:暴力|伤害|死亡|沉重内容)",
        re.I,
    ),
    re.compile(
        r"建议.{0,100}(?:生命的尊重与关怀|尊重生命|避免过度渲染"
        r"|暴力和痛苦的细节)",
        re.I,
    ),
    re.compile(
        r"(?:严格)?遵循.{0,50}(?:平台|社区).{0,35}(?:内容)?规范",
        re.I,
    ),
    re.compile(
        r"(?:情绪|心理).{0,50}(?:困扰|不适|影响)",
        re.I,
    ),
    re.compile(
        r"(?:寻求|获得).{0,30}(?:专业)?心理支持|"
        r"帮助是随时可用的|(?:你|您)并不孤单",
        re.I,
    ),
    re.compile(
        r"(?:I noticed|It sounds like).{0,100}(?:violence|injury|death|distressing content)|"
        r"(?:seek|reach out for).{0,40}(?:professional )?(?:mental health )?support",
        re.I,
    ),
)
_TRANSIENT_FACE_TEXT = re.compile(
    r"(?:人脸|面部).{0,30}(?:失败|异常|不稳定|不一致|没通过)|"
    r"(?:face|facial|face verification|facial recognition|face consistency)"
    r".{0,40}(?:failed|error|unstable|inconsistent|not detected|not verified)|"
    r"(?:could not|couldn't|unable to)\s+detect.{0,20}(?:a\s+)?face",
    re.I,
)
_LOGIN_TEXT = re.compile(
    r"请先登录|登录后.*使用|会话已过期|"
    r"(?:please\s+)?(?:log|sign)\s+in\s+to\s+continue|"
    r"you\s+need\s+to\s+(?:log|sign)\s+in|"
    r"session\s+(?:has\s+)?expired|authentication\s+(?:has\s+)?expired|"
    r"you\s+have\s+been\s+signed\s+out",
    re.I,
)
_DAILY_LIMIT_TEXT = re.compile(
    r"(?:今天|今日|当日|每天|每日)的?(?:视频)?生成次数(?:已经|已)?"
    r"(?:达到|达到了|达)?上限|明天再来免费生成|"
    r"(?:daily|today.s)\s+(?:video\s+)?generation\s+limit\s+"
    r"(?:(?:has\s+been|is|already)\s+)?reached|"
    r"(?:reached|hit)\s+(?:(?:your|the)\s+)?daily\s+(?:video\s+)?generation\s+limit",
    re.I,
)


_INSUFFICIENT_TEXT = re.compile(
    r"额度不足|视频生成额度.{0,20}(?:不足|用完|耗尽)|没有足够.{0,20}额度|"
    r"insufficient.{0,40}(?:credit|quota)|not enough.{0,40}(?:credit|quota)|"
    r"(?:credit|quota).{0,40}(?:exhausted|used up)|"
    r"(?:no|zero)\s+(?:video generation\s+)?credits?\s+(?:left|remaining)|"
    r"(?:out of|used all).{0,20}(?:credits?|quota)|"
    r"(?:only\s+have|have\s+only)\s+\d+\s+(?:credits?|quota|points?|left)\b|"
    r"(?:daily|usage|generation)\s+limit\s+(?:has\s+been\s+)?reached",
    re.I,
)
_CREDIT_SHORTFALL_FAILURE_TEXT = re.compile(
    r"无法生成(?:该|此|这个)?视频|"
    r"请尝试降低(?:生成)?配置后重试|"
    r"(?:cannot|can't|unable\s+to)\s+(?:generate|create).{0,40}video|"
    r"(?:will\s+use|requires?|needs?)\s+\d+\s+(?:video\s+)?credits?[^.\n]{0,100}"
    r"(?:only\s+have|have\s+only)\s+\d+\s+(?:left|remaining)|"
    r"(?:lower|reduce).{0,30}(?:settings?|configuration).{0,30}(?:try|retry)",
    re.I,
)


def _is_prompt_policy_warning(text):
    """Recognize Dola's safety-counselling reply without keying on prompt words alone."""
    tail = str(text or "")[-12000:]
    matches = sum(
        1 for pattern in _PROMPT_POLICY_WARNING_MARKERS if pattern.search(tail)
    )
    return matches >= 2


def _is_credit_shortfall_failure(text):
    tail = str(text or "")[-12000:]
    direct = re.search(r"(?:will\s+use|requires?|needs?)\s*(\d+)\s*(?:video\s+)?credits?[^\n]{0,120}?"
                       r"(?:only\s+have|have\s+only)\s*(\d+)\s*(?:credits?|left|remaining)", tail, re.I)
    if direct:
        return int(direct.group(1)) > int(direct.group(2)) and int(direct.group(2)) <= 2
    required = _extract_consumed_credits(tail)
    remaining = _extract_latest_quota(tail)
    return bool(
        required is not None
        and remaining is not None
        and required > remaining
        and _CREDIT_SHORTFALL_FAILURE_TEXT.search(tail)
    )


def _is_credit_receipt_error(text):
    """Match Dola's parameter-error reply, which needs one retry first."""
    tail = str(text or "")[-12000:]
    required = _extract_consumed_credits(tail)
    remaining = _extract_latest_quota(tail)
    direct = re.search(
        r"(?:will\s+use|requires?|needs?)\s*(\d+)\s*(?:video\s+)?credits?[^\n]{0,120}?"
        r"(?:only\s+have|have\s+only)\s*(\d+)\s*(?:credits?|left|remaining)",
        tail,
        re.I,
    )
    if direct:
        required = int(direct.group(1))
        remaining = int(direct.group(2))
    if required is None or remaining is None or required <= remaining:
        return False
    has_parameter_context = re.search(
        r"current\s+parameters|本次视频生成|生成参数|无法生成|cannot\s+generate|"
        r"unable\s+to\s+generate",
        tail,
        re.I,
    )
    has_change_advice = re.search(
        r"change.{0,40}(?:parameters?|settings?)|"
        r"(?:lower|reduce).{0,40}(?:parameters?|settings?)|"
        r"请尝试降低|修改参数|更改参数",
        tail,
        re.I,
    )
    return bool(has_parameter_context and has_change_advice)


def _requires_plan_choice(text):
    source = str(text or "")
    return bool(re.search(
        r"(?:你|您)?(?:回复|回答|选择|选)[\s：:]*(?:方案[\s：:]*)?"
        r"[AaＡａ１1][\s]*(?:或(?:者)?|/|／|、|和|还是)[\s]*(?:方案[\s：:]*)?[BbＢｂ２2]"
        r"|(?:请|需要你|需要您)[^。！？\n]{0,35}(?:选择|确认)[^。！？\n]{0,25}(?:方案|选项)"
        r"|(?:reply|choose|select|pick)\s+(?:with\s+)?(?:option\s+)?A\s*(?:or|/|and)\s*(?:option\s+)?B"
        r"|(?:please\s+)?(?:choose|select|pick)\s+(?:option\s+)?(?:A|B)\b[\s\S]{0,120}"
        r"(?:option\s+)?(?:A|B)\b"
        r"|\b(?:option\s+)?A\b[\s\S]{0,100}\b(?:option\s+)?B\b[\s\S]{0,80}"
        r"\b(?:reply|respond|choose|select|pick)\b",
        source, re.I,
    ))


def _is_english_status_text(text):
    source = str(text or "")
    words = re.findall(r"\b[A-Za-z]{2,}\b", source)
    han = len(re.findall(r"[\u4e00-\u9fff]", source))
    letters = sum(map(len, words))
    return (han == 0 and letters >= 3) or (len(words) >= 4 and letters > han * 1.5)


def _classify_response(text, model="Seedance 2.5"):
    tail = str(text or "")[-12000:]
    if _LOGIN_TEXT.search(tail):
        return "logged_out"
    if _DAILY_LIMIT_TEXT.search(re.sub(r"[\u200b-\u200d\ufeff]", "", tail)):
        return "daily_limit"
    if _is_credit_receipt_error(tail):
        return "credit_receipt_error"
    if _is_credit_shortfall_failure(tail):
        return "quota_shortfall"
    if _INSUFFICIENT_TEXT.search(tail):
        return "new_chat"
    if _video_generation_failed_marker_count(tail) > 0:
        return "new_chat"
    if _is_prompt_policy_warning(tail):
        return "prompt_policy_warning"
    # Explicit policy/failure replies take precedence over an earlier
    # optimistic wait estimate in the same streaming assistant response.
    if _MANUAL_TEXT.search(tail):
        return "new_chat"
    if _PORTRAIT_PROTECTION_TEXT.search(tail):
        return "portrait_retry"
    if _TRANSIENT_FACE_TEXT.search(tail):
        return "new_chat"
    if _NON_SUCCESS_RESPONSE.search(tail):
        return "new_chat"
    if _VIDEO_DISPLAY_BLOCKED_RESPONSE.search(tail):
        return "new_chat"
    # Dola may first explain that only 4-15 seconds are supported, then
    # automatically shorten the request and accept it. A complete receipt
    # (cost + estimated wait + remaining balance) proves the task was queued,
    # so the earlier duration explanation must not be treated as a rejection.
    if (
        _SUCCESS_CREDIT.search(tail)
        and _SUCCESS_WAIT.search(tail)
        and _extract_latest_quota(tail) is not None
    ):
        return "submitted"
    # Check confirmation wording only after a complete receipt. The submitted
    # user prompt can itself say "不要回复、不要确认" and Dola may echo that text
    # above the assistant receipt; it must never override a concrete queued
    # receipt with cost, waiting time and remaining balance.
    if _requires_plan_choice(tail) or _CONFIRMATION_TEXT.search(tail):
        return "new_chat"
    # Some Dola builds first stream an English dispatch sentence such as
    # "Only two videos ... I'll start by generating ...", then append the
    # normal Chinese credit receipt a few seconds later.  The leading limit
    # explanation also matches _NEW_CHAT_TEXT, but the explicit "I'll start"
    # commitment proves this is an in-progress successful submission.  Keep
    # observing the same reply instead of opening a duplicate conversation.
    if _ENGLISH_DISPATCH_RECEIPT.search(tail):
        return "submitted"
    if _NEW_CHAT_TEXT.search(tail):
        return "new_chat"
    # Normal bilingual dispatch rule: an explicit generation statement plus a
    # numeric remaining quota is always accepted. Some English Dola variants
    # omit quota numbers but explicitly commit to start/queue the video; those
    # strong receipts are accepted after all rejection/confirmation checks.
    if _STRICT_GENERATE_VIDEO.search(tail) and _extract_latest_quota(tail) is not None:
        return "submitted"
    return "pending"


def _english_status_explanation(text, state):
    """Translate recognized status meanings locally, without sending prompts out."""
    source = str(text or "")
    if not _is_english_status_text(source):
        return ""
    if _CONTENT_RESTRICTION_FAILED_TEXT.search(source):
        return "生成内容涉及版权限制，需要更换输入内容后重试"
    if _EXPLICIT_GENERATION_FAILED_TEXT.search(source):
        return "视频生成失败，停止等待并在当前账号新建对话重试"
    if _INSUFFICIENT_TEXT.search(source):
        return "回复提示可用生成额度不足，按额度规则处理"
    return {
        "submitted": "任务已提交生成，继续等待，不重复提交",
        "logged_out": "账号已退出登录",
        "portrait_retry": "视频生成受到肖像保护限制",
        "prompt_policy_warning": "提示词触发内容规范提醒",
        "credit_receipt_error": "额度回执与生成结果矛盾，本次未成功生成",
        "new_chat": "本次未成功进入生成，按当前账号的新对话重试规则处理",
    }.get(state, "")


def _new_text_since(baseline, current):
    before = str(baseline or "")
    after = str(current or "")
    if not before:
        return after
    if after == before:
        return ""
    if after.startswith(before):
        return after[len(before):]
    before_lines = before.splitlines()
    after_lines = after.splitlines()
    matcher = difflib.SequenceMatcher(None, before_lines, after_lines, autojunk=False)
    added = []
    for operation, _left_start, _left_end, right_start, right_end in matcher.get_opcodes():
        if operation in {"insert", "replace"}:
            added.extend(after_lines[right_start:right_end])
    return "\n".join(added)


def _without_submitted_prompt(value, submitted_prompt):
    """Remove the just-sent user message before classifying Dola's reply."""
    source = _normalized_task_text(value)
    prompt = _normalized_task_text(submitted_prompt)
    if not source or not prompt:
        return source
    position = source.find(prompt)
    if position < 0:
        return source
    return (source[:position] + " " + source[position + len(prompt):]).strip()


def _success_receipt_counts(value):
    """Count strict receipt signals so old replies cannot satisfy a new task."""
    source = str(value or "")
    quota_count = sum(
        len(pattern.findall(source)) for pattern in _QUOTA_PATTERNS
    )
    return (
        len(_SUCCESS_CREDIT.findall(source)),
        len(_SUCCESS_WAIT.findall(source)),
        quota_count,
    )


def _wait_submission_result(
    page,
    params,
    progress_callback,
    baseline_text="",
    account_index=None,
    submitted_prompt="",
):
    deadline = _active_wait_clock() + params["submit_timeout"]
    last_state = "pending"
    submitted_seen_at = None
    response_stable_since = _active_wait_clock()
    last_response_text = ""
    last_status_explanation = ""
    negative_state = None
    negative_seen_at = None
    baseline_receipt_counts = _success_receipt_counts(baseline_text)
    while True:
        _check_stopped()
        _dismiss_rename_dialog(page)
        now = _active_wait_clock()
        text = _page_text(page)
        if _page_is_explicitly_logged_out(page):
            raise LoginExpired("账号在提交过程中退出登录")
        access = _classify_page_access(text, page.locator('[role="textbox"]').count() > 0)
        if access == "region":
            raise RegionUnavailable("Dola 返回“当前地区不可用”，请更换全局/TUN VPN节点")
        response_text = _without_submitted_prompt(
            _new_text_since(baseline_text, text),
            submitted_prompt,
        )
        if response_text != last_response_text:
            last_response_text = response_text
            response_stable_since = _active_wait_clock()
        state = _classify_response(
            response_text,
            params.get("model") or "Seedance 2.5",
        )
        is_plan_choice = state == "new_chat" and _requires_plan_choice(response_text)
        is_confirmation = state == "new_chat" and bool(_CONFIRMATION_TEXT.search(response_text))
        if is_plan_choice:
            explanation = (
                "Dola 正在等待选择方案，尚未确认开始生成；不自动选择压缩或拆分方案，"
                "继续保留原对话等待，不重新上传素材。"
            )
        elif is_confirmation:
            explanation = (
                "Dola 正在等待确认，尚未出现成功入队回执；"
                "继续保留原对话等待，不重新上传素材。"
            )
        else:
            explanation = _english_status_explanation(response_text, state)
        if explanation and explanation != last_status_explanation:
            prefix = "回复状态：" if is_plan_choice or is_confirmation else "英文状态中文释义："
            _log(prefix + explanation)
            last_status_explanation = explanation
        # Dola's streaming renderer can rewrite the whole response. Fall back
        # only when all three strict receipt signals increased after clicking
        # send; never classify old page history or the user's prompt as a new
        # assistant rejection.
        if state == "pending":
            current_receipt_counts = _success_receipt_counts(text)
            if all(
                current > baseline
                for current, baseline in zip(
                    current_receipt_counts, baseline_receipt_counts
                )
            ):
                state = "submitted"
        if state == "logged_out":
            raise LoginExpired("账号在提交过程中退出登录")
        if state in {
            "new_chat",
            "portrait_retry",
            "prompt_policy_warning",
            "credit_receipt_error",
            "daily_limit",
            "quota_shortfall",
        }:
            if negative_state != state:
                negative_state = state
                negative_seen_at = _active_wait_clock()
            # Let a streaming reply finish before abandoning this chat. This
            # prevents a partial explanation from winning just before Dola
            # appends the valid queued receipt.
            if (
                _active_wait_clock() - negative_seen_at >= 6
                and _active_wait_clock() - response_stable_since >= 3
            ):
                # A plan-choice reply is an explicit failure branch: open a
                # fresh chat instead of silently waiting forever. A normal
                # confirmation still waits for the user's confirmation.
                if state == "new_chat" and is_confirmation:
                    return "submitted_pending"
                return state
        else:
            negative_state = None
            negative_seen_at = None
        # Read and classify the latest reply BEFORE considering the deadline.
        # A failure arriving at the timeout boundary must override old credits.
        if state == "pending" and submitted_seen_at is None and now >= deadline:
            if _is_english_status_text(response_text):
                raise ManualReviewRequired(
                    "英文回复暂时无法确定是否已生成，已停止自动操作以免重复提交。"
                    "请核对原文：" + response_text[:500]
                )
            return "submitted_pending"
        if submitted_seen_at is not None and now >= submitted_seen_at + 60 and negative_state is None:
            return "submitted"
        if state == "pending" and submitted_seen_at is not None:
            # A positive receipt is sticky while the streaming DOM is being
            # rewritten. A later explicit failure above still wins.
            state = "submitted"
        if state == "submitted":
            if submitted_seen_at is None:
                submitted_seen_at = _active_wait_clock()
                _log("已看到生成等待与额度回执，继续观察完整回复，防止随后出现肖像保护提示")
            if (
                _active_wait_clock() - submitted_seen_at >= 30
                and _active_wait_clock() - response_stable_since >= 8
            ):
                return "submitted"
        if state != last_state:
            last_state = state
        prefix = f"账号{account_index} " if account_index is not None else ""
        _progress(progress_callback, f"{prefix}等待入队确认", 18)
        page.wait_for_timeout(1500)


def _verify_dola_duration_before_submit(page,params,account_index):
    binding=getattr(page,'_anne_dola_duration_binding',None)
    if not isinstance(binding,dict):return  # The legacy non-HTTP launcher keeps its original route.
    _check_stopped()
    if (binding.get('account_index')!=account_index or binding.get('duration')!=int(params['duration'])
            or _dola_duration_route(page.url)!=_dola_duration_route(binding.get('page_url'))):
        raise ManualReviewRequired('原任务页面或时长已变化，图文草稿已保留；未发送或自动重提')
    proof=_account_safety_call(page.evaluate,'() => window.__anneDolaDurationHook?.arm?.() || null')
    if (not isinstance(proof,dict) or proof.get('verified') is not True or proof.get('armed') is not True
            or proof.get('duration')!=binding['duration'] or type(proof.get('arm_id')) is not int):
        raise ManualReviewRequired('本账号时长设置已失效，图文草稿已保留；请检查原窗口，未发送或自动重提')
    return proof['arm_id']




def _dola_request_duration(request):
    """Read only the outgoing duration; never log prompts, cookies or headers."""
    try:
        if str(request.method).upper()!='POST':return None
        raw=request.post_data_buffer
        if raw is None:raw=request.post_data
        if raw is None or len(raw)>8*1024*1024:return None
        body=json.loads(raw)
        ability=body.get('chat_ability') if isinstance(body,dict) else None
        if not isinstance(ability,dict):return None
        param=ability.get('ability_param')
        if isinstance(param,str):param=json.loads(param)
        if not isinstance(param,dict) or 'duration' not in param:return None
        duration=param['duration']
        return {'duration':duration if type(duration) in (int,float) and 0<duration<3600 else None}
    except Exception:
        return None


def _send_dola_with_duration_proof(page,composer,params,account_index):
    binding=getattr(page,'_anne_dola_duration_binding',None)
    if not isinstance(binding,dict):
        _click_send(page,composer)
        return  # Preserve the separate legacy launcher path.
    # The page can navigate between setting the duration and sending (new chat,
    # AI Creation, uploads). The manager's hook is bound to the route it saw, so
    # re-bind it to the current route before arming; otherwise it correctly
    # refuses with route_changed and nothing is submitted.
    try:
        current_route=_dola_duration_route(page.url)
        bound_route=_dola_duration_route(binding.get('page_url'))
        if current_route and bound_route and current_route!=bound_route:
            _log(
                f"账号{account_index}页面已切换，重新绑定 {binding.get('duration')} 秒时长后再提交"
            )
            refreshed=_enable_manager_video_duration(
                params,int(binding.get('duration') or 0),account_index,page=page)
            if isinstance(refreshed,dict):
                binding=getattr(page,'_anne_dola_duration_binding',binding)
    except Exception as error:
        _log(f"账号{account_index}提交前重新绑定时长失败：{error}")
    observed=[]
    def capture(request):
        try:
            if request.frame.page is not page:return
            value=_dola_request_duration(request)
            if value is not None:observed.append(value)
        except Exception:pass
    page.on('request',capture)
    try:
        arm_id=_verify_dola_duration_before_submit(page,params,account_index)
        expected=binding['duration']
        _click_send(page,composer)
        deadline=time.monotonic()+12
        receipt=None
        while time.monotonic()<deadline:
            _check_stopped()
            if observed:
                wrong=[item for item in observed if item['duration']!=expected]
                if wrong:
                    actual=wrong[0]['duration']
                    raise ManualReviewRequired(
                        f'账号{account_index}实际出站时长为 {actual} 秒，目标为 {expected} 秒；'
                        '已停止自动流程，请检查原对话；可能已经提交，不自动重发')
                _log(f'账号{account_index}实际出站参数已核对：{expected} 秒（尚待成片时长核验）')
                return
            receipt=_account_safety_call(page.evaluate,
                '(id) => window.__anneDolaDurationHook?.receipt?.(id) || null',arm_id)
            if isinstance(receipt,dict) and receipt.get('status')=='blocked':
                raise ManualReviewRequired(
                    f"账号{account_index}本次时长请求已拦住：{receipt.get('reason') or '无法核验'}；"
                    '请检查原窗口，不自动重发')
            page.wait_for_timeout(100)
        # A real hook receipt is still useful when the embedded browser does not
        # expose a Playwright request event. Keep following the existing task;
        # the downloaded file must pass the independent duration check below.
        if (isinstance(receipt,dict) and receipt.get('arm_id')==arm_id
                and receipt.get('status')=='forwarded' and receipt.get('duration')==expected):
            _log(f'账号{account_index}发送函数已使用 {expected} 秒参数；浏览器未提供独立出站回读，继续跟踪本次任务并核对成片，不重发')
            return
        raise ManualReviewRequired(
            f'账号{account_index}未确认本次 {expected} 秒请求是否生效；'
            '发送按钮已点击，请检查原对话，可能已经提交，不自动重发')
    finally:
        _record_dola_sent_chat(page)
        try:page.remove_listener('request',capture)
        except Exception:pass


def _prepare_and_submit(page, prompt, paths, params, progress_callback, account_index):
    _assert_dola_upload_allowed(page)
    composer = _wait_for_composer(page, 35000)
    _wait_for_video_mode(page, params, progress_callback, account_index)
    _step_pause(page, params)
    composer = _wait_for_composer(page, 15000)
    _progress(
        progress_callback,
        "账号{account} 准备设置 {model} / {duration}秒 / {aspect}（待核验）".format(
            account=account_index,
            model=params.get("model") or "Seedance 2.5",
            duration=params.get("duration") or "30",
            aspect=params.get("aspect_ratio") or "16:9",
        ),
        6,
    )
    _select_video_settings(page, params, account_index)
    submitted_prompt = _submission_prompt(prompt, params)
    _fill_prompt(composer, submitted_prompt)
    _remember_dola_draft(page,paths)
    _step_pause(page, params)
    _progress(progress_callback, f"账号{account_index} 上传并确认 {len(paths)} 张资产", 8)
    try:
        _upload_references(page, paths, params, account_index)
    except UiNotReady:
        raise
    except Exception as error:
        raise UploadNotReady(f"素材上传未完成：{error}") from error
    _progress(progress_callback, f"账号{account_index} 提交视频", 12)
    _assert_dola_draft(page,require_upload=True)
    baseline_text = _page_text(page)
    _send_dola_with_duration_proof(page,composer,params,account_index)
    return _wait_submission_result(
        page,
        params,
        progress_callback,
        baseline_text,
        account_index,
        submitted_prompt,
    )



def _extract_vids(content):
    normalized = html.unescape(html.unescape(str(content or "")))
    normalized = normalized.replace("\\u002F", "/").replace("\\u0026", "&")
    patterns = (
        r'"(?:vid|video_id|video_key|video_vid)"\s*:\s*"(v1[A-Za-z0-9]{20,100})"',
        r"(?:vid|video_id)=((?:v1)[A-Za-z0-9]{20,100})",
    )
    result = []
    for pattern in patterns:
        for value in re.findall(pattern, normalized, re.I):
            if value not in result:
                result.append(value)
    return result


def _react_video_vids(page):
    try:
        values = _account_safety_call(page.evaluate, 
            r"""() => {
              const result = [];
              const add = value => {
                const text = String(value || '');
                const match = text.match(/v1[A-Za-z0-9]{20,100}/);
                if (match && !result.includes(match[0])) result.push(match[0]);
              };
              let seen = new WeakSet();
              let visited = 0;
              const walk = (value, depth) => {
                if (value == null || depth > 10 || visited++ > 50000) return;
                if (typeof value === 'string') {
                  const direct = value.match(/\"(?:vid|video_id|video_key|video_vid)\"\s*:\s*\"(v1[A-Za-z0-9]{20,100})\"/g) || [];
                  direct.forEach(add);
                  return;
                }
                if (typeof value !== 'object' && typeof value !== 'function') return;
                if (seen.has(value)) return;
                seen.add(value);
                let keys;
                try { keys = Object.keys(value).slice(0, 300); } catch (_) { return; }
                for (const key of keys) {
                  let child;
                  try { child = value[key]; } catch (_) { continue; }
                  if (/^(vid|video_?id|video_?key|video_?vid)$/i.test(key)) add(child);
                  walk(child, depth + 1);
                }
              };
              const mediaElements = Array.from(document.querySelectorAll('video,img'))
                .sort((left, right) => {
                  const leftArea = (left.clientWidth || 0) * (left.clientHeight || 0);
                  const rightArea = (right.clientWidth || 0) * (right.clientHeight || 0);
                  return rightArea - leftArea;
                });
              for (const media of mediaElements) {
                // A conversation can contain 30 reference images before the
                // result card. Give every media subtree an independent budget
                // so reference-image React trees cannot exhaust the scan before
                // the completed video poster is reached.
                seen = new WeakSet();
                visited = 0;
                let element = media;
                for (let level = 0; element && level < 15; level++, element = element.parentElement) {
                  for (const key of Object.keys(element)) {
                    if (/^__react(?:Props|Fiber|Container)|react/i.test(key)) {
                      walk(element[key], 0);
                    }
                  }
                }
              }
              return result;
            }"""
        )
    except Exception:
        return []
    return list(dict.fromkeys(str(value) for value in (values or ()) if value))


def _normalize_media_url(value):
    if not isinstance(value, str):
        return None
    value = html.unescape(value).replace("\\u002F", "/").replace("\\/", "/").strip()
    if value.startswith(("http://", "https://")):
        return value
    try:
        padding = "=" * (-len(value) % 4)
        decoded = base64.urlsafe_b64decode((value + padding).encode("ascii")).decode("utf-8")
        if decoded.startswith(("http://", "https://")):
            return decoded
    except Exception:
        pass
    return None


def _number(item, keys):
    for key in keys:
        value = item.get(key) if isinstance(item, dict) else None
        try:
            if value is not None and value != "":
                return float(value)
        except (TypeError, ValueError):
            continue
    return 0.0


def _collect_media_candidates(data):
    candidates = []
    seen = set()
    url_keys = {
        "main_url", "backup_url", "backup_url_1", "play_url", "url", "download_url",
        "no_watermark_url", "original_url", "video_url",
    }

    def priority(path, key):
        joined = ".".join(path).lower()
        if "original_media_info" in joined and key == "main_url":
            return 100
        if "original_media_info" in joined:
            return 92
        if key in {"original_url", "no_watermark_url"}:
            return 86
        if "media_info" in joined:
            return 75
        if "play_info" in joined:
            return 65
        return 50

    def walk(value, path=(), inherited=None):
        inherited = inherited if isinstance(inherited, dict) else {}
        if isinstance(value, dict):
            meta = dict(inherited)
            nested_meta = value.get("meta")
            if isinstance(nested_meta, dict):
                meta.update(nested_meta)
            meta.update({k: v for k, v in value.items() if k not in url_keys and not isinstance(v, (dict, list))})
            for key, raw in value.items():
                if key in url_keys:
                    url = _normalize_media_url(raw)
                    if url and url not in seen:
                        seen.add(url)
                        candidates.append({
                            "url": url,
                            "source": ".".join(path + (key,)),
                            "priority": priority(path, key),
                            "width": _number(meta, ("width", "vwidth", "video_width")),
                            "height": _number(meta, ("height", "vheight", "video_height")),
                            "bitrate": _number(meta, ("bitrate", "real_bitrate", "video_bitrate")),
                            "declared_size": _number(meta, ("size", "file_size", "content_length")),
                        })
                elif isinstance(raw, (dict, list, tuple)):
                    walk(raw, path + (str(key),), meta)
        elif isinstance(value, (list, tuple)):
            for index, item in enumerate(value):
                walk(item, path + (str(index),), inherited)

    walk(data, ("data",), {})
    return candidates


def _react_video_models(page):
    try:
        values = _account_safety_call(page.evaluate, 
            r"""() => {
              const result = [];
              const seenIds = new Set();
              let seen = new WeakSet();
              let visited = 0;
              const walk = (value, depth) => {
                if (value == null || depth > 10 || visited++ > 50000) return;
                if (typeof value !== 'object' && typeof value !== 'function') return;
                if (seen.has(value)) return;
                seen.add(value);
                let keys;
                try { keys = Object.keys(value).slice(0, 300); } catch (_) { return; }
                for (const key of keys) {
                  let child;
                  try { child = value[key]; } catch (_) { continue; }
                  if (key === 'videoModel' && typeof child === 'string') {
                    try {
                      const parsed = JSON.parse(child);
                      const id = String(parsed?.video_id || '');
                      if (id && !seenIds.has(id)) {
                        seenIds.add(id);
                        result.push(parsed);
                      }
                    } catch (_) {}
                  }
                  walk(child, depth + 1);
                }
              };
              // A completed Dola card initially renders as a poster image. Its
              // videoModel lives in the surrounding React props even before a
              // <video> element is created by clicking the card.
              const mediaElements = Array.from(document.querySelectorAll('video,img'))
                .sort((left, right) => {
                  const leftArea = (left.clientWidth || 0) * (left.clientHeight || 0);
                  const rightArea = (right.clientWidth || 0) * (right.clientHeight || 0);
                  return rightArea - leftArea;
                });
              for (const media of mediaElements) {
                seen = new WeakSet();
                visited = 0;
                let element = media;
                for (let level = 0; element && level < 15; level++, element = element.parentElement) {
                  for (const key of Object.keys(element)) {
                    if (/^__react(?:Props|Fiber|Container)|react/i.test(key)) {
                      walk(element[key], 0);
                    }
                  }
                }
              }
              return result;
            }"""
        )
    except Exception:
        return []
    return [value for value in (values or ()) if isinstance(value, dict)]


def _current_result_video_models(page):
    """Read only the newest rendered result card, without sibling React fibers.

    The September desktop block renderer has no More/share menu. Its card
    already contains signed unwatermarked URLs in videoModel. A walk through
    fibers or a whole conversation can find a previous job's video instead.
    """
    try:
        values = _account_safety_call(page.evaluate, r"""() => {
          const selector = '[class*="video-hover-button-group-container"], [class*="block-video-"], video';
          const messages = [...document.querySelectorAll('[data-testid="receive_message"]')];
          const message = messages.filter(el => el.querySelector(selector)).at(-1);
          if (!message) return [];
          const media = [...message.querySelectorAll(selector)].at(-1);
          const result = [], ids = new Set();
          const walkRoot = value => {
            const seen = new WeakSet(); let visited = 0;
            const walk = (item, depth) => {
              if (!item || typeof item !== 'object' || item instanceof Node ||
                  depth > 8 || visited++ > 8000 || seen.has(item)) return;
              seen.add(item);
              for (const key of Object.keys(item)) {
                if (['_owner', 'return', 'child', 'sibling', 'alternate'].includes(key)) continue;
                let child; try { child = item[key]; } catch (_) { continue; }
                if (key === 'videoModel' || key === 'video_model') {
                  try {
                    const model = typeof child === 'string' ? JSON.parse(child) : child;
                    const id = String(model?.video_id || '');
                    if (id && model.video_list && !ids.has(id)) {
                      ids.add(id); result.push(model);
                    }
                  } catch (_) {}
                } else walk(child, depth + 1);
              }
            };
            walk(value, 0);
          };
          for (let el = media; el; el = el.parentElement) {
            for (const key of Object.keys(el)) {
              if (key.startsWith('__reactProps')) walkRoot(el[key]);
            }
            if (el === message) break;
          }
          return result;
        }""")
    except Exception:
        return []
    return [item for item in values if isinstance(item, dict)] if isinstance(values, list) else []


def _current_card_master_candidates(page, excluded_vids=()):
    """Resolve original high-bitrate variants from the exact rendered card."""
    excluded = set(excluded_vids or ())
    models = [m for m in _current_result_video_models(page)
              if str(m.get("video_id") or "") not in excluded]
    state = _install_media_api_capture(page)
    route = _conversation_route(getattr(page, "url", ""))
    result = []
    for model in models:
        vid = str(model.get("video_id") or "")
        apis = _fallback_api_values(model)
        if not vid or not apis:
            continue
        key = (route, vid)
        cache = state.setdefault("card_masters", {})
        item = cache.get(key, {})
        if item.get("candidates"):
            result.extend(dict(c) for c in item["candidates"])
            continue
        if time.monotonic() < item.get("retry_at", 0):
            continue
        cache[key] = {"retry_at": time.monotonic() + 15}
        try:
            payload = _manager_api_request("/resolve_video_master", method="POST",
                data={"video_id": vid, "fallback_apis": apis}, timeout=55)
            if _conversation_route(getattr(page, "url", "")) != route:
                return []
            candidates = _manager_master_candidates(payload) if payload.get("success") else []
        except GenerationStopped:
            raise
        except Exception as error:
            _log(f"当前卡片高码率解析待重试（{type(error).__name__}）；保留原任务，不采用低码率预览")
            continue
        for candidate in candidates:
            candidate["video_id"] = vid
            candidate["source"] = "current_video_card.highest_bitrate_master"
        if candidates:
            cache[key] = {"candidates": [dict(c) for c in candidates]}
            result.extend(candidates)
    return _merge_candidates(result)


def _react_media_candidates(page, vid):
    result = []
    seen = set()
    for model in _react_video_models(page):
        if str(model.get("video_id") or "") != str(vid):
            continue
        for candidate in _collect_media_candidates(model):
            candidate = dict(candidate)
            candidate["url"] = (
                _request_no_watermark_variant(candidate["url"])
                or candidate["url"]
            )
            if candidate["url"] in seen:
                continue
            seen.add(candidate["url"])
            split = urllib.parse.urlsplit(candidate["url"])
            query = dict(urllib.parse.parse_qsl(split.query, keep_blank_values=True))
            is_unwatermarked = str(query.get("lr") or "").lower() == "unwatermarked"
            suffix = "unwatermarked_master" if is_unwatermarked else "internal"
            candidate["source"] = (
                f"local_video_card.{suffix}.{candidate['source']}"
            )
            candidate["priority"] = max(
                96 if is_unwatermarked else 60,
                int(candidate.get("priority", 0)),
            )
            result.append(candidate)
    return result


def _decode_qaab_items(items, params):
    if not items:
        return []
    manager_root, launcher = _manager_paths(params)
    if not launcher.is_file():
        return [None] * len(items)
    if _manager_uses_local_api(manager_root, launcher):
        # launcher_vNNN exposes account/video controls through localhost but
        # does not implement the command-line QAAB decoder contract.
        return [None] * len(items)
    stamp = f"{os.getpid()}_{threading.get_ident()}_{time.time_ns()}"
    input_path = Path(tempfile.gettempdir()) / f"zizi_dola_qaab_in_{stamp}.json"
    output_path = Path(tempfile.gettempdir()) / f"zizi_dola_qaab_out_{stamp}.json"
    creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        with input_path.open("w", encoding="utf-8") as file:
            json.dump({"items": items}, file, ensure_ascii=False)
        completed = subprocess.run(
            [str(launcher), "--decode-dola-qaab", str(input_path), str(output_path)],
            cwd=str(manager_root),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=60,
            creationflags=creation_flags,
            check=False,
        )
        if completed.returncode != 0 or not output_path.is_file():
            return [None] * len(items)
        with output_path.open("r", encoding="utf-8") as file:
            result = json.load(file)
        rows = result.get("items") if isinstance(result, dict) else None
        if not isinstance(rows, list):
            return [None] * len(items)
        return [
            row.get("url") if isinstance(row, dict) and row.get("success") else None
            for row in rows
        ]
    except Exception:
        return [None] * len(items)
    finally:
        for path in (input_path, output_path):
            try:
                path.unlink()
            except OSError:
                pass


def _fallback_api_values(value):
    result = []

    def walk(current, depth=0):
        if depth > 12:
            return
        if isinstance(current, dict):
            for key, child in current.items():
                if str(key).lower() == "fallback_api" and isinstance(child, str):
                    url = html.unescape(child).replace("\\u002F", "/").replace("\\/", "/").strip()
                    if url.startswith(("http://", "https://")):
                        result.append(url)
                elif isinstance(child, (dict, list, tuple)):
                    walk(child, depth + 1)
        elif isinstance(current, (list, tuple)):
            for child in current:
                walk(child, depth + 1)

    walk(value)
    return list(dict.fromkeys(result))


def _install_media_api_capture(page, reset=False):
    """Capture Dola's current dynamic mother-video APIs as they are loaded."""
    state = getattr(page, "_dola_media_api_capture", None)
    if not isinstance(state, dict):
        state = {
            "fplay_urls": [],
            "fallback_urls": [],
            "fplay_payloads": [],
        }
        setattr(page, "_dola_media_api_capture", state)

        # Best-effort lifecycle hints do not guarantee animation frames while
        # the native window is minimized. Media controls below must work without
        # Playwright's frame-based pointer actionability checks as well.
        try:
            background_session = page.context.new_cdp_session(page)
            state["background_session"] = background_session
        except Exception:
            background_session = None
        if background_session is not None:
            for method, arguments in (
                ("Page.setWebLifecycleState", {"state": "active"}),
                ("Emulation.setFocusEmulationEnabled", {"enabled": True}),
            ):
                try:
                    background_session.send(method, arguments)
                except Exception as error:
                    # Some Dola builds implement only one of these commands.
                    # A failed lifecycle hint must not skip focus emulation.
                    state.setdefault("background_errors", {})[method] = type(error).__name__

        def remember(values, key):
            target = state[key]
            for value in values or ():
                value = str(value or "").strip()
                if value.startswith(("http://", "https://")) and value not in target:
                    target.append(value)

        def remember_fplay_payload(response_url, payload):
            """Keep the response that the signed-in Dola window received.

            Re-requesting the same API from Python can leave the browser/VPN
            route and incorrectly return a country/region error.  The page's
            original response is authoritative because that is the response
            which rendered the playable video card.
            """
            if not isinstance(payload, dict):
                return
            video_info = payload.get("video_info")
            data = video_info.get("data") if isinstance(video_info, dict) else None
            if not isinstance(data, dict):
                return
            target = state["fplay_payloads"]
            if any(item.get("url") == response_url for item in target):
                return
            target.append({"url": response_url, "payload": payload})
            if len(target) > 20:
                del target[:-20]

        def capture_response(response):
            response_url = str(getattr(response, "url", "") or "")
            lowered = response_url.lower()
            if "/video/fplay/" in lowered:
                remember((response_url,), "fplay_urls")
                try:
                    remember_fplay_payload(response_url, response.json())
                except Exception:
                    pass
            if "/im/message/share/get" not in lowered:
                return
            try:
                remember(_fallback_api_values(response.json()), "fallback_urls")
            except Exception:
                try:
                    body = response.text()
                except Exception:
                    return
                normalized = html.unescape(body).replace("\\u002F", "/").replace("\\/", "/")
                remember(
                    re.findall(
                        r'''fallback_api\s*["']?\s*[:=]\s*["']?(https?://[^"'\s\\<>]+)''',
                        normalized,
                        re.I,
                    ),
                    "fallback_urls",
                )

        page.on("response", capture_response)
    if reset:
        state["fplay_urls"].clear()
        state["fallback_urls"].clear()
        state.setdefault("fplay_payloads", []).clear()
        state.pop("share_url", None)
        state.pop("share_chat_route", None)
        state.pop("share_candidates", None)
        state.pop("share_attempted_at", None)
        state.pop("share_failure_notice", None)
        for key in ("share_retry_at", "share_failures", "media_retry", "direct_media_retry_at", "fplay_cached_signature", "fplay_cached_candidates", "fplay_decode_retry_at"):
            state.pop(key, None)
    return state


def _captured_fplay_payloads(page):
    """Return successful fplay bodies received by the logged-in Dola page."""
    state = _install_media_api_capture(page)
    return [
        dict(item)
        for item in state.get("fplay_payloads") or ()
        if isinstance(item, dict) and isinstance(item.get("payload"), dict)
    ]


def _captured_fplay_urls(page):
    """Return live fplay/fallback URLs, including requests made before a listener ran."""
    state = _install_media_api_capture(page)
    result = list(state.get("fplay_urls") or ())
    result.extend(state.get("fallback_urls") or ())
    try:
        resources = _account_safety_call(page.evaluate, 
            """() => performance.getEntriesByType('resource')
              .map(entry => String(entry.name || ''))
              .filter(url => url.includes('/video/fplay/'))"""
        )
        result.extend(resources or ())
    except Exception:
        pass
    return list(
        dict.fromkeys(
            str(value or "").strip()
            for value in result
            if str(value or "").startswith(("http://", "https://"))
        )
    )


def _valid_dola_share_url(value):
    value = str(value or "").strip()
    try:
        split = urllib.parse.urlsplit(value)
    except Exception:
        return None
    hostname = (split.hostname or "").lower()
    if (
        split.scheme not in {"http", "https"}
        or (hostname != "dola.com" and not hostname.endswith(".dola.com"))
        or not split.path.startswith("/thread/")
    ):
        return None
    return value


def _click_media_control_without_frames(locator):
    """Dispatch a media control's DOM events without waiting for painted frames.

    Native minimization can stop requestAnimationFrame even though DOM scripts
    and network responses still run. locator.click(), including its stability
    wait, is therefore unsuitable for acquiring a background download URL.
    The role locator still scopes this to the existing, enabled Dola control.
    """
    return bool(locator.evaluate_all(
        """elements => {
          const eligible = elements.filter(el => {
            if (!el.isConnected || el.matches(':disabled') ||
                el.closest('[aria-disabled="true"], [data-disabled]')) return false;
            const menu = el.closest('[role="menu"]');
            if (!menu) return true;
            const state = menu.getAttribute('data-state');
            if (state === 'closed' || menu.hidden) return false;
            // Radix/Popper hides open menus when the anchor is clipped. The
            // current share action remains mounted and works without paint.
            if (state === 'open') return true;
            // Older menus lack data-state. Do not click their retained hidden
            // copies: only the explicitly open Radix menu gets this exception.
            for (let node = el; node; node = node.parentElement) {
              const style = getComputedStyle(node);
              if (node.hidden || style.display === 'none' ||
                  style.visibility === 'hidden') return false;
            }
            return true;
          });
          const el = eligible[eligible.length - 1];
          if (!el) return false;
          const rect = el.getBoundingClientRect();
          const init = {bubbles: true, cancelable: true, composed: true,
            view: window, button: 0, clientX: rect.x + rect.width / 2,
            clientY: rect.y + rect.height / 2};
          // Support both pointer-down menu triggers and ordinary click handlers.
          el.dispatchEvent(new PointerEvent('pointerdown', {...init,
            pointerId: 1, pointerType: 'mouse', isPrimary: true, buttons: 1}));
          el.dispatchEvent(new MouseEvent('mousedown', {...init, buttons: 1}));
          el.dispatchEvent(new PointerEvent('pointerup', {...init,
            pointerId: 1, pointerType: 'mouse', isPrimary: true, buttons: 0}));
          el.dispatchEvent(new MouseEvent('mouseup', {...init, buttons: 0}));
          el.click();
          return true;
        }"""
    ))


def _clear_other_chat_share_cache(page, state):
    route = _conversation_route(getattr(page, "url", ""))
    if state.get("share_chat_route") != route:
        for key in ("share_url", "share_candidates", "share_retry_at", "share_failures"):
            state.pop(key, None)
        state["share_chat_route"] = route
    return route


def _log_share_acquisition_failure(page, state, stage):
    now = time.monotonic()
    previous = state.get("share_failure_notice") or {}
    if previous.get("stage") == stage and now < previous.get("next_at", 0):
        return
    state["share_failure_notice"] = {"stage": stage, "next_at": now + 30}
    try:
        visibility = _account_safety_call(page.evaluate, "document.visibilityState")
    except Exception:
        visibility = "unknown"
    menu_detail = ""
    try:
        controls = page.get_by_role(
            "button", name=re.compile(r"^(?:更多|More)$", re.I)
        ).evaluate_all("""elements => ({
          count: elements.length,
          expanded: elements.filter(el => el.getAttribute('aria-expanded') === 'true').length
        })""")
        menus = page.get_by_role(
            "menuitem", name=re.compile(r"(?:复制分享链接|Copy share link)", re.I),
            include_hidden=True,
        ).evaluate_all("""elements => ({
          count: elements.length,
          open: elements.filter(el => el.closest('[role="menu"][data-state="open"]')).length
        })""")
        menu_detail = (
            f"；更多按钮 {controls['count']} 个/展开 {controls['expanded']} 个，"
            f"分享菜单项 {menus['count']} 个/已打开 {menus['open']} 个"
        )
    except Exception:
        pass
    _log(
        f"后台取址尚未完成：{stage}（页面状态：{visibility}{menu_detail}）；"
        "保留当前任务重试，不重新生成"
    )


def _copy_current_share_url(page, timeout_ms=8000):
    """Acquire this chat's share response without painted frames or clipboard."""
    _check_stopped()
    state = _install_media_api_capture(page)
    chat_route = _clear_other_chat_share_cache(page, state)
    cached = _valid_dola_share_url(state.get("share_url"))
    if cached:
        return cached

    responses = []

    def capture_share_response(response):
        if "/im/message/share/save" in str(response.url).lower():
            responses.append(response)

    more_clicked = False
    share_clicked = False
    clipboard_write = None
    stage = "未找到当前视频的更多按钮"
    deadline = time.monotonic() + max(1, timeout_ms) / 1000
    # Install before dispatching the menu events: the save response may return
    # during evaluate_all itself. Poll in Python so no page rAF is needed.
    page.on("response", capture_share_response)
    try:
        # Some builds reuse a share in page memory and only write its URL,
        # without another /share/save response. Observe the value THIS action
        # writes; never read the shared system clipboard or change permissions.
        # The original write still runs (and may reject while minimized).
        clipboard_write = _account_safety_call(page.evaluate_handle, 
            """() => {
              const capture = {value: '', restore() {}};
              try {
                const clipboard = navigator.clipboard;
                const original = clipboard.writeText;
                const descriptor = Object.getOwnPropertyDescriptor(clipboard, 'writeText');
                const replacement = function(value) {
                  capture.value = String(value || '');
                  return original.call(this, value);
                };
                Object.defineProperty(clipboard, 'writeText', {
                  configurable: true, writable: true, value: replacement
                });
                capture.restore = () => {
                  if (clipboard.writeText !== replacement) return;
                  if (descriptor) Object.defineProperty(clipboard, 'writeText', descriptor);
                  else delete clipboard.writeText;
                };
              } catch (_) {}
              return capture;
            }"""
        )
        more = page.get_by_role(
            "button", name=re.compile(r"^(?:更多|More)$", re.I)
        )
        share = page.get_by_role(
            "menuitem", name=re.compile(r"(?:复制分享链接|Copy share link)", re.I),
            include_hidden=True,
        )
        while time.monotonic() < deadline:
            _check_stopped()
            if _conversation_route(getattr(page, "url", "")) != chat_route:
                stage = "取址期间当前对话发生变化，已丢弃本轮结果"
                break
            if responses:
                response = responses.pop(0)
                payload = response.json()
                data = payload.get("data") if isinstance(payload, dict) else None
                share_url = (
                    _valid_dola_share_url(data.get("share_url"))
                    if isinstance(data, dict) else None
                )
                if (
                    share_url and payload.get("code") in (0, "0", None)
                    and _conversation_route(getattr(page, "url", "")) == chat_route
                ):
                    state["share_url"] = share_url
                    state["share_chat_route"] = chat_route
                    state.pop("share_failure_notice", None)
                    return share_url
                stage = "分享接口已返回，但未取得当前对话的有效地址"
                break
            if share_clicked:
                share_url = _valid_dola_share_url(
                    _account_safety_call(clipboard_write.evaluate, "capture => capture.value")
                )
                if (
                    share_url
                    and _conversation_route(getattr(page, "url", "")) == chat_route
                ):
                    state["share_url"] = share_url
                    state["share_chat_route"] = chat_route
                    state.pop("share_failure_notice", None)
                    return share_url
            if not share_clicked:
                # A previous attempt may have left the menu open. Consume its
                # share item before toggling More, and click each control once.
                if _click_media_control_without_frames(share):
                    share_clicked = True
                    stage = "已触发复制分享链接，等待分享接口响应"
                elif not more_clicked and _click_media_control_without_frames(more):
                    more_clicked = True
                    stage = "已发送更多按钮事件，尚未取得可用的分享菜单项"
            remaining_ms = (deadline - time.monotonic()) * 1000
            if remaining_ms > 0:
                page.wait_for_timeout(min(150, remaining_ms))
    except GenerationStopped:
        raise
    except Exception as error:
        stage = f"{stage}，操作异常：{type(error).__name__}"
    finally:
        page.remove_listener("response", capture_share_response)
        if clipboard_write is not None:
            try:
                # Always undo our temporary clipboard hook, including after a
                # safety halt. This is cleanup, not a click or new task action.
                clipboard_write.evaluate("capture => capture.restore()")
            except Exception:
                pass  # Navigation destroys the old clipboard and its wrapper.
            finally:
                try:
                    clipboard_write.dispose()
                except Exception:
                    pass
    # Never read the global clipboard here: another account (or the user) may
    # have replaced it, and minimized pages can be denied clipboard access.
    _log_share_acquisition_failure(page, state, stage)
    return None


def _share_template_media_candidates(page):
    """Resolve the current master without invoking the manager's popup fallback."""
    state = _install_media_api_capture(page)
    chat_route = _clear_other_chat_share_cache(page, state)
    cached = state.get("share_candidates")
    if isinstance(cached, list) and cached:
        return [dict(item) for item in cached]
    if time.monotonic() < float(state.get("share_retry_at") or 0):
        return []
    failures = min(4, int(state.get("share_failures") or 0) + 1)
    state["share_failures"] = failures
    state["share_retry_at"] = time.monotonic() + min(20, 3 * 2 ** (failures - 1))

    share_url = _copy_current_share_url(page)
    if not share_url:
        return []
    # Only forward APIs captured for this task since the capture was reset.
    # Do not scan another account or create a new browser page.
    live_apis = list(state.get("fallback_urls") or ()) + list(state.get("fplay_urls") or ())
    for model in _react_video_models(page):
        live_apis.extend(_fallback_api_values(model))
    live_apis = list(dict.fromkeys(str(value) for value in live_apis if value))
    _check_stopped()
    try:
        payload = _manager_api_request(
            "/resolve_video_master",
            method="POST",
            data={"url": share_url, "fallback_apis": live_apis},
            timeout=55,
        )
    except urllib.error.HTTPError as error:
        if error.code == 404:
            if not state.get("background_resolver_missing_logged"):
                _log(
                    "多开器尚未加载后台母版解析通道，请同步更新 launcher_core.py 后重启多开器；"
                    "当前继续从原视频卡片读取地址，不调用会弹窗的旧通道"
                )
                state["background_resolver_missing_logged"] = True
        else:
            _log(f"后台母版解析暂不可用（HTTP {error.code}），保留当前任务重试")
        return []
    except Exception as error:
        _log(f"后台母版解析连接暂不可用：{type(error).__name__}，保留当前任务重试，不新开窗口")
        return []
    _check_stopped()
    if _conversation_route(getattr(page, "url", "")) != chat_route:
        return []
    if not payload.get("success"):
        _log(
            "当前对话分享母版解析失败："
            f"{payload.get('error') or payload.get('message') or '未知错误'}"
        )
        return []

    candidates = _manager_master_candidates(payload)
    if candidates:
        state["share_failures"] = 0
        state["share_candidates"] = [dict(item) for item in candidates]
        known_sizes = [
            int(item.get("declared_size") or 0) for item in candidates
            if int(item.get("declared_size") or 0) > 0
        ]
        size_mb = max(known_sizes) / (1024 * 1024) if known_sizes else 0
        detail = f"，最大母版约 {size_mb:.2f}MB" if size_mb else ""
        _log(
            f"后台母版解析完成，捕获 {len(candidates)} 个最高码率无水印地址"
            f"{detail}；已取得地址，开始下载验证"
        )
    return candidates


def _manager_master_candidates(payload):
    routes = payload.get("urls")
    if not isinstance(routes, list):
        routes = [payload.get("url")] if payload.get("url") else []
    media_sizes = {
        str(item.get("url") or ""): item.get("size")
        for item in (payload.get("media") or [])
        if isinstance(item, dict)
    }
    candidates = []
    seen = set()
    for route in routes:
        _check_stopped()
        route = str(route or "").strip()
        if not route:
            continue
        candidate_url = route
        direct_url = route
        manager_proxy = False
        try:
            route_split = urllib.parse.urlsplit(route)
            if not route_split.scheme and route.startswith("/"):
                candidate_url = urllib.parse.urljoin(
                    f"{_manager_api_base()}/", route.lstrip("/")
                )
                route_split = urllib.parse.urlsplit(candidate_url)
            manager_proxy = (
                (route_split.hostname or "").lower() in {"127.0.0.1", "localhost"}
                and route_split.scheme == 'http'
                and route_split.port == urllib.parse.urlsplit(_manager_api_base()).port
                and route_split.path.endswith("/download_video")
            )
            if manager_proxy:
                direct_url = (
                    urllib.parse.parse_qs(route_split.query).get("source") or [None]
                )[0]
        except Exception:
            continue
        direct_url = _normalize_media_url(direct_url)
        if not direct_url or candidate_url in seen:
            continue
        try:
            direct_split = urllib.parse.urlsplit(direct_url)
            hostname = (direct_split.hostname or "").lower()
            if hostname != "dola.com" and not hostname.endswith(".dola.com"):
                continue
            query = urllib.parse.parse_qs(direct_split.query)
        except Exception:
            continue
        if str((query.get("lr") or [""])[0]).lower() != "unwatermarked":
            continue
        seen.add(candidate_url)

        try:
            known_size = max(0, int(media_sizes.get(route) or 0))
        except (TypeError, ValueError):
            known_size = 0
        if manager_proxy and not known_size:
            try:
                request = urllib.request.Request(
                    candidate_url,
                    headers={"Range": "bytes=0-0", "Accept": "video/mp4"},
                )
                with _manager_urlopen(request, timeout=5) as response:
                    content_range = str(response.headers.get("Content-Range") or "")
                    matched = re.search(r"/(\d+)\s*$", content_range)
                    if matched:
                        known_size = int(matched.group(1))
                    elif response.status == 200:
                        known_size = int(response.headers.get("Content-Length") or 0)
            except Exception:
                pass
        try:
            # Dola's ``bt`` URL value is the effective video bitrate in Kbps.
            declared_bitrate = float((query.get("bt") or [0])[0]) * 1000
        except (TypeError, ValueError):
            declared_bitrate = 0
        candidates.append(
            {
                # Keep the localhost proxy URL. It downloads through the same
                # manager HTTP/proxy context that resolved the mother file,
                # avoiding a second direct request rejected by region checks.
                "url": candidate_url,
                "source": (
                    "manager_proxy.highest_bitrate_unwatermarked_master"
                    if manager_proxy
                    else "current_share.unwatermarked_template"
                ),
                "priority": 140,
                "width": 0,
                "height": 0,
                "bitrate": declared_bitrate,
                "declared_size": known_size,
            }
        )
    return candidates


def _fplay_url_variants(url):
    try:
        split = urllib.parse.urlsplit(url)
        pairs = urllib.parse.parse_qsl(split.query, keep_blank_values=True)
    except Exception:
        return []
    current = dict(pairs)
    codecs = ["8"]
    existing_codec = str(current.get("codec_type") or "").strip()
    if existing_codec and existing_codec not in codecs:
        codecs.append(existing_codec)
    result = []
    for codec in codecs:
        # Dola's current fplay template uses ``lr=cici_ai_v`` or
        # ``lr=video_gen_watermark_dyn``.  Merely changing logo_type now leaves
        # the old/expiring watermarked route in place, so request the explicit
        # unwatermarked route first.  Keep the former variant as a compatibility
        # fallback for older accounts whose signatures still expect the old lr.
        for force_unwatermarked_lr in (True, False):
            values = dict(current)
            values["codec_type"] = codec
            values["logo_type"] = "unwatermarked"
            values["channel"] = "no"
            if force_unwatermarked_lr:
                values["lr"] = "unwatermarked"
            query = urllib.parse.urlencode(values)
            candidate = urllib.parse.urlunsplit(
                (split.scheme, split.netloc, split.path, query, split.fragment)
            )
            if candidate not in result:
                result.append(candidate)
    return result


def _fplay_payload_candidates(payload_rows, params):
    """Decode already-received bodies before any new network wait."""
    candidates = []
    encrypted = []
    seen_tokens = set()
    for source_prefix, payload in payload_rows:
        video_info = payload.get("video_info") if isinstance(payload, dict) else None
        data = video_info.get("data") if isinstance(video_info, dict) else None
        if not isinstance(data, dict):
            continue
        key_seed = str(data.get("key_seed") or "")
        for candidate in _collect_media_candidates(data):
            candidate = dict(candidate)
            candidate["url"] = (
                _request_no_watermark_variant(candidate["url"])
                or candidate["url"]
            )
            candidate["source"] = f"{source_prefix}.{candidate['source']}"
            candidate["priority"] = max(90, int(candidate.get("priority") or 0))
            candidates.append(candidate)
        video_list = data.get("video_list")
        if not isinstance(video_list, dict) or not key_seed:
            continue
        for video_name, video_item in video_list.items():
            if not isinstance(video_item, dict):
                continue
            for key in ("main_url", "backup_url", "backup_url_1", "play_url", "url"):
                token = video_item.get(key)
                if not isinstance(token, str) or not token.startswith("qAAB") or token in seen_tokens:
                    continue
                seen_tokens.add(token)
                encrypted.append({
                    "token": token,
                    "key_seed": key_seed,
                    "source": f"{source_prefix}.video_list.{video_name}.{key}",
                    "priority": 99 if str(video_item.get("quality") or "").lower() == "original" else 94,
                    "width": _number(video_item, ("vwidth", "width", "video_width")),
                    "height": _number(video_item, ("vheight", "height", "video_height")),
                    "bitrate": _number(video_item, ("real_bitrate", "bitrate", "video_bitrate")),
                    "declared_size": _number(video_item, ("size", "file_size", "content_length")),
                })

    decoded_urls = _decode_qaab_items(
        [
            {"token": item["token"], "key_seed": item["key_seed"]}
            for item in encrypted
        ],
        params,
    )
    for item, url in zip(encrypted, decoded_urls):
        if not url:
            continue
        candidates.append({
            "url": _request_no_watermark_variant(url),
            "source": item["source"],
            "priority": item["priority"],
            "width": item["width"],
            "height": item["height"],
            "bitrate": item["bitrate"],
            "declared_size": item["declared_size"],
        })
    return _merge_candidates(candidates)


def _fplay_media_candidates(page, vid, params):
    api_urls = []
    for model in _react_video_models(page):
        if str(model.get("video_id") or "") != str(vid):
            continue
        for fallback_api in _fallback_api_values(model):
            api_urls.extend(_fplay_url_variants(fallback_api))
    # Since September 2026 Dola no longer reliably keeps fallback_api inside
    # the rendered React model.  The working desktop parser captures the live
    # share/fplay response instead; use the same source here.
    for captured_url in _captured_fplay_urls(page):
        api_urls.extend(_fplay_url_variants(captured_url))
    api_urls = list(dict.fromkeys(api_urls))
    state = _install_media_api_capture(page)
    captured = _captured_fplay_payloads(page)
    signature = json.dumps(captured, sort_keys=True, ensure_ascii=False, default=str)
    if (
        signature != state.get("fplay_cached_signature")
        or (not state.get("fplay_cached_candidates")
            and time.monotonic() >= float(state.get("fplay_decode_retry_at") or 0))
    ):
        state["fplay_cached_signature"] = signature
        state["fplay_decode_retry_at"] = time.monotonic() + 5
        state["fplay_cached_candidates"] = _fplay_payload_candidates(
            [(f"captured_fplay_{number}", item.get("payload"))
             for number, item in enumerate(captured, 1)], params,
        )
    cached = list(state.get("fplay_cached_candidates") or [])
    if any(int(item.get("priority") or 0) >= 99 for item in cached):
        return _merge_candidates(cached)
    if time.monotonic() < float(state.get("direct_media_retry_at") or 0):
        return _merge_candidates(cached)

    payload_rows = []
    deadline = time.monotonic() + 10
    for api_number, api_url in enumerate(api_urls, 1):
        _check_stopped()
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        key = "fplay:" + api_url
        retry = state.get("media_retry", {}).get(key, {})
        if time.monotonic() < float(retry.get("at") or 0):
            continue
        try:
            response = page.context.request.get(
                api_url,
                headers={
                    "Accept": "application/json,text/plain,*/*",
                    "Origin": "https://www.dola.com",
                    "Referer": page.url,
                },
                timeout=max(1, int(min(8, remaining) * 1000)),
            )
            payload = response.json()
            info = payload.get("video_info") if isinstance(payload, dict) else None
            if not isinstance(info, dict) or not isinstance(info.get("data"), dict):
                message = (payload.get("msg") or payload.get("message") or payload.get("code")
                           if isinstance(payload, dict) else None)
                _media_request_failed(state, key, str(message or "母版响应尚未就绪"))
                if time.monotonic() < float(state.get("direct_media_retry_at") or 0):
                    break
                continue
        except Exception as error:
            _media_request_failed(state, key, type(error).__name__)
            continue
        state.setdefault("media_retry", {}).pop(key, None)
        payload_rows.append((f"requested_fplay_{api_number}", payload))
    return _merge_candidates(cached, _fplay_payload_candidates(payload_rows, params))


def _media_request_failed(state, key, error):
    retry = state.setdefault("media_retry", {})
    failures = min(4, int(retry.get(key, {}).get("failures") or 0) + 1)
    delay = min(30, 3 * 2 ** (failures - 1))
    if re.search(r"country|region|地区", str(error), re.I):
        delay = 90
        state["direct_media_retry_at"] = time.monotonic() + delay
    retry[key] = {"at": time.monotonic() + delay, "failures": failures, "error": str(error)}


def _fetch_play_info(page, vid):
    state = _install_media_api_capture(page)
    key = "play_info:" + str(vid)
    retry = state.get("media_retry", {}).get(key, {})
    if time.monotonic() < float(state.get("direct_media_retry_at") or 0):
        return [], "独立播放接口地区限制，暂时跳过并优先读取后台母版"
    if time.monotonic() < float(retry.get("at") or 0):
        return [], str(retry.get("error") or "独立播放接口等待重试")
    _check_stopped()
    endpoint = (
        "https://www.dola.com/samantha/media/get_play_info"
        "?aid=489823&device_platform=web&samantha_web=1"
    )
    try:
        response = page.context.request.post(
            endpoint,
            data={"key": vid, "type": "video"},
            headers={
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Origin": "https://www.dola.com",
                "Referer": "https://www.dola.com/",
            },
            timeout=8000,
        )
        payload = response.json()
    except Exception as error:
        message = f"播放信息接口请求失败：{type(error).__name__}"
        _media_request_failed(state, key, message)
        return [], message
    if not isinstance(payload, dict):
        _media_request_failed(state, key, "播放信息接口未返回JSON")
        return [], "播放信息接口未返回JSON"
    if payload.get("code") not in (0, "0", None):
        message = str(payload.get("msg") or payload.get("message") or payload.get("code"))
        _media_request_failed(state, key, message)
        return [], message
    data = payload.get("data")
    if not isinstance(data, dict):
        _media_request_failed(state, key, "播放信息接口没有data")
        return [], "播放信息接口没有data"
    state.setdefault("media_retry", {}).pop(key, None)
    return _collect_media_candidates(data), None


def _dom_video_candidates(page):
    values = _account_safety_call(page.evaluate, 
        """() => Array.from(document.querySelectorAll('video,video source')).map(el => el.currentSrc || el.src || el.getAttribute('src') || '').filter(Boolean)"""
    )
    result = []
    for value in values or []:
        url = _normalize_media_url(value)
        if url and all(item["url"] != url for item in result):
            result.append({
                "url": url, "source": "dom_preview", "priority": 10,
                "width": 0, "height": 0, "bitrate": 0, "declared_size": 0,
            })
    return result


def _request_no_watermark_variant(url):
    """Match the local Dola downloader's route switch without re-encoding its signature."""
    normalized = _normalize_media_url(url)
    if not normalized:
        return None
    route_names = (
        r"video_gen_watermark_dyn|video_gen_watermark|cici_ai_v?|"
        r"watermarked|with_watermark"
    )
    result = re.sub(
        rf"(?i)([?&]lr=)(?:{route_names})(?=&|$)",
        r"\1unwatermarked",
        normalized,
    )
    # Some returned media URLs contain one or two URL-encoded query strings.
    # Preserve their existing encoding and signature text while switching only
    # the lr route, matching the current working downloader template.
    result = re.sub(
        rf"(?i)(lr%3D)(?:{route_names})(?=(?:%26|&|$))",
        r"\1unwatermarked",
        result,
    )
    result = re.sub(
        rf"(?i)(lr%253D)(?:{route_names})(?=(?:%2526|%26|&|$))",
        r"\1unwatermarked",
        result,
    )
    return result


def _unwatermarked_dom_candidates(page):
    result = []
    seen = set()
    for candidate in _dom_video_candidates(page):
        url = _request_no_watermark_variant(candidate["url"])
        if not url or url == candidate["url"] or url in seen:
            continue
        seen.add(url)
        result.append({
            "url": url,
            "source": "local_video_card.unwatermarked_variant",
            "priority": 58,
            "width": 0,
            "height": 0,
            "bitrate": 0,
            "declared_size": 0,
        })
    return result


def _merge_candidates(*groups):
    result = []
    seen = set()
    for group in groups:
        for candidate in group or ():
            url = candidate.get("url") if isinstance(candidate, dict) else None
            if not url or url in seen:
                continue
            seen.add(url)
            result.append(candidate)
    return result


def _raise_if_video_failed(text, baseline_failure_markers=0, prompt_markers=None):
    response_text = text
    for prompt_marker in prompt_markers or ():
        response_text = _without_submitted_prompt(response_text, prompt_marker)
    if _is_credit_shortfall_failure(response_text):
        raise VideoGenerationFailed(
            "Dola 等待阶段返回错误额度数字并明确表示无法生成；"
            "该回执不计入额度，立即新建对话原样重提"
        )
    if (_PLAN_ANNOUNCEMENT.search(response_text)
            and not _SUCCESS_WAIT.search(response_text)):
        # A plan/announcement is not a receipt: no waiting time, no charge. Resubmitting in
        # a new chat is what actually starts the generation.
        raise VideoGenerationFailed(
            "Dola 只回复了生成计划、没有给出生成回执；该回执不计入额度，立即新建对话原样重提"
        )
    if _video_generation_failed_marker_count(response_text) > baseline_failure_markers:
        raise VideoGenerationFailed(_video_generation_failure_message(response_text))


def _wait_for_candidates(
    page,
    baseline_vids,
    params,
    progress_callback,
    baseline_ready_markers=0,
    baseline_failure_markers=0,
    baseline_dom_urls=None,
    expected_chat_url=None,
    expected_prompt_markers=None,
    account_index=None,
):
    deadline = _active_wait_clock() + params["generation_timeout"]
    started = _active_wait_clock()
    last_error = None
    ready_seen_at = None
    last_result_refresh = started
    result_refresh_count = 0
    region_capture_notice_logged = False
    rendered_ready_seen = False
    blank_render_since = None
    last_blank_recent_restore = 0.0
    baseline_dom_urls = set(baseline_dom_urls or ())
    while _active_wait_clock() < deadline:
        _check_stopped()
        _dismiss_rename_dialog(page)
        if expected_chat_url and not _is_expected_conversation(
            page, expected_chat_url
        ):
            prefix = f"账号{account_index} " if account_index is not None else ""
            _progress(progress_callback, f"{prefix}检测到聊天被切换，正在返回本次任务对话", 22)
            if not _restore_active_conversation_route(
                page,
                expected_chat_url,
                timeout_ms=12000,
            ):
                _log(
                    f"{prefix}当前任务对话暂未恢复，继续锁定原地址等待，"
                    "不会点击最近对话或切换账号"
                )
            # Re-read the restored conversation on the next loop; never reuse
            # DOM or text captured from the manually selected conversation.
            continue
        content = page.content()
        text = _page_text(page)
        # The exact chat route was verified above. A concrete failure reply
        # wins over the layout-based blank-screen heuristic, including when
        # the user minimized the window and its geometry reports no messages.
        if _video_element_count(page) <= 0:
            _raise_if_video_failed(text, baseline_failure_markers, expected_prompt_markers)
        if expected_chat_url and not _conversation_render_ready(page):
            now = _active_wait_clock()
            # A blank conversation that never recovers is a stuck task, not a slow one:
            # resubmitting in a new chat beats waiting for the 2-hour cap.
            if blank_render_since is not None and now - blank_render_since >= 180:
                raise VideoGenerationFailed(
                    "任务对话白屏超过 3 分钟未恢复；该回执不计入额度，立即新建对话原样重提")
            if blank_render_since is None:
                blank_render_since = now
            if (
                now - blank_render_since >= 4
                and now - last_blank_recent_restore >= 15
            ):
                last_blank_recent_restore = now
                prefix = f"账号{account_index} " if account_index is not None else ""
                message = (
                    f"{prefix}检测到当前任务对话白屏，"
                    "正在从最近记录找回本次任务对话"
                )
                _log(message)
                _progress(progress_callback, message, 22)
                try:
                    _restore_expected_conversation(
                        page,
                        expected_chat_url,
                        timeout_ms=12000,
                        prompt_markers=expected_prompt_markers,
                    )
                except RecoveryPromptMismatch as error:
                    _log(
                        f"{prefix}白屏后最近对话未核对到本次完整提示词：{error}；"
                        "返回原任务地址继续等待，不切号"
                    )
                    _restore_active_conversation_route(
                        page, expected_chat_url, timeout_ms=3000
                    )
                else:
                    expected_chat_url = str(
                        getattr(page, "url", "") or expected_chat_url
                    )
                    _log(f"{prefix}白屏后已从最近记录恢复本次任务对话")
                blank_render_since = _active_wait_clock()
                continue
            page.wait_for_timeout(1000)
            continue
        blank_render_since = None
        # A concrete chat URL is captured only after the submitted prompt was
        # verified. Once that exact route has been restored, trust its stable
        # chat id. Dola may reformat/collapse the displayed prompt later; using
        # the rendered text as a second identity check would incorrectly leave
        # the right conversation and loop through recent chats forever.
        if (
            not expected_chat_url
            and _is_specific_conversation_url(getattr(page, "url", ""))
            and _page_has_task_prompt(text, expected_prompt_markers)
        ):
            expected_chat_url = str(getattr(page, "url", "") or "")
            _log("已从当前页面锁定本次任务对话，不查找最近对话")
        if not expected_chat_url and expected_prompt_markers and not _page_has_task_prompt(
            text, expected_prompt_markers
        ):
            _progress(
                progress_callback,
                "当前任务对话地址尚未显示，继续等待当前页面，不查找旧对话",
                22,
            )
            page.wait_for_timeout(1000)
            continue
        has_new_ready_result = (
            _ready_video_marker_count(text) > baseline_ready_markers
        )

        if expected_chat_url and not _is_expected_conversation(
            page, expected_chat_url
        ):
            continue

        # Until Dola explicitly reports that this task's video is ready, only
        # inspect lightweight page text. Avoid walking the large React tree on
        # every poll, and check every two seconds for faster handoff.
        if not has_new_ready_result:
            ready_seen_at = None
            if _page_is_explicitly_logged_out(page) or _LOGIN_TEXT.search(text[-8000:]):
                raise LoginExpired("等待视频时账号退出登录")
            if _MANUAL_TEXT.search(text[-8000:]) and not _SUCCESS_CREDIT.search(text[-8000:]):
                raise ManualReviewRequired("视频生成阶段出现人脸或安全限制，需要人工处理")
            elapsed = _active_wait_clock() - started
            refresh_interval = params.get("result_refresh_interval", 120)
            now = _active_wait_clock()
            if (
                refresh_interval > 0
                and now - last_result_refresh >= refresh_interval
            ):
                result_refresh_count += 1
                last_result_refresh = now
                prefix = f"账号{account_index} " if account_index is not None else ""
                message = (
                    f"{prefix}等待页面状态更新，正在自动刷新当前任务对话"
                    f"（第{result_refresh_count}次）"
                )
                _log(message)
                _progress(progress_callback, message, 78)
                if not _refresh_expected_conversation(
                    page,
                    expected_chat_url,
                    prompt_markers=expected_prompt_markers,
                ):
                    _log(
                        f"{prefix}自动刷新后原任务对话仍在加载，"
                        "继续等待；仅白屏时才检查最近记录，不切号"
                    )
                continue
            percent = 22 + int(
                min(1.0, elapsed / max(1, params["generation_timeout"])) * 58
            )
            prefix = f"账号{account_index} " if account_index is not None else ""
            _progress(
                progress_callback,
                _waiting_progress_text(
                    prefix,
                    "等待本次新视频生成",
                    elapsed,
                ),
                percent,
            )
            page.wait_for_timeout(2000)
            continue

        all_vids = list(dict.fromkeys(_extract_vids(content) + _react_video_vids(page)))
        vids = [value for value in all_vids if value not in baseline_vids]
        dom_candidates = _dom_video_candidates(page)
        new_dom_candidates = [
            item for item in dom_candidates if item.get("url") not in baseline_dom_urls
        ]

        # Never inspect or download media until the active conversation has
        # gained a new ready-result marker. This prevents an old video element
        # that finishes loading late from being mistaken for the current job.
        if has_new_ready_result:
            rendered_ready_seen = rendered_ready_seen or bool(new_dom_candidates)
            _progress(progress_callback, "检测到成品，正在解析无水印母版", 80)
            card_candidates = _current_card_master_candidates(page, baseline_vids)
            if card_candidates:
                _log("已从当前成品卡片取得签名母版地址，开始下载验证")
                return card_candidates
            share_candidates = _share_template_media_candidates(page)
            if share_candidates:
                return share_candidates
            for vid in reversed(vids):
                fplay_candidates = _fplay_media_candidates(page, vid, params)
                if any(int(item.get("priority") or 0) >= 99 for item in fplay_candidates):
                    return fplay_candidates
                api_candidates, error = _fetch_play_info(page, vid)
                local_candidates = _react_media_candidates(page, vid)
                variant_candidates = (
                    _unwatermarked_dom_candidates(page) if local_candidates else []
                )
                mother_candidates = _merge_candidates(
                    api_candidates,
                    fplay_candidates,
                )
                candidates = _merge_candidates(
                    mother_candidates,
                    local_candidates,
                    variant_candidates,
                )
                if mother_candidates:
                    if error:
                        _log(
                            f"主播放接口部分不可用（{error}），采用已捕获的母版接口数据"
                        )
                    return candidates
                if candidates and params["allow_preview_fallback"]:
                    _log("母版接口暂不可用，已按设置采用页面预览候选")
                    return candidates
                if error:
                    last_error = error
                    if (
                        "country" in error.lower()
                        or "region" in error.lower()
                        or "地区" in error
                    ):
                        # The manager/share path is retried above without
                        # touching the visible conversation. Never refresh a
                        # completed card merely because a separate direct API
                        # request was region-limited.
                        if not region_capture_notice_logged:
                            region_capture_notice_logged = True
                            _log(
                                "高清接口的独立请求返回地区限制，"
                                "继续等待多开器母版通道，不刷新、不切号"
                            )

            if new_dom_candidates and params["allow_preview_fallback"]:
                return new_dom_candidates

            # Dola sometimes renders the completion text first but leaves the
            # video card as a blank placeholder. A manual refresh makes the
            # media metadata appear. Refresh this exact task conversation on a
            # configurable interval, without resubmitting or changing chats.
            now = _active_wait_clock()
            if ready_seen_at is None:
                ready_seen_at = now
            refresh_interval = params.get("result_refresh_interval", 120)
            if (
                not new_dom_candidates
                and refresh_interval > 0
                and now - ready_seen_at >= refresh_interval
                and now - last_result_refresh >= refresh_interval
            ):
                result_refresh_count += 1
                last_result_refresh = now
                prefix = f"账号{account_index} " if account_index is not None else ""
                message = (
                    f"{prefix}成品提示已出现但视频卡片尚未加载，"
                    f"正在自动刷新当前任务对话（第{result_refresh_count}次）"
                )
                _log(message)
                _progress(progress_callback, message, 80)
                if not _refresh_expected_conversation(
                    page,
                    expected_chat_url,
                    prompt_markers=expected_prompt_markers,
                ):
                    _log(
                        f"{prefix}自动刷新后原任务视频卡片仍在加载，"
                        "继续等待，不查找旧对话或切换账号"
                    )
                continue

        if _page_is_explicitly_logged_out(page) or _LOGIN_TEXT.search(text[-8000:]):
            raise LoginExpired("等待视频时账号退出登录")
        if _MANUAL_TEXT.search(text[-8000:]) and not _SUCCESS_CREDIT.search(text[-8000:]):
            raise ManualReviewRequired("视频生成阶段出现人脸或安全限制，需要人工处理")
        # Same classification as the first loop, but never fatal once a video is on the
        # page: a partially successful split ("1 video couldn't be generated") still has a
        # usable first video that must be downloaded.
        if _video_element_count(page) <= 0:
            _raise_if_video_failed(text, baseline_failure_markers, expected_prompt_markers)

        elapsed = _active_wait_clock() - started
        percent = 22 + int(min(1.0, elapsed / max(1, params["generation_timeout"])) * 58)
        status = (
            "已检测到成品，等待可用的无水印母版地址（不重新生成）"
            if has_new_ready_result
            else "等待本次新视频生成"
        )
        prefix = f"账号{account_index} " if account_index is not None else ""
        progress_text = f"{prefix}{status}"
        if not has_new_ready_result:
            progress_text = _waiting_progress_text(
                prefix,
                status,
                elapsed,
            )
        _progress(progress_callback, progress_text, percent)
        page.wait_for_timeout(2000)

    detail = f"；最后接口信息：{last_error}" if last_error else ""
    if rendered_ready_seen:
        raise RuntimeError(
            "Dola 成品视频已显示，但暂未取得可下载的无水印母版地址；"
            "请检查母版解析通道，不要重复生成" + detail
        )
    if ready_seen_at is not None:
        raise RuntimeError(
            f"Dola 已提示视频生成完成，但视频卡片自动刷新 {result_refresh_count} 次后仍未加载{detail}"
        )
    raise RuntimeError(f"等待视频生成超时{detail}")


def _video_metrics(path, fallback=None):
    fallback = fallback or {}
    width = _as_int(fallback.get("width"), 0, 0)
    height = _as_int(fallback.get("height"), 0, 0)
    bitrate = float(fallback.get("bitrate") or 0)
    duration = 0.0
    try:
        import cv2
        capture = cv2.VideoCapture(str(path))
        if capture.isOpened():
            width = int(capture.get(cv2.CAP_PROP_FRAME_WIDTH) or width)
            height = int(capture.get(cv2.CAP_PROP_FRAME_HEIGHT) or height)
            fps = float(capture.get(cv2.CAP_PROP_FPS) or 0)
            frames = float(capture.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
            if fps > 0 and frames > 0:
                duration = frames / fps
        capture.release()
    except Exception:
        pass
    if width <= 0 or height <= 0 or duration <= 0:
        ffprobe_candidates = []
        try:
            ffprobe_candidates.append(
                _PLUGIN_DIR.parents[3] / "resources" / "ffmpeg" / "bin" / "ffprobe.exe"
            )
        except IndexError:
            pass
        ffprobe_on_path = shutil.which("ffprobe")
        if ffprobe_on_path:
            ffprobe_candidates.append(Path(ffprobe_on_path))
        for ffprobe in ffprobe_candidates:
            if not ffprobe.is_file():
                continue
            try:
                completed = subprocess.run(
                    [
                        str(ffprobe), "-v", "error", "-select_streams", "v:0",
                        "-show_entries",
                        "stream=width,height,bit_rate,duration:format=duration,bit_rate",
                        "-of", "json", str(path),
                    ],
                    capture_output=True,
                    text=True,
                    timeout=30,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
                payload = json.loads(completed.stdout or "{}")
                streams = payload.get("streams") or []
                stream = streams[0] if streams else {}
                media_format = payload.get("format") or {}
                width = _as_int(stream.get("width"), width, 0)
                height = _as_int(stream.get("height"), height, 0)
                duration = float(
                    stream.get("duration") or media_format.get("duration") or duration
                )
                bitrate = float(
                    media_format.get("bit_rate") or stream.get("bit_rate") or bitrate
                )
                break
            except Exception:
                continue
    size = os.path.getsize(path)
    if duration > 0:
        bitrate = size * 8 / duration
    return {
        "width": width,
        "height": height,
        "bitrate": bitrate,
        "duration": duration,
        "content_length": size,
    }


def _quality_rank(metrics, candidate=None):
    candidate = candidate or {}
    return (
        int(metrics.get("width") or 0) * int(metrics.get("height") or 0),
        float(metrics.get("bitrate") or 0),
        int(metrics.get("content_length") or 0),
        int(candidate.get("priority") or 0),
    )


def _declared_quality_rank(candidate):
    candidate = candidate or {}
    return (
        int(float(candidate.get("width") or 0))
        * int(float(candidate.get("height") or 0)),
        float(candidate.get("bitrate") or 0),
        int(float(candidate.get("declared_size") or 0)),
        int(candidate.get("priority") or 0),
    )


def _actual_confirms_declared(metrics, candidate):
    """Whether one full download verifies the top candidate's quality metadata."""
    checks = 0
    declared_width = int(float(candidate.get("width") or 0))
    declared_height = int(float(candidate.get("height") or 0))
    declared_bitrate = float(candidate.get("bitrate") or 0)
    declared_size = int(float(candidate.get("declared_size") or 0))
    if declared_width > 0 and declared_height > 0:
        checks += 1
        if (
            int(metrics.get("width") or 0) < declared_width
            or int(metrics.get("height") or 0) < declared_height
        ):
            return False
    if declared_bitrate > 0:
        checks += 1
        if float(metrics.get("bitrate") or 0) < declared_bitrate * 0.72:
            return False
    if declared_size > 0:
        checks += 1
        if int(metrics.get("content_length") or 0) < declared_size * 0.78:
            return False
    return checks >= 2


def _download_best_candidate(page, candidates, output_path, progress_callback):
    _check_stopped()
    if not candidates:
        raise RuntimeError("没有可下载的视频地址")
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    ordered = sorted(
        _merge_candidates(candidates),
        key=_declared_quality_rank,
        reverse=True,
    )[:8]
    probed = []
    temp_paths = []
    try:
        for number, candidate in enumerate(ordered, 1):
            _check_stopped()
            _progress(
                progress_callback,
                f"下载并验证无水印母版 {number}/{len(ordered)}",
                82 + number,
            )
            temp_path = f"{output_path}.candidate_{number}.tmp.mp4"
            candidate_url = str(candidate.get("url") or "")
            split = urllib.parse.urlsplit(candidate_url)
            manager_proxy = (
                (split.hostname or "").lower() in {"127.0.0.1", "localhost"}
                and split.scheme == 'http'
                and split.port == urllib.parse.urlsplit(_manager_api_base()).port
                and split.path.endswith("/download_video")
            )
            if manager_proxy:
                # The master channel is a local proxy in front of the CDN: a single
                # 502 is usually a transient upstream hiccup, so retry it before
                # falling through to the other candidates.
                downloaded = False
                for attempt in range(1, 4):
                    try:
                        request = urllib.request.Request(
                            candidate_url,
                            headers={"Accept": "video/mp4"},
                        )
                        with _manager_urlopen(request, timeout=180) as response:
                            with open(temp_path, "wb") as file:
                                while True:
                                    _check_stopped()
                                    chunk = response.read(1024 * 1024)
                                    if not chunk:
                                        break
                                    file.write(chunk)
                        downloaded = True
                        break
                    except Exception as error:
                        try:
                            os.remove(temp_path)
                        except OSError:
                            pass
                        if attempt < 3:
                            _log(
                                f"多开器母版通道第 {attempt} 次失败（{error}），"
                                f"1.5 秒后重试同一地址"
                            )
                            page.wait_for_timeout(1500)
                            continue
                        _log(f"多开器母版通道下载失败（已重试 3 次）：{error}")
                if not downloaded:
                    continue
                if not os.path.isfile(temp_path) or os.path.getsize(temp_path) < 128 * 1024:
                    try:
                        os.remove(temp_path)
                    except OSError:
                        pass
                    continue
            else:
                body = None
                for attempt in range(1, 4):
                    response = page.context.request.get(
                        candidate_url,
                        headers={
                            "Referer": page.url,
                            "Origin": "https://www.dola.com",
                        },
                        timeout=180000,
                    )
                    if response.ok:
                        body = response.body()
                        break
                    if attempt < 3 and response.status >= 500:
                        _log(
                            f"直连候选第 {attempt} 次返回 HTTP {response.status}，"
                            "1.5 秒后重试同一地址"
                        )
                        page.wait_for_timeout(1500)
                        continue
                    _log(f"直连候选不可用：HTTP {response.status}（{candidate_url[:90]}）")
                    break
                if body is None:
                    continue
                if len(body) < 128 * 1024:
                    _log(f"直连候选文件过小（{len(body)} 字节），跳过")
                    continue
                with open(temp_path, "wb") as file:
                    file.write(body)
            temp_paths.append(temp_path)
            metrics = _video_metrics(temp_path, candidate)
            item = dict(candidate)
            item.update(metrics)
            item["temp_path"] = temp_path
            item["rank"] = _quality_rank(metrics, candidate)
            probed.append(item)
            # Candidates are already ordered by resolution, bitrate and size.
            # When the highest available tier's real file matches its declared
            # metadata, lower tiers cannot win and need not be downloaded.
            if _actual_confirms_declared(metrics, candidate):
                _log("最高档候选的实际画质与接口数据一致，跳过低画质候选下载")
                break

        if not probed:
            raise RuntimeError("所有候选视频下载失败")
        best = max(probed, key=lambda item: item["rank"])
        os.replace(best["temp_path"], output_path)
        temp_paths.remove(best["temp_path"])
        size_mb = best["content_length"] / (1024 * 1024)
        bitrate_mbps = best["bitrate"] / 1_000_000 if best["bitrate"] else 0
        quality = (
            f"{best['width']}x{best['height']} / {bitrate_mbps:.2f}Mbps / {size_mb:.2f}MB"
        )
        _log(f"已选择无水印母版最高画质：{quality}（{best['source']}）")
        _progress(progress_callback, f"无水印母版已返回 {quality}", 100)
        return output_path
    finally:
        for path in temp_paths:
            try:
                os.remove(path)
            except OSError:
                pass


def _existing_result_candidates(page, params):
    """Extract the newest completed result from an already-finished chat."""
    card_candidates = _current_card_master_candidates(page)
    if card_candidates:
        _log("已从原任务成品卡片找回签名母版地址")
        return card_candidates
    text = _page_text(page)
    content = page.content()
    vids = list(dict.fromkeys(_extract_vids(content) + _react_video_vids(page)))
    # After the account window is closed and reopened, Dola often virtualizes
    # the completion sentence out of the rendered text while keeping the
    # finished video card and its React video_id visible. Recovery has already
    # locked the exact conversation (and, for legacy records, matched the full
    # task prompt), so the media card itself is sufficient proof of completion.
    if not vids:
        return []
    if _ready_video_marker_count(text) <= 0:
        _log("原任务完成文字未渲染，但已检测到成品视频卡片，直接解析找回")
    share_candidates = _share_template_media_candidates(page)
    if share_candidates:
        return share_candidates
    for vid in reversed(vids):
        api_candidates, error = _fetch_play_info(page, vid)
        fplay_candidates = _fplay_media_candidates(page, vid, params)
        local_candidates = _react_media_candidates(page, vid)
        variant_candidates = (
            _unwatermarked_dom_candidates(page) if local_candidates else []
        )
        mother_candidates = _merge_candidates(
            api_candidates,
            fplay_candidates,
        )
        candidates = _merge_candidates(
            mother_candidates,
            local_candidates,
            variant_candidates,
        )
        if mother_candidates:
            if error:
                _log(f"找回时主播放接口部分不可用（{error}），采用已捕获的母版数据")
            return candidates
        if candidates and params["allow_preview_fallback"]:
            _log("找回时母版接口暂不可用，已按设置采用页面预览候选")
            return candidates
    return []


def _claim_recovery_account(index):
    with _account_condition:
        if _as_int(_active_slots.get(index, 0), 0, 0):
            return False
        _active_slots[index] = 1
        return True


def _recover_from_account(
    index,
    context,
    params,
    progress_callback,
    expected_url=None,
    wait_for_result=False,
    open_if_needed=False,
):
    _check_stopped()
    port = params["base_port"] + index
    if (expected_url or open_if_needed) and not _devtools_ready(port):
        _check_stopped()
        port = _ensure_account_browser(index, params)
    if not _devtools_ready(port):
        return None
    try:
        from playwright.sync_api import sync_playwright
    except Exception as error:
        raise RuntimeError(f"字字动画缺少 Playwright：{error}") from error

    prompt = _submission_prompt(str(context.get("prompt") or ""), params)
    markers = _task_prompt_markers(prompt)
    output_path = _output_path(context)
    deadline = time.monotonic() + (
        params["generation_timeout"] if wait_for_result else 12
    )
    started = time.monotonic()

    with sync_playwright() as playwright:
        browser = _connect_account_browser(playwright, port, index)
        page = None
        for browser_context in browser.contexts:
            try:
                page = _find_local_dola_page(browser_context)
                break
            except AccountUnavailable:
                continue
        if page is None:
            return None
        _install_media_api_capture(page, reset=True)
        if expected_url:
            if (
                not _is_expected_conversation(page, expected_url)
                or not _conversation_render_ready(page)
            ):
                _progress(
                    progress_callback,
                    f"账号{index}正在点击左侧原任务对话并恢复文字",
                    6,
                )
            if not _restore_expected_conversation(
                page,
                expected_url,
                prompt_markers=markers,
            ):
                raise RecoveryPromptMismatch("最近第一条对话未找到本次完整提示词")
            expected_url = str(getattr(page, "url", "") or expected_url)
        _apply_headless_mode(index, params)

        while time.monotonic() < deadline:
            _check_stopped()
            _dismiss_rename_dialog(page)
            if expected_url and (
                not _is_expected_conversation(page, expected_url)
                or not _conversation_render_ready(page)
            ):
                if not _restore_expected_conversation(
                    page,
                    expected_url,
                    prompt_markers=markers,
                ):
                    raise RecoveryPromptMismatch("最近第一条对话未找到本次完整提示词")
                expected_url = str(getattr(page, "url", "") or expected_url)
            text = _page_text(page)
            if expected_url and not _page_has_task_prompt(text, markers):
                raise RecoveryPromptMismatch(
                    "找回视频时已打开原对话，但没有看到本次分镜的完整提示词"
                )
            if not expected_url and not _page_has_task_prompt(text, markers):
                restored_url = _open_matching_recent_conversation(
                    page, markers, timeout_ms=12000
                )
                if not restored_url:
                    return None
                expected_url = restored_url
                text = _page_text(page)
                if not _page_has_task_prompt(text, markers):
                    return None
            if (
                _video_generation_failed_marker_count(text) > 0
                or _is_credit_shortfall_failure(text)
            ):
                _unmark_submitted(index)
                _forget_recovery(context)
                params["_recovery_retry_account"] = index
                _log(
                    f"账号{index}原任务已明确生成失败，或出现错误额度回执；"
                    "清除旧任务记录并锁定原账号重新提交"
                )
                return None
            candidates = _existing_result_candidates(page, params)
            if candidates:
                _progress(
                    progress_callback,
                    f"账号{index}发现已生成成品，直接找回且不重复扣额度",
                    80,
                )
                result = _download_best_candidate(
                    page, candidates, output_path, progress_callback
                )
                _mark_recovery_complete(context, params, index, page.url)
                _log(f"账号{index}已把停止任务的现有成品找回字字动画")
                return result
            if not wait_for_result:
                return None
            elapsed = time.monotonic() - started
            percent = 12 + int(
                min(1.0, elapsed / max(1, params["generation_timeout"])) * 66
            )
            _progress(
                progress_callback,
                _waiting_progress_text(
                    f"账号{index}",
                    "原任务仍在生成，继续等待找回",
                    elapsed,
                ),
                percent,
            )
            page.wait_for_timeout(2000)
    return None


def _try_recover_existing(context, params, progress_callback):
    _check_stopped()
    records = _recovery_plan(context, params)
    if not records:
        return None

    plans = []
    accounts = set(_account_range(params))
    for record in records:
        index = _as_int(record.get("account"), 0, 0)
        expected_url = str(record.get("chat_url") or "")
        if index in accounts and expected_url:
            plans.append((index, expected_url))
    if not plans:
        return None

    _progress(progress_callback, "先查找这条分镜在 Dola 中已有的成品", 2)
    _log("重新生成只检查本分镜保存的原账号和原对话，不遍历其他账号窗口")
    for index, expected_url in plans:
        _check_stopped()
        if not _claim_recovery_account(index):
            continue
        try:
            _check_stopped()
            output = _recover_from_account(
                index,
                context,
                params,
                progress_callback,
                expected_url=expected_url,
                wait_for_result=bool(expected_url),
                open_if_needed=False,
            )
            if output:
                _close_idle_account_after_success(
                    index, params, progress_callback
                )
                return output
        except RecoveryPromptMismatch as error:
            _forget_recovery(context)
            _mark_unavailable(index)
            closed = _close_account_browser(index, params)
            close_text = "已关闭窗口和后台" if closed else "关闭窗口已重试3次"
            _log(
                f"账号{index}找回视频时无法核对本次完整提示词：{error}；"
                f"{close_text}；已清除无效旧任务记录，不再扫描其他账号"
            )
            _progress(
                progress_callback,
                f"账号{index}未找到本次提示词，停止找回并进入正常生成",
                2,
            )
        except LoginExpired as error:
            _mark_logged_out(index)
            _log(
                f"账号{index}找回原任务时确认已退出登录，"
                "正在先关闭窗口和后台再切换账号"
            )
            closed = _close_account_browser(index, params)
            if closed:
                _log(f"账号{index}窗口和后台已确认退出，可以切换下一账号")
                _progress(
                    progress_callback,
                    f"账号{index}已掉线，窗口和后台已退出，正在切号",
                    2,
                )
            else:
                _log(
                    f"账号{index}已掉线，但窗口或后台关闭失败；"
                    "已完成3次关闭重试"
                )
        except AccountUnavailable as error:
            _log(f"账号{index}暂时无法找回原任务：{error}")
        finally:
            _release_account(index)
    return None


def _safe_piece(value, default):
    text = re.sub(r"[^0-9A-Za-z_-]+", "_", str(value or "")).strip("_")
    return text[:80] or default


def _output_path(context):
    output_dir = os.path.abspath(
        os.fspath(context.get("output_dir") or context.get("project_path") or ".")
    )
    viewer_index = _as_int(context.get("viewer_index"), 0, 0)
    unique_name = _safe_piece(context.get("unique_name"), "dola")
    generation_round = _as_int(context.get("generation_round"), 0, 0)
    positions = context.get("output_position")
    if isinstance(positions, (list, tuple)) and positions:
        position = _safe_piece(positions[0], "0")
    else:
        position = _safe_piece(positions, "0")
    filename = f"{viewer_index:04d}_{unique_name}_{generation_round}_{position}.mp4"
    path = os.path.join(output_dir, filename)
    if os.path.exists(path):
        stamp = time.strftime("%Y%m%d_%H%M%S")
        path = os.path.join(output_dir, f"{viewer_index:04d}_{unique_name}_{generation_round}_{position}_{stamp}.mp4")
    return path


def _recover_matching_before_submit(
    page, index, context, params, progress_callback, output_path
):
    """Last duplicate guard: inspect this account before sending anything."""
    prompt = _submission_prompt(str(context.get("prompt") or ""), params)
    markers = _task_prompt_markers(prompt)
    _progress(progress_callback, f"账号{index}发送前检查已有同分镜任务", 4)
    matched_url = _open_matching_recent_conversation(
        page, markers, timeout_ms=16000
    )
    if not matched_url:
        _log(f"账号{index}未发现相同完整提示词的已提交对话，允许新建任务")
        return None

    text = _page_text(page)
    if (
        _video_generation_failed_marker_count(text) > 0
        or _is_credit_shortfall_failure(text)
    ):
        _log(
            f"账号{index}找到相同提示词的旧对话，但该任务已明确生成失败"
            "或出现错误额度回执；"
            "允许重新提交"
        )
        return None
    candidates = _existing_result_candidates(page, params)
    ready = _ready_video_marker_count(text) > 0
    receipt_state = _classify_response(
        text, params.get("model") or "Seedance 2.5"
    )
    if not candidates and not ready and receipt_state != "submitted":
        # The same text may merely be sitting unsent in a composer. That is not
        # proof of a charged task and must not be treated as a recovery.
        _log(
            f"账号{index}找到相同文字，但没有生成回执或成品；"
            "不把未发送草稿当成旧任务"
        )
        return None

    _log(
        f"账号{index}发送前发现同一完整提示词已经提交；"
        "取消本次发送并接回原任务"
    )
    _progress(
        progress_callback,
        f"账号{index}发现原任务，已阻止重复生成",
        12,
    )
    _record_consumed_credits(params, text)
    _remember_account_balance(index, text)
    _remember_recovery(context, params, index, matched_url)
    _mark_submitted(index)

    if candidates:
        output = _download_best_candidate(
            page, candidates, output_path, progress_callback
        )
        _mark_recovery_complete(context, params, index, matched_url)
        return output

    baseline_vids = set()
    baseline_dom_urls = set()
    candidates = _wait_for_candidates(
        page,
        baseline_vids,
        params,
        progress_callback,
        0,
        0,
        baseline_dom_urls,
        matched_url,
        markers,
        index,
    )
    output = _download_best_candidate(
        page, candidates, output_path, progress_callback
    )
    _mark_recovery_complete(context, params, index, matched_url)
    return output


def _run_on_account(index, context, params, progress_callback):
    port = _ensure_account_browser(index, params)
    _progress(progress_callback, f"账号{index}连接中", 3)
    try:
        from playwright.sync_api import sync_playwright
    except Exception as error:
        raise RuntimeError(f"字字动画缺少 Playwright：{error}") from error

    prompt = str(context.get("prompt") or "").strip()
    if not prompt:
        raise RuntimeError("分镜提示词为空")
    paths = _limit_reference_paths(_reference_paths(context), params)
    output_path = _output_path(context)

    with sync_playwright() as playwright:
        browser = _connect_account_browser(playwright, port, index)
        if not browser.contexts:
            raise AccountUnavailable(f"账号{index}没有浏览器登录上下文")
        page = None
        for browser_context in browser.contexts:
            try:
                page = _find_local_dola_page(browser_context)
                break
            except AccountUnavailable:
                continue
        if page is None:
            raise AccountUnavailable(f"账号{index}没有本地 Dola 聊天窗口")
        _bind_dola_upload_scope(page,params,index)
        submitted = False
        expected_chat_url = None
        expected_prompt_markers = _task_prompt_markers(
            _submission_prompt(prompt, params)
        )
        _wait_for_dola_startup(page, params, progress_callback, index)
        _apply_headless_mode(index, params)
        _wait_for_composer(page, 35000)
        _check_video_quota(page, params, progress_callback)
        _open_clean_chat(page)
        _install_media_api_capture(page, reset=True)
        baseline_vids = set(
            _extract_vids(page.content()) + _react_video_vids(page)
        )
        baseline_ready_markers = _ready_video_marker_count(_page_text(page))
        baseline_failure_markers = _video_generation_failed_marker_count(
            _page_text(page)
        )
        baseline_dom_urls = {
            item.get("url") for item in _dom_video_candidates(page) if item.get("url")
        }
        last_ui_error = None
        new_chat_count = 0
        max_new_chats = 3
        prompt_policy_warning_count = 0
        daily_limit_count = 0
        credit_receipt_error_count = 0
        while True:
            generation_failure = None
            attempt_label = (
                "当前对话"
                if new_chat_count == 0
                else f"新对话 {new_chat_count}/{max_new_chats}"
            )
            _progress(progress_callback, f"账号{index} {attempt_label}提交", 5)
            try:
                state = _prepare_and_submit(
                    page, prompt, paths, params, progress_callback, index
                )
            except (UploadNotReady, PreparationUnconfirmed) as error:
                # The composer already contains the user's exact draft/assets;
                # rotating to a new chat would re-upload and could duplicate
                # the task. Preserve it for manual inspection instead.
                _log(f"账号{index}图文准备未确认：{error}；保留当前草稿，不新建对话重传")
                _progress(progress_callback, f"账号{index}素材/输入框尚未确认，已暂停并保留草稿", 8)
                raise Exception(f"PLUGIN_ERROR:::{error}") from error
            except UiNotReady as error:
                if _page_is_explicitly_logged_out(page):
                    raise LoginExpired("本地 Dola 明确显示未登录") from error
                _log(f"账号{index}页面控件未就绪：{error}；保留当前草稿，不新建对话重传")
                _progress(progress_callback, f"账号{index}参数控件尚未确认，已暂停并保留草稿", 8)
                raise Exception(f"PLUGIN_ERROR:::{error}") from error

            if state == "daily_limit":
                daily_limit_count += 1
                _log(f"账号{index}本次提交收到今日生成次数上限提示 {daily_limit_count}/2")
                if daily_limit_count >= 2:
                    raise InsufficientQuota(
                        f"账号{index}连续两次独立提交均提示今日生成次数达到上限，本批次不再分配任务"
                    )
            else:
                daily_limit_count = 0

            if state == "prompt_policy_warning":
                prompt_policy_warning_count += 1
                _log(
                    f"账号{index}识别到 Dola 安全劝导式回复 "
                    f"{prompt_policy_warning_count}/4，这条分镜提示词可能违规"
                )
                _progress(
                    progress_callback,
                    f"账号{index}提示词疑似违规 "
                    f"{prompt_policy_warning_count}/4，正在换新对话复核",
                    5,
                )
                if prompt_policy_warning_count >= 4:
                    raise PromptPolicyRejected(
                        "提示词疑似违规：Dola 连续 4 次返回相同的"
                        "安全劝导/心理支持提示，已停止本分镜"
                    )
            else:
                prompt_policy_warning_count = 0

            if state in {"submitted", "submitted_pending"}:
                expected_chat_url = _capture_submission_chat_url(
                    page, expected_prompt_markers
                )
                if not expected_chat_url:
                    raise ManualReviewRequired(
                        f"账号{index}发送后尚不能锁定原对话，已停止自动重传，请检查原窗口"
                    )
                if state == "submitted":
                    _record_consumed_credits(params, _page_text(page))
                    # Keep this account remaining credits for the panel (from the reply).
                    _remember_account_balance(index, _page_text(page))
                    _mark_submitted(index)
                _remember_recovery(context, params, index, expected_chat_url)
                remaining = _extract_latest_quota(_page_text(page)) if state == "submitted" else None
                if remaining is not None and remaining < params["required_credits"]:
                    _mark_insufficient_quota(index)
                    _log(
                        f"账号{index}成功入队后页面显示仅剩 {remaining} 个额度，"
                        "本批次不再向该账号分配新任务"
                    )
                submitted = True
                if state == "submitted":
                    _log(f"账号{index}任务已成功入队，已锁定当前新对话：{expected_chat_url}")
                else:
                    _log(f"账号{index}已发送，入队尚未确认；保留原对话等待，不重传素材")
                try:
                    candidates = _wait_for_candidates(
                        page,
                        baseline_vids,
                        params,
                        progress_callback,
                        baseline_ready_markers,
                        baseline_failure_markers,
                        baseline_dom_urls,
                        expected_chat_url,
                        expected_prompt_markers,
                        index,
                    )
                except VideoGenerationFailed as error:
                    generation_failure = error
                    _unmark_submitted(index)
                    _forget_recovery(context)
                    submitted = False
                    state = "generation_failed"
                    _log(
                        f"账号{index}入队后生成失败：{error}；"
                        "停止等待，使用当前账号自动新建对话原样重提"
                    )
                else:
                    output = _download_best_candidate(
                        page, candidates, output_path, progress_callback
                    )
                    _mark_recovery_complete(
                        context, params, index, expected_chat_url
                    )
                    return output

            if state == "daily_limit":
                reason = "首次提示今日生成次数上限，在原账号新对话复核一次"
            elif state == "quota_shortfall":
                raise InsufficientQuota(f"账号{index}剩余额度少于本次任务所需额度，切换下一个账号；不在原账号重传")
            elif state == "portrait_retry":
                reason = "肖像保护提示"
            elif state == "prompt_policy_warning":
                reason = "提示词疑似违规，Dola 返回安全劝导式回复"
            elif state == "credit_receipt_error":
                credit_receipt_error_count += 1
                if credit_receipt_error_count >= 2:
                    raise InsufficientQuota(
                        f"账号{index}连续两次收到参数额度错误回执，切换下一个账号"
                    )
                reason = (
                    "Dola 返回参数额度错误回执（1/2），视为当前对话错误，"
                    "不判定账号额度不足；先新建对话重提"
                )
            elif state == "timeout_new_chat":
                reason = f"超过 {params['submit_timeout']} 秒未出现严格成功回执"
            elif state == "generation_failed":
                reason = str(
                    generation_failure or "生成失败或被拦截"
                )
            elif last_ui_error is not None:
                reason = f"页面控件未就绪：{last_ui_error}"
            else:
                reason = "回复不是‘生成视频＋剩余额度’严格成功回执"
            _log(f"账号{index}{reason}；不回复，新建对话原样重提")

            if new_chat_count >= max_new_chats:
                raise AccountUnavailable(
                    f"账号{index}连续新建 {max_new_chats} 个对话仍未出现"
                    "‘生成视频＋剩余额度’回执，自动切换下一个账号"
                )
            new_chat_count += 1
            _progress(
                progress_callback,
                f"账号{index}已新建对话 {new_chat_count}/{max_new_chats}，原样重提",
                5,
            )
            try:
                _open_clean_chat(page)
                page.wait_for_timeout(1200)
                baseline_vids = set(
                    _extract_vids(page.content()) + _react_video_vids(page)
                )
                current_text = _page_text(page)
                baseline_ready_markers = _ready_video_marker_count(current_text)
                baseline_failure_markers = (
                    _video_generation_failed_marker_count(current_text)
                )
                baseline_dom_urls = {
                    item.get("url")
                    for item in _dom_video_candidates(page)
                    if item.get("url")
                }
                expected_chat_url = None
            except UiNotReady as error:
                raise AccountUnavailable(
                    f"账号{index}新建对话失败：{error}"
                ) from error


def _generate(context, params=None):
    _check_stopped()
    params = dict(params) if isinstance(params, dict) else _fresh_params(context)
    if params.get("target_platform", "dola") != "doubao" and params.get("model") == "Seedance 2.0":
        raise RuntimeError("Dola 不支持 Seedance 2.0，请选择 2.0 Fast 或 2.5")
    progress_callback = context.get("progress_callback")
    manager_root, _launcher = _manager_paths(params)
    _diagnostic_context.root=manager_root
    _diagnostic_record('generation_started',platform=params.get('target_platform','dola'))
    if params.get('target_platform')=='doubao' or _manager_uses_local_api(manager_root, _launcher):
        _ensure_manager_api(manager_root, _launcher, params)
        if params.get('target_platform', 'dola') != 'doubao':
            _ensure_network_preflight()
    try:
        authorization = validate_authorization(str(manager_root))
    except AuthorizationError as error:
        raise Exception(f"PLUGIN_ERROR:::授权校验失败：{error}") from error
    if authorization.get("mode") == "development":
        _log("本机开发原版已启用，无需卡密授权")
    else:
        _log(f"卡密授权有效，到期时间：{authorization['expire_at']}")
    if params.get('target_platform', 'dola') == 'doubao':
        return _doubao_adapter().generate(context, params, globals())
    recovered = _try_recover_existing(context, params, progress_callback)
    if recovered:
        return [recovered]
    preferred_retry_account = params.pop("_recovery_retry_account", None)
    excluded = set()
    total = len(_account_range(params))
    last_error = None

    for _ in range(total):
        _check_stopped()
        try:
            index = _reserve_account(
                params,
                excluded,
                preferred_account=preferred_retry_account,
            )
            preferred_retry_account = None
        except RuntimeError as error:
            last_error = error
            break
        excluded.add(index)
        try:
            output = _run_on_account(index, context, params, progress_callback)
            with _account_condition:
                quota_exhausted = index in _batch_insufficient_quota
            if quota_exhausted or _submitted_count(index) >= params["slots_per_account"]:
                _log(
                    f"账号{index}本批次已无可分配额度，完成下载后立即退出"
                )
            _close_idle_account_after_success(index, params, progress_callback)
            return [output]
        except LoginExpired as error:
            last_error = error
            _mark_logged_out(index)
            _close_account_browser(index, params)
            _log(f"账号{index}登录失效，已关闭并切换账号")
            _progress(progress_callback, f"账号{index}已退出，关闭并切换账号", 2)
            continue
        except PromptPolicyRejected as error:
            last_error = error
            closed = _close_account_browser(index, params)
            close_text = "已关闭账号窗口和后台" if closed else "账号窗口关闭失败"
            message = f"{error}；{close_text}，不再切换其他账号重试"
            _log(f"账号{index}{message}")
            _progress(progress_callback, message, 100)
            raise Exception(f"PLUGIN_ERROR:::{message}") from error
        except RecoveryPromptMismatch as error:
            last_error = error
            _forget_recovery(context)
            _unmark_submitted(index)
            _mark_unavailable(index)
            _close_account_browser(index, params)
            _log(
                f"账号{index}当前对话没有本次完整提示词：{error}；"
                "已关闭并切换账号重新生成"
            )
            _progress(
                progress_callback,
                f"账号{index}未找到本次提示词，关闭并切号重新生成",
                2,
            )
            continue
        except LocalConnectionError as error:
            _log(str(error))
            raise Exception(f"PLUGIN_ERROR:::{error}") from error
        except AccountUnavailable as error:
            last_error = error
            _mark_unavailable(index)
            _close_account_browser(index, params)
            _log(f"账号{index}不可用：{error}，已关闭并切换账号")
            continue
        except InsufficientQuota as error:
            last_error = error
            _mark_insufficient_quota(index)
            _close_account_browser(index, params)
            _log(f"账号{index}额度不足：{error}，已关闭并切换账号")
            _progress(progress_callback, f"账号{index}额度不足，关闭并切换账号", 2)
            continue
        except RegionUnavailable as error:
            _reveal_account_for_review(index, params, error)
            raise Exception(f"PLUGIN_ERROR:::{error}") from error
        except ManualReviewRequired as error:
            _reveal_account_for_review(index, params, error)
            raise Exception(f"PLUGIN_ERROR:::{error}") from error
        except GenerationStopped:
            raise
        except Exception as error:
            _reveal_account_for_review(index, params, error)
            message = str(error)
            if message.startswith("PLUGIN_ERROR:::"):
                raise
            raise Exception(f"PLUGIN_ERROR:::{message}") from error
        finally:
            _release_account(index)

    detail = f"；最后错误：{last_error}" if last_error else ""
    raise Exception(f"PLUGIN_ERROR:::所有账号均不可用、已退出或额度不足{detail}")


def _generation_call_key(context, params):
    """Identify one exact host output without serializing other storyboards."""
    current = context if isinstance(context, dict) else {}
    output_position = current.get("output_position")
    try:
        position_text = json.dumps(
            output_position, ensure_ascii=False, sort_keys=True, default=str
        )
    except (TypeError, ValueError):
        position_text = str(output_position or "")
    output_root = current.get("output_dir") or current.get("project_path") or ""
    try:
        output_root = os.path.abspath(os.fspath(output_root)) if output_root else ""
    except (TypeError, ValueError):
        output_root = str(output_root or "")
    identity = {
        "output_root": output_root,
        "unique_name": str(current.get("unique_name") or ""),
        "viewer_index": str(current.get("viewer_index") or ""),
        "generation_round": str(current.get("generation_round") or ""),
        "output_position": position_text,
        "prompt_hash": hashlib.sha256(
            str(current.get("prompt") or "").encode("utf-8", errors="ignore")
        ).hexdigest(),
        "model": str(params.get("model") or ""),
        "duration": str(params.get("duration") or ""),
        "aspect_ratio": str(params.get("aspect_ratio") or ""),
    }
    # Preserve the old Dola key so unfinished jobs still resume after updating.
    if params.get('target_platform') == 'doubao':
        identity.update(platform='doubao', group=str(params.get('doubao_group') or ''))
    payload = json.dumps(identity, ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(payload.encode("utf-8", errors="ignore")).hexdigest()


def _set_generation_concurrency(value):
    global _generation_concurrency_limit
    limit = _as_int(value, 2, 2, 5)
    with _generation_condition:
        _generation_concurrency_limit = limit
        _global_params["max_concurrent_generations"] = limit
        _generation_condition.notify_all()
    return limit


def _generation_queue_snapshot():
    with _generation_condition:
        return {
            "running": len(_generation_running),
            "queued": len(_generation_waiting),
            "concurrency_limit": _generation_concurrency_limit,
            "stopping": _generation_stop_in_progress,
            "updating": _plugin_update_in_progress,
            "update_restart_required": _plugin_update_restart_required,
            **_account_safety_snapshot(),
        }


def _wait_generation_turn(task_key, entry, progress_callback):
    """FIFO admission before recovery/account/browser work, with no queue timeout."""
    last_position = None
    while True:
        _check_stopped()
        admitted = False
        with _generation_condition:
            _check_account_safety()
            if entry["cancelled"] or _stop_event.is_set():
                raise GenerationStopped("用户已停止 Dola 插件生成，排队任务已取消")
            # Pause/stop can arrive between the outer checkpoint and this lock.
            if _pause_event.is_set() or (not _is_doubao() and _network_pause_event.is_set()):
                continue
            if (
                _generation_waiting
                and _generation_waiting[0] == task_key
                and len(_generation_running) < _generation_concurrency_limit
            ):
                _generation_waiting.popleft()
                _generation_running.add(task_key)
                admitted = True
                running = len(_generation_running)
                limit = _generation_concurrency_limit
                _generation_condition.notify_all()
            else:
                position = _generation_waiting.index(task_key) + 1
                running = len(_generation_running)
                limit = _generation_concurrency_limit
        if admitted:
            _progress(progress_callback, f"分镜已开始运行（{running}/{limit} 并发）", 1)
            return
        if position != last_position:
            _progress(
                progress_callback,
                f"分镜排队中：第 {position} 位，当前运行 {running}/{limit}；有任务结束后自动开始",
                0,
            )
            last_position = position
        with _generation_condition:
            _generation_condition.wait(timeout=0.5)


def generate(context):
    params = _fresh_params(context)
    previous = getattr(_platform_context, 'name', 'dola')
    previous_connection=dict(_manager_connection_context.__dict__)
    _select_manager_context(params)
    _platform_context.name = params.get('target_platform', 'dola')
    try:
        return _generate_queued(context)
    finally:
        _platform_context.name = previous
        _manager_connection_context.__dict__.clear();_manager_connection_context.__dict__.update(previous_connection)


def _generate_queued(context):
    global _active_generation_count, _network_guard_batch_checked, _generation_concurrency_limit
    global _account_safety_check_passed
    params = _fresh_params(context)
    try:
        _retry_account_safety_from_generate()
    except GenerationStopped as error:
        raise Exception(f"PLUGIN_ERROR:::{error}") from error
    task_key = _generation_call_key(context, params)
    progress_callback = context.get("progress_callback") if isinstance(context, dict) else None
    with _generation_lock:
        if _plugin_update_in_progress:
            raise Exception("PLUGIN_ERROR:::插件正在安装更新，请等待安装完成并重启字字动画后再生成")
        if _plugin_update_restart_required:
            raise Exception("PLUGIN_ERROR:::插件更新已安装，请先重启字字动画再生成，以免混用新旧版本")
        _check_account_safety()
        if _generation_stop_in_progress:
            raise Exception("PLUGIN_ERROR:::正在停止并关闭账号窗口，请完成后重新点击生成")
        if _active_generation_count == 0:
            _stop_event.clear()
            _network_guard_batch_checked = _account_safety_check_passed
            _account_safety_check_passed = False
            _generation_concurrency_limit = params["max_concurrent_generations"]
        _active_generation_count += 1
        entry = _inflight_generations.get(task_key)
        owner = entry is None
        if owner:
            entry = {
                "event": threading.Event(),
                "result": None,
                "error": None,
                "cancelled": False,
            }
            _inflight_generations[task_key] = entry
            _generation_waiting.append(task_key)
    try:
        if not owner:
            _progress(
                progress_callback,
                "检测到同一分镜被重复触发，等待并复用正在运行的任务",
                1,
            )
            _log("同一分镜已有任务运行，已阻止重复打开账号和重复扣除额度")
            while not entry["event"].wait(timeout=1.0):
                _check_stopped()
            if entry["cancelled"]:
                raise GenerationStopped("用户已停止 Dola 插件生成，排队任务已取消")
            if entry.get("error") is not None:
                raise Exception(str(entry["error"])) from entry["error"]
            result = entry.get("result")
            return list(result) if isinstance(result, list) else result

        try:
            _wait_generation_turn(task_key, entry, progress_callback)
            result = _generate(context, params)
            if params.get('target_platform') == 'doubao':
                # Only the owning call commits a verified download as returned
                # to the host. Accepted/progress/download events are not success.
                returned_state = _doubao_adapter().mark_host_return(context, params, globals(), result)
                _doubao_adapter().close_after_host_return(returned_state, globals())
        except GenerationStopped as error:
            wrapped = Exception(f"PLUGIN_ERROR:::{error}")
            _append_runtime_log(str(error), "error")
            with _generation_lock:
                entry["error"] = wrapped
            raise wrapped from error
        except Exception as error:
            message = str(error).removeprefix('PLUGIN_ERROR:::')
            _append_runtime_log('生成失败：' + message, 'error')
            wrapped = Exception('PLUGIN_ERROR:::' + message)
            with _generation_lock:
                entry["error"] = wrapped
            raise wrapped from error
        else:
            with _generation_lock:
                entry["result"] = result
            _diagnostic_record('generation_finished',success=True)
            return result
        finally:
            with _generation_condition:
                _generation_running.discard(task_key)
                if task_key in _generation_waiting:
                    _generation_waiting.remove(task_key)
                entry["event"].set()
                if _inflight_generations.get(task_key) is entry:
                    _inflight_generations.pop(task_key, None)
                _generation_condition.notify_all()
    except GenerationStopped as error:
        raise Exception(f"PLUGIN_ERROR:::{error}") from error
    finally:
        with _generation_lock:
            _active_generation_count = max(0, _active_generation_count - 1)
            if _active_generation_count == 0 and not _generation_stop_in_progress:
                _stop_event.clear()


def _version_key(value):
    parts = [int(piece) for piece in re.findall(r"\d+", str(value or ""))[:4]]
    return tuple((parts + [0, 0, 0, 0])[:4])


def _download_update_json(url):
    parsed = urllib.parse.urlsplit(str(url or "").strip())
    if parsed.scheme.lower() not in {"http", "https"} or not parsed.netloc:
        raise ValueError("更新清单地址必须是有效的 http/https 网址")
    request = urllib.request.Request(
        str(url),
        headers={
            "Accept": "application/json",
            "Cache-Control": "no-cache",
            "User-Agent": f"{_PLUGIN_ID}/{_PLUGIN_VERSION}",
        },
    )
    with urllib.request.urlopen(request, timeout=20) as response:
        raw = response.read(256 * 1024 + 1)
    if len(raw) > 256 * 1024:
        raise ValueError("更新清单超过 256KB，已拒绝读取")
    try:
        payload = json.loads(raw.decode("utf-8-sig"))
    except Exception as error:
        raise ValueError(f"更新清单不是有效 JSON：{error}") from error
    if not isinstance(payload, dict):
        raise ValueError("更新清单必须是 JSON 对象")
    return payload


def _sanitize_update_manifest(payload):
    version = str(payload.get("version") or payload.get("latest") or "").strip()
    download_url = str(
        payload.get("url")
        or payload.get("zip_url")
        or payload.get("download_url")
        or ""
    ).strip()
    sha256 = str(payload.get("sha256") or "").strip().lower()
    if not version or not re.search(r"\d", version):
        raise ValueError("更新清单缺少 version")
    parsed = urllib.parse.urlsplit(download_url)
    if parsed.scheme.lower() not in {"http", "https"} or not parsed.netloc:
        raise ValueError("更新清单缺少可直接下载的 ZIP 地址")
    if sha256 and not re.fullmatch(r"[0-9a-f]{64}", sha256):
        raise ValueError("更新清单中的 sha256 格式不正确")
    return {
        "name": str(payload.get("name") or "Anne自动化插件"),
        "version": version,
        "url": download_url,
        "sha256": sha256,
        "size": _as_int(payload.get("size"), 0, 0),
        "force": bool(payload.get("force")),
        "notes": re.sub(r"\s+", " ", str(payload.get("notes") or "")).strip()[:500],
    }


def _plugin_update_policy():
    # This flag controls update UX only. It never authorizes an account or
    # changes license validation. Missing metadata keeps old share installs working.
    root=globals().get('_PLUGIN_DIR')
    if root is not None:
        for name in ('local_update_policy.json','info.json'):
            try:
                path=Path(root)/name
                if not path.is_file() or path.stat().st_size>65536:continue
                metadata=json.loads(path.read_text(encoding='utf-8-sig'))
                if not isinstance(metadata,dict):continue
                edition=metadata.get('edition') if name=='local_update_policy.json' else metadata.get('workbench_edition')
                if edition in ('development','share'):
                    return {'edition':edition,'online_updates':edition=='share'}
            except (OSError,ValueError,TypeError):
                continue
    return {'edition':'share','online_updates':True}


def _local_update_status():
    return {'ok':True,'edition':'development','online_updates':False,'managed_locally':True,
            'update_available':False,'has_update':False,'installed':False,
            'current_version':_PLUGIN_VERSION,'latest_version':_PLUGIN_VERSION,
            'message':'开发原版由本机直接同步修复，无需联网更新或安装。'}


def _check_online_update(url):
    if not _plugin_update_policy()['online_updates']:
        return _local_update_status()
    url = str(url or "").strip()
    if not url:
        return {
            "ok": False,
            "update_available": False,
            "has_update": False,
            "current_version": _PLUGIN_VERSION,
            "error": "尚未配置更新清单网址。",
        }
    try:
        manifest = _sanitize_update_manifest(_download_update_json(url))
    except Exception as error:
        return {"ok": False, "error": f"联网检查失败：{error}"}
    latest = manifest["version"]
    has_update = _version_key(latest) > _version_key(_PLUGIN_VERSION)
    message = (
        f"发现新版本 v{latest}（当前 v{_PLUGIN_VERSION}）"
        if has_update
        else f"当前已是最新版 v{_PLUGIN_VERSION}。"
    )
    if has_update and manifest.get("notes"):
        message += f"；{manifest['notes']}"
    return {
        "ok": True,
        "update_available": has_update,
        "has_update": has_update,
        "current_version": _PLUGIN_VERSION,
        "latest_version": latest,
        "manifest_url": url,
        "manifest": manifest,
        "message": message,
    }


def _verify_update_zip_member(member):
    name = member.filename.replace("\\", "/")
    if (
        not name
        or name.startswith("/")
        or name.startswith("../")
        or "/../" in f"/{name}/"
        or re.match(r"^[A-Za-z]:", name)
    ):
        raise ValueError(f"更新包包含不安全路径：{member.filename}")
    unix_mode = member.external_attr >> 16
    if unix_mode and (unix_mode & 0o170000) == 0o120000:
        raise ValueError(f"更新包不允许符号链接：{member.filename}")


def _find_update_root(extract_dir):
    root = Path(extract_dir)
    candidates = [root]
    top_dirs = [item for item in root.iterdir() if item.is_dir()]
    if len(top_dirs) == 1:
        candidates.append(top_dirs[0])
    for candidate in candidates:
        if (
            (candidate / "main.py").is_file()
            and (candidate / "info.json").is_file()
            and (candidate / "ui" / "index.html").is_file()
        ):
            return candidate
    raise ValueError("更新包中缺少 main.py、info.json 或 ui/index.html")


def _copy_update_file(source, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.name + ".update_tmp")
    try:
        if temporary.exists():
            os.chmod(str(temporary), 0o666)
            temporary.unlink()
    except OSError:
        pass
    shutil.copyfile(str(source), str(temporary))
    try:
        os.chmod(str(temporary), 0o666)
    except OSError:
        pass

    last_error = None
    for attempt in range(1, 7):
        try:
            if destination.exists():
                try:
                    os.chmod(str(destination), 0o666)
                except OSError:
                    pass
            os.replace(str(temporary), str(destination))
            return
        except PermissionError as error:
            last_error = error
            if attempt < 6:
                time.sleep(0.5 * attempt)

    # Some Windows hosts allow writing an imported .py file but temporarily
    # reject renaming over it. In that case, update the contents in place.
    try:
        with temporary.open("rb") as source_handle:
            with destination.open("wb") as destination_handle:
                shutil.copyfileobj(source_handle, destination_handle, 256 * 1024)
                destination_handle.flush()
                os.fsync(destination_handle.fileno())
        if destination.stat().st_size != temporary.stat().st_size:
            raise OSError("更新文件写入不完整")
        temporary.unlink()
        return
    except Exception as fallback_error:
        raise PermissionError(
            f"无法覆盖 {destination.name}，请关闭字字动画后重试"
        ) from (fallback_error or last_error)


def _update_source_files(source_root):
    source_root = Path(source_root)
    result = []
    for current, dirnames, filenames in os.walk(str(source_root)):
        current_path = Path(current)
        dirnames[:] = [
            name for name in dirnames
            if name not in _UPDATE_PRESERVE_NAMES
            and name not in _WORKBENCH_OVERLAY_NAMES
        ]
        for filename in filenames:
            if (
                filename in _UPDATE_PRESERVE_NAMES
                or filename.endswith((".pyc", ".pyo"))
            ):
                continue
            source = current_path / filename
            result.append((source.relative_to(source_root), source))
    return result


def _copy_update_tree(source_root, destination_root, touched=None):
    touched = [] if touched is None else touched
    for relative, source in _update_source_files(source_root):
        destination = Path(destination_root) / relative
        # Record before writing: a failed Windows in-place fallback may already
        # have changed this file, and the caller still needs the partial list.
        touched.append(relative)
        _copy_update_file(source, destination)
    return touched


def _rollback_update_tree(backup_root, destination_root, touched):
    for relative in reversed(list(touched or ())):
        backup = Path(backup_root) / relative
        destination = Path(destination_root) / relative
        try:
            if backup.is_file():
                _copy_update_file(backup, destination)
            elif destination.exists():
                destination.unlink()
        except Exception:
            pass


def _download_update_zip_once(url, destination, expected_size=0):
    request = urllib.request.Request(
        url,
        headers={
            "Accept": "application/octet-stream",
            "Cache-Control": "no-cache",
            "Connection": "close",
            "User-Agent": f"{_PLUGIN_ID}/{_PLUGIN_VERSION}",
        },
    )
    digest = hashlib.sha256()
    total = 0
    with urllib.request.urlopen(request, timeout=300) as response:
        content_length = _as_int(response.headers.get("Content-Length"), 0, 0)
        if content_length > _MAX_UPDATE_DOWNLOAD_BYTES:
            raise ValueError("更新包超过 256MB，已拒绝下载")
        with Path(destination).open("wb") as output:
            while True:
                chunk = response.read(256 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > _MAX_UPDATE_DOWNLOAD_BYTES:
                    raise ValueError("更新包超过 256MB，已停止下载")
                digest.update(chunk)
                output.write(chunk)
    if expected_size and total != expected_size:
        raise ValueError(f"更新包大小不一致：预期 {expected_size}，实际 {total}")
    return digest.hexdigest(), total


def _download_update_zip(url, destination, expected_size=0):
    destination = Path(destination)
    last_error = None
    for attempt in range(1, 5):
        try:
            if destination.exists():
                destination.unlink()
            return _download_update_zip_once(url, destination, expected_size)
        except Exception as error:
            last_error = error
            message = str(error)
            if "超过 256MB" in message:
                raise
            if attempt >= 4:
                break
            _log(f"更新下载连接中断，正在重试 {attempt}/4")
            time.sleep(1.5 * attempt)
    raise ConnectionError(
        f"下载连接连续失败 4 次，请稍后再试：{last_error}"
    ) from last_error


class UpdateVersionChanged(ValueError):
    """The user has not approved the newly published version yet."""


_WORKBENCH_OVERLAY_NAMES = ("workbench", "_workbench")
_WORKBENCH_PATCH_FILES = ("desktop_dola_video.py", "desktop_dola_duration.js")


def _workbench_overlay_root(source_root):
    """Return the package's workbench overlay directory when it carries one."""
    source_root = Path(source_root)
    for name in _WORKBENCH_OVERLAY_NAMES:
        candidate = source_root / name
        if candidate.is_dir():
            return candidate
    return None


def _install_workbench_patch(source_root):
    """Copy the whitelisted workbench overlay into the connected workbench's _internal.

    Never fatal: the plugin update has already succeeded by the time this runs, so any
    problem is logged and reported instead of raised.
    """
    overlay = _workbench_overlay_root(source_root)
    if overlay is None:
        return {"applied": False, "reason": "no-overlay"}
    try:
        params = _fresh_params(None)
        manager_root, _launcher = _manager_paths(params)
    except Exception as error:
        _log(f"工作台补丁跳过：无法确定工作台目录（{error}）")
        return {"applied": False, "reason": "no-workbench"}
    internal = Path(manager_root) / "_internal"
    if not (internal / "desktop_shell.py").is_file():
        _log("工作台补丁跳过：目标目录不是 Anne 工作台")
        return {"applied": False, "reason": "not-workbench"}
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    changed = []
    backups = []
    for name in _WORKBENCH_PATCH_FILES:
        source = overlay / name
        if not source.is_file():
            continue
        target = internal / name
        data = source.read_bytes()
        if target.is_file() and target.read_bytes() == data:
            continue
        try:
            if target.is_file():
                backup = target.with_suffix(target.suffix + f".bak-{stamp}")
                shutil.copy2(target, backup)
                backups.append(str(backup))
            temporary = target.with_suffix(target.suffix + ".tmp")
            temporary.write_bytes(data)
            os.replace(str(temporary), str(target))
            changed.append(name)
        except Exception as error:
            _log(f"工作台补丁写入 {name} 失败：{error}")
    if changed:
        _log("工作台补丁已更新：" + " / ".join(changed) + "；需要重启 Anne 工作台后生效")
    return {"applied": bool(changed), "files": changed, "backups": backups}


def _install_online_update(url, expected_version=None):
    global _plugin_update_in_progress, _plugin_update_restart_required
    if not _plugin_update_policy()['online_updates']:
        return _local_update_status()
    with _generation_lock:
        if _plugin_update_in_progress:
            raise RuntimeError("插件更新正在安装，请勿重复点击")
        if _plugin_update_restart_required:
            raise RuntimeError("插件更新已安装，请先重启字字动画")
        if _active_generation_count or _generation_running or _generation_waiting or _generation_stop_in_progress:
            raise RuntimeError("仍有生成或排队任务，请等待任务结束后再更新；不会中断现有任务")
        _plugin_update_in_progress = True
    try:
        result = _install_online_update_files(url, expected_version)
        if result.get('installed'):
            with _generation_lock:
                _plugin_update_restart_required = True
        return result
    finally:
        with _generation_lock:
            _plugin_update_in_progress = False


def _install_online_update_files(url, expected_version=None):
    if not _plugin_update_policy()['online_updates']:
        return _local_update_status()
    check = _check_online_update(url)
    if not check.get("ok"):
        raise ValueError(check.get("error") or "更新检测失败")
    manifest = check["manifest"]
    if expected_version and _version_key(expected_version) != _version_key(manifest['version']):
        raise UpdateVersionChanged("线上版本已变化，请重新检测并确认后再安装")
    if not check.get("update_available") and not manifest.get("force"):
        return {
            "ok": True,
            "installed": False,
            "current_version": _PLUGIN_VERSION,
            "latest_version": manifest["version"],
            "message": f"当前已是最新版 v{_PLUGIN_VERSION}。",
        }

    backup_root = _PLUGIN_DIR.parent / f"_{_PLUGIN_DIR.name}_backups"
    backup_root.mkdir(parents=True, exist_ok=True)
    backup_dir = backup_root / datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    touched = []
    with tempfile.TemporaryDirectory(prefix="dola_plugin_update_") as temp_dir:
        temp_root = Path(temp_dir)
        zip_path = temp_root / "update.zip"
        _log(f"正在后台下载插件更新 v{manifest['version']}")
        actual_sha256, actual_size = _download_update_zip(
            manifest["url"], zip_path, manifest.get("size") or 0
        )
        expected_sha256 = manifest.get("sha256")
        if expected_sha256 and actual_sha256.lower() != expected_sha256.lower():
            raise ValueError("更新包 SHA-256 校验失败，已取消安装")

        extract_dir = temp_root / "extract"
        extract_dir.mkdir()
        with zipfile.ZipFile(zip_path, "r") as archive:
            members = archive.infolist()
            if len(members) > 5000:
                raise ValueError("更新包文件数量异常")
            total_uncompressed = 0
            for member in members:
                _verify_update_zip_member(member)
                total_uncompressed += max(0, int(member.file_size or 0))
                if total_uncompressed > _MAX_UPDATE_EXTRACT_BYTES:
                    raise ValueError("更新包解压后超过 512MB，已取消安装")
            archive.extractall(str(extract_dir))

        update_root = _find_update_root(extract_dir)
        try:
            package_info = json.loads(
                (update_root / "info.json").read_text(encoding="utf-8-sig")
            )
        except Exception as error:
            raise ValueError(f"更新包 info.json 无效：{error}") from error
        package_version = str(package_info.get("version") or "").strip()
        if _version_key(package_version) != _version_key(manifest["version"]):
            raise ValueError(
                f"更新包版本 {package_version or '未知'} 与清单版本 "
                f"{manifest['version']} 不一致"
            )

        shutil.copytree(
            str(_PLUGIN_DIR),
            str(backup_dir),
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo"),
        )
        try:
            _copy_update_tree(update_root, _PLUGIN_DIR, touched)
        except Exception:
            _rollback_update_tree(backup_dir, _PLUGIN_DIR, touched)
            raise
        # The package may also carry workbench files; write them after the plugin is in
        # place, and keep going even if that part cannot be applied.
        workbench_patch = _install_workbench_patch(update_root)

        state = {
            "installed_at": datetime.now(_BEIJING_TIMEZONE).strftime(
                "%Y-%m-%d %H:%M:%S"
            ),
            "from_version": _PLUGIN_VERSION,
            "to_version": manifest["version"],
            "backup_dir": str(backup_dir),
            "sha256": actual_sha256,
            "size": actual_size,
        }
        state_path = _PLUGIN_DIR / "update_state.json"
        temporary_state = state_path.with_suffix(".json.tmp")
        temporary_state.write_text(
            json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        os.replace(str(temporary_state), str(state_path))

    return {
        "ok": True,
        "installed": True,
        "current_version": _PLUGIN_VERSION,
        "latest_version": manifest["version"],
        "backup_dir": str(backup_dir),
        "restart_required": True,
        "workbench_patch": workbench_patch,
        "message": (
            f"v{manifest['version']} 已下载并自动安装；"
            + ("工作台补丁也一起装好了，重启 Anne 工作台与字字动画后生效。"
               if workbench_patch.get("applied") else
               "请重启字字动画后生效。")
        ),
    }


def _doubao_quota_snapshot(params, accounts=None):
    """Read local usage and account metadata without launching a workbench/tab."""
    adapter = _doubao_adapter()
    if accounts is None:
        manager_root,launcher=_manager_paths(params)
        if not _anne_manager_required(manager_root,launcher,params) or not _bind_running_workbench(manager_root):
            raise RuntimeError('所选 Anne 工作台尚未连接；不会为额度查询启动工作台。')
        payload = _manager_api_request('/desktop/platforms')
        accounts = payload.get('accounts') if isinstance(payload, dict) else None
    if not isinstance(accounts, list):
        raise RuntimeError('工作台账号接口返回异常')
    snapshot = adapter.quota_snapshot(_PLUGIN_DIR / 'data' / 'doubao-tasks', accounts, params)
    if not isinstance(snapshot, dict) or not isinstance(snapshot.get('accounts'), list):
        raise RuntimeError('豆包额度记录暂不可读')
    return snapshot


def _doubao_quota_message(snapshot):
    return (
        f" 今日豆包：已生成 {snapshot['success']} 条，处理中 {snapshot['processing']} 条，"
        f"预计可用 {snapshot['remaining']} 额度；"
        '北京时间 00:00 重置。'
    )


def handle_action(action, data=None, context=None):
    params = _fresh_params(context)
    previous = getattr(_platform_context, 'name', 'dola')
    previous_connection=dict(_manager_connection_context.__dict__)
    _select_manager_context(params)
    _platform_context.name = params.get('target_platform', 'dola')
    try:
        return _handle_action(action, data, context)
    finally:
        _platform_context.name = previous
        _manager_connection_context.__dict__.clear();_manager_connection_context.__dict__.update(previous_connection)


def _handle_action(action, data=None, context=None):
    global _generation_stop_in_progress
    params = _fresh_params()
    if action == 'restore_dola_account':
        return _restore_dola_account(params, data)
    if action == 'get_doubao_quota':
        if params.get('target_platform') != 'doubao':
            return {'ok': False, 'read_only': True, 'error': '今日额度仅在豆包平台显示。'}
        try:
            snapshot = _doubao_quota_snapshot(params)
            return {'ok': True, 'read_only': True, 'quota': snapshot}
        except Exception:
            # Polling must neither start the workbench nor turn an unavailable
            # account list into a misleading zero-usage/empty-account snapshot.
            return {
                'ok': False, 'read_only': True, 'available': False,
                'error': '暂时无法读取豆包今日额度，请确认 Anne 工作台已打开后重试；额度未按 0 计算。',
            }
    if params.get('target_platform') == 'doubao' and action in {'check_environment', 'show_account_state'}:
        try:
            manager_root, launcher = _manager_paths(params)
            _ensure_manager_api(manager_root, launcher, params)
            validate_authorization(str(manager_root))
            adapter = _doubao_adapter()
            accounts = _manager_api_request('/desktop/platforms').get('accounts')
            if not isinstance(accounts, list):
                raise RuntimeError('工作台账号接口返回异常，请稍后重试')
            # Connectivity is not page readiness. A normal cold start has no
            # opened account tabs; generation opens its own selected account.
            if action == 'check_environment':
                return {'ok': True, 'connected': True, 'message': '工作台已连接。'}
            rows = adapter.select_account(accounts, params)
            ready=0;issues=[];opened=sum(bool(r.get('opened')) for r in rows)
            for row in rows:
                if not row.get('opened'):continue
                page=None
                try:
                    page=adapter.Page(row);state=adapter.account_state(page)
                    if state.get('plan')=='logged_out':issues.append('账号 '+str(abs(row['index']))+' 未登录')
                    elif adapter.composer(page):ready+=1
                    else:issues.append('账号 '+str(abs(row['index']))+' 输入框未就绪')
                except Exception as error:issues.append('账号 '+str(abs(row['index']))+'：'+str(error))
                finally:adapter.close_page(page)
            message=f'工作台已连接：{len(rows)} 个豆包账号，已打开 {opened} 个，页面可输入 {ready} 个。'
            if issues:message+=' '+ '；'.join(issues)
            if not opened:message+=' 生成时将自动打开账号。'
            elif not ready:message+=' 请检查已打开账号的登录状态或等待页面加载完成。'
            ok = bool(ready) or not opened
            snapshot = None
            try:
                snapshot = _doubao_quota_snapshot(params, accounts)
                message += _doubao_quota_message(snapshot)
            except Exception:
                message += ' 今日额度暂不可读（未按 0 计算），请稍后刷新。'
            response = {'ok': ok, 'connected': True, 'message': message, 'error': message if not ok else None}
            if snapshot is not None:response['quota'] = snapshot
            return response
        except Exception as error:
            return {'ok': False, 'error': str(error)}
    with _generation_condition:
        if _active_generation_count == 0:
            _set_generation_concurrency(params["max_concurrent_generations"])
    if action == "set_generation_concurrency":
        value = data.get("limit") if isinstance(data, dict) else params["max_concurrent_generations"]
        limit = _set_generation_concurrency(value)
        status = _generation_queue_snapshot()
        message = f"分镜并发上限已设为 {limit}，其余任务按顺序排队，有空位自动补上。"
        if status["running"] > limit:
            message += "正在运行的分镜不中断，数量降到新上限以下后再补位。"
        _log(message)
        return dict(status, ok=True, message=message)
    if action == "dola_account_total":
        # The panel asks for the real Dola account count so the start/end fields can be
        # filled and capped instead of letting a hand-typed range point at a number
        # that does not exist.
        numbers = sorted(_known_dola_account_numbers(params))
        return {"ok": True, "total": len(numbers), "numbers": numbers}

    if action == "plugin_status":
        _poll_network_guard()
        return {
            "ok": True,
            "version": _PLUGIN_VERSION,
            **_plugin_update_policy(),
            "headless_mode": bool(params.get("headless_mode")),
            "paused": _pause_event.is_set() or (not _is_doubao() and _network_pause_event.is_set()) or (not _is_doubao() and _account_safety_event.is_set()),
            "network_paused": (not _is_doubao() and _network_pause_event.is_set()),
            "network_message": _network_guard_state.get("message", ""),
            "network_auto_recovering": bool(_network_guard_state.get("auto_recovering")),
            **_generation_queue_snapshot(),
            "paused": _pause_event.is_set() or (not _is_doubao() and (_network_pause_event.is_set() or _account_safety_event.is_set())),
        }

    if action == "toggle_pause":
        if not _is_doubao() and (not _is_doubao() and _account_safety_event.is_set()):
            return {"ok": False, "paused": True, "account_safety_stopped": True,
                    "error": "请重新点击分镜的生成视频按钮；网络复检通过后才解除掉线保护。"}
        _poll_network_guard(force=True)
        if (not _is_doubao() and _network_pause_event.is_set()):
            try:
                _manager_api_request(
                    "/automation_network_check", method="POST",
                    data={"force": True}, timeout=65,
                )
                state = _poll_network_guard(force=True)
            except Exception as error:
                return {"ok": False, "paused": True, "error": f"重新检测未完成：{error}"}
            if (not _is_doubao() and _network_pause_event.is_set()):
                return {"ok": False, "paused": True, "error": state.get("message")}
            # A network recovery must not clear a separately requested manual pause.
            message = "网络检测通过，" + (
                "仍保持手动暂停，请再次点击恢复。" if _pause_event.is_set()
                else "已恢复原任务。"
            )
            _log(message)
            return {"ok": True, "paused": _pause_event.is_set(), "message": message}
        if _pause_event.is_set():
            _pause_event.clear()
            message = "插件所有操作已恢复，将从原进度继续。"
            _log(message)
            return {"ok": True, "paused": False, "message": message}
        _pause_event.set()
        message = "插件所有操作已暂停；不关窗口、不切号、不刷新、不提交、不下载。"
        _log(message)
        return {"ok": True, "paused": True, "message": message}

    if action == "get_generation_logs":
        _poll_network_guard()
        # The panel polls this action, so an idle app also rolls its counters
        # within a few seconds after Beijing midnight. With the panel closed,
        # the first task/state access after midnight performs the same reset.
        with _state_lock:
            _load_state_unlocked()
        after = data.get("after", 0) if isinstance(data, dict) else 0
        return {
            "ok": True,
            "logs": _runtime_log_snapshot(after),
            **_plugin_update_policy(),
            "active": _active_generation_count,
            **_generation_queue_snapshot(),
            "paused": _pause_event.is_set() or (not _is_doubao() and (_network_pause_event.is_set() or _account_safety_event.is_set())),
            "paused": _pause_event.is_set() or (not _is_doubao() and _network_pause_event.is_set()) or (not _is_doubao() and _account_safety_event.is_set()),
            "network_paused": (not _is_doubao() and _network_pause_event.is_set()),
            "network_auto_recovering": bool(_network_guard_state.get("auto_recovering")),
        }

    if action == "clear_generation_logs":
        _clear_runtime_logs()
        return {"ok": True, "message": "生成日志已清空。"}

    if action == "export_diagnostics":
        try:
            from anne_diagnostics import Diagnostics
            logger=Diagnostics(_PLUGIN_DIR/'data'/'diagnostics',source='plugin',background=False)
            path=logger.export()
            subprocess.Popen(['explorer.exe','/select,',str(path)])
            return {"ok":True,"message":"已导出最近48小时诊断日志，请发送选中的 TXT 文件："+str(path)}
        except Exception:
            return {"ok":False,"error":"诊断日志导出失败，请检查插件目录是否可写；任务未改动。"}

    if action == "check_update":
        url = (
            data.get("url")
            if isinstance(data, dict) and data.get("url") is not None
            else params.get("update_manifest_url")
        )
        result = _check_online_update(url)
        _log(result.get("message") or result.get("error") or "联网更新检测完成")
        return result

    if action == "install_update":
        url = (
            data.get("url")
            if isinstance(data, dict) and data.get("url") is not None
            else params.get("update_manifest_url")
        )
        try:
            expected_version = data.get('expected_version') if isinstance(data, dict) else None
            result = _install_online_update(url, expected_version)
        except UpdateVersionChanged as error:
            result = {"ok": False, "recheck_required": True, "error": str(error)}
        except Exception as error:
            result = {"ok": False, "error": f"自动安装失败：{error}"}
        _log(result.get("message") or result.get("error") or "自动更新完成")
        return result

    if action == "set_headless_mode":
        enabled = _as_bool(
            data.get("enabled") if isinstance(data, dict) else None,
            params.get("headless_mode", False),
        )
        probe = dict(params)
        probe["headless_mode"] = enabled
        status = _manager_api_status() or {}
        running = [
            _as_int(index, 0, 1) for index in (status.get("running") or [])
        ]
        if not running:
            running = [
                index
                for index in _account_range(probe)
                if _devtools_ready(probe["base_port"] + index)
            ]
        changed = 0
        for index in running:
            if enabled:
                changed += _set_account_windows_visible(index, probe, False)
            else:
                changed += _set_account_windows_visible(index, probe, True)
        mode = "开启" if enabled else "关闭"
        _log(f"无头运行已{mode}，处理 {changed} 个账号窗口")
        return {
            "ok": True,
            "message": f"无头运行已{mode}；已处理 {changed} 个账号窗口。",
        }

    if action == "set_force_account_start":
        enabled = _as_bool(
            data.get("enabled") if isinstance(data, dict) else None,
            params.get("force_account_start", False),
        )
        start = _as_int(
            data.get("account_start") if isinstance(data, dict) else None,
            params.get("account_start", 1),
            1,
        )
        if enabled:
            with _account_condition:
                _batch_logged_out.clear()
                _batch_unavailable.clear()
                _batch_insufficient_quota.clear()
                state = _load_state_unlocked()
                state["last_account"] = None
                _save_state_unlocked(state)
                _account_condition.notify_all()
            _log(f"已锁定从账号{start}开始，并清除本轮旧的跳过记录")
        return {
            "ok": True,
            "message": (
                f"已指定从账号{start}开始生成。"
                if enabled
                else "已恢复自动接着上次账号调度。"
            ),
        }

    if action == "detect_manager_port":
        probe = dict(params)
        if isinstance(data, dict) and data.get("manager_root") is not None:
            probe["manager_root"] = str(data.get("manager_root") or "").strip()
        auto_detected = False
        if not str(probe.get("manager_root") or "").strip():
            running = _running_anne_workbench_roots()
            if len(running) > 1:
                return {
                    "ok": False,
                    "ambiguous": True,
                    "error": "检测到多个正在运行的 Anne 工作台，请在设置中手动选择要使用的目录。",
                }
            if running:
                manager_root, launcher = _resolve_manager_launcher(running[0])
                auto_detected = True
            else:
                manager_root, launcher = _manager_paths(probe)
        else:
            manager_root, launcher = _manager_paths(probe)
        if not launcher.is_file():
            return {
                "ok": False,
                "error": (
                    "没有在所填路径中找到 Dola长登码管理器.exe "
                    f"或 launcher*.exe：{launcher}"
                ),
            }
        api_mode = _manager_uses_local_api(manager_root, launcher)
        base_port = 9221 if api_mode else 19221
        first_account = _as_int(probe.get("account_start"), 1, 1)
        first_port = base_port + first_account
        manager_note = "，管理接口 8888" if api_mode else ""
        if _port_open(first_port) and not _devtools_ready(first_port):
            port_note = f"；警告：端口 {first_port} 已被其他程序占用"
        elif _devtools_ready(first_port):
            port_note = f"；账号{first_account}端口 {first_port} 已就绪"
        else:
            port_note = f"；账号{first_account}将使用 {first_port}"
        return {
            "ok": True,
            "manager_root": str(Path(manager_root).resolve()),
            "launcher": launcher.name,
            "auto_detected": auto_detected,
            "base_port": base_port,
            "manager_api_port": 8888 if api_mode else None,
            "message": (
                f"已识别 {launcher.name}：调试端口起点 {base_port}"
                f"{manager_note}{port_note}。"
            ),
        }

    if action == "check_environment":
        manager_root, launcher = _manager_paths(params)
        checks = []
        checks.append((launcher.is_file(), f"管理器：{launcher}"))
        checks.append(((manager_root / "_internal" / "launcher_core.py").is_file(), "账号启动辅助入口"))
        try:
            from playwright.sync_api import sync_playwright as _unused
            checks.append((True, "Playwright：可用"))
        except Exception as error:
            checks.append((False, f"Playwright：{error}"))
        failed = [label for ok, label in checks if not ok]
        if failed:
            return {"ok": False, "error": "；".join(failed)}
        return {"ok": True, "message": "环境检查通过，可以连接本地 Dola 客户端。"}

    if action == "open_first_account":
        try:
            manager_root, launcher = _manager_paths(params)
            _ensure_manager_api(manager_root, launcher, params)
            _ensure_network_preflight()
            index = params["account_start"]
            port = _ensure_account_browser(index, params)
            hidden = _apply_headless_mode(index, params)
            suffix = f"，已隐藏 {hidden} 个窗口" if hidden else ""
            return {
                "ok": True,
                "message": f"账号{index}本地 Dola 已启动，调试端口 {port}{suffix}。",
            }
        except Exception as error:
            return {"ok": False, "error": str(error)}

    if action == "show_account_state":
        payload = {"ok": True, "message": _account_state_message(params)}
        if str(params.get("target_platform") or "") == "dola":
            try:
                payload["dola"] = _dola_state_snapshot(params)
            except Exception as error:
                payload["dola"] = None
                payload["message"] = _account_state_message(params) + f"（明细读取失败：{error}）"
        return payload

    if action == "reset_daily_usage":
        with _state_lock:
            _save_state_unlocked(_empty_state())
            _batch_logged_out.clear()
            _batch_unavailable.clear()
            _batch_insufficient_quota.clear()
        return {"ok": True, "message": "今日账号计数和本批次跳过状态已重置。"}

    if action == "stop_generation":
        with _generation_condition:
            if _generation_stop_in_progress:
                return {"ok": True, "message": "正在停止任务并关闭账号窗口，请稍候。"}
            _generation_stop_in_progress = True
            _stop_event.set()
            _pause_event.clear()
            cancelled = len(_generation_waiting)
            for entry in _inflight_generations.values():
                entry["cancelled"] = True
            _generation_waiting.clear()
            _generation_condition.notify_all()
        try:
            with _account_condition:
                _account_condition.notify_all()
            status = _manager_api_status() or {}
            running = [
                _as_int(index, 0, 1)
                for index in (status.get("running") or [])
            ]
            if not running:
                running = [
                    index
                    for index in _account_range(params)
                    if _port_open(params["base_port"] + index)
                ]
            closed = 0
            for index in running:
                if index and _close_account_browser(index, params):
                    closed += 1
            return {
                "ok": True,
                "message": f"已发送停止指令，取消 {cancelled} 个排队任务，并关闭 {closed} 个 Dola 账号窗口。",
            }
        finally:
            with _generation_condition:
                _generation_stop_in_progress = False
                _generation_condition.notify_all()

    return {"ok": False, "error": f"未知动作：{action}"}


_append_runtime_log(f"插件 v{_PLUGIN_VERSION} 已加载，等待生成任务", "info")
