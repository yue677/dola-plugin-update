# -*- coding: utf-8 -*-
"""Offline authorization guard used only by the distributable plugin copy."""

from __future__ import annotations

import base64
import ctypes
import ctypes.wintypes
import hashlib
import hmac
import json
import os
import socket
import time
import urllib.request
import winreg
from datetime import datetime
from pathlib import Path

from license_public import PUBLIC_EXPONENT, PUBLIC_MODULUS_B64

_SHA256_DIGEST_INFO_PREFIX = bytes.fromhex("3031300d060960864801650304020105000420")
_CLOCK_REGISTRY_PATH = r"Software\DolaAuthorizedPlugin"


class AuthorizationError(RuntimeError):
    pass


def _base64url_decode(value: str) -> bytes:
    value = "".join(str(value or "").split())
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def _current_user_sid() -> str:
    token_query = 0x0008
    token_user = 1
    advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.GetCurrentProcess.restype = ctypes.wintypes.HANDLE
    advapi32.OpenProcessToken.argtypes = [
        ctypes.wintypes.HANDLE,
        ctypes.wintypes.DWORD,
        ctypes.POINTER(ctypes.wintypes.HANDLE),
    ]
    advapi32.OpenProcessToken.restype = ctypes.wintypes.BOOL
    advapi32.GetTokenInformation.argtypes = [
        ctypes.wintypes.HANDLE,
        ctypes.c_int,
        ctypes.c_void_p,
        ctypes.wintypes.DWORD,
        ctypes.POINTER(ctypes.wintypes.DWORD),
    ]
    advapi32.GetTokenInformation.restype = ctypes.wintypes.BOOL
    advapi32.ConvertSidToStringSidW.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.wintypes.LPWSTR),
    ]
    advapi32.ConvertSidToStringSidW.restype = ctypes.wintypes.BOOL
    kernel32.CloseHandle.argtypes = [ctypes.wintypes.HANDLE]
    kernel32.CloseHandle.restype = ctypes.wintypes.BOOL
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p
    token = ctypes.wintypes.HANDLE()
    if not advapi32.OpenProcessToken(kernel32.GetCurrentProcess(), token_query, ctypes.byref(token)):
        raise AuthorizationError("无法读取当前 Windows 用户信息")
    try:
        needed = ctypes.wintypes.DWORD(0)
        advapi32.GetTokenInformation(token, token_user, None, 0, ctypes.byref(needed))
        buffer = ctypes.create_string_buffer(needed.value)
        if not advapi32.GetTokenInformation(
            token, token_user, buffer, needed, ctypes.byref(needed)
        ):
            raise AuthorizationError("无法读取当前 Windows 用户 SID")
        sid_pointer = ctypes.cast(buffer, ctypes.POINTER(ctypes.c_void_p))[0]
        string_sid = ctypes.wintypes.LPWSTR()
        if not advapi32.ConvertSidToStringSidW(sid_pointer, ctypes.byref(string_sid)):
            raise AuthorizationError("无法转换当前 Windows 用户 SID")
        try:
            return string_sid.value
        finally:
            kernel32.LocalFree(string_sid)
    finally:
        kernel32.CloseHandle(token)


def current_machine_code() -> str:
    try:
        with winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Microsoft\Cryptography",
            0,
            winreg.KEY_READ | winreg.KEY_WOW64_64KEY,
        ) as key:
            machine_guid = str(winreg.QueryValueEx(key, "MachineGuid")[0])
    except OSError as exc:
        raise AuthorizationError(f"无法读取机器标识：{exc}")
    sid = _current_user_sid()
    machine_name = os.environ.get("COMPUTERNAME") or socket.gethostname()
    digest = hashlib.sha256(
        f"{machine_guid}|{sid}|{machine_name}".encode("utf-8")
    ).hexdigest().upper()[:24]
    return "-".join(digest[index:index + 6] for index in range(0, 24, 6))


def _verify_signature(payload: bytes, signature: bytes) -> bool:
    modulus = int.from_bytes(base64.b64decode(PUBLIC_MODULUS_B64), "big")
    key_size = (modulus.bit_length() + 7) // 8
    if len(signature) != key_size:
        return False
    encoded = pow(int.from_bytes(signature, "big"), PUBLIC_EXPONENT, modulus).to_bytes(
        key_size, "big"
    )
    digest_info = _SHA256_DIGEST_INFO_PREFIX + hashlib.sha256(payload).digest()
    padding_size = key_size - len(digest_info) - 3
    expected = b"\x00\x01" + b"\xff" * padding_size + b"\x00" + digest_info
    return padding_size >= 8 and hmac.compare_digest(encoded, expected)


def _resolve_manager_root(manager_path: str) -> Path:
    text = os.path.expandvars(os.path.expanduser(str(manager_path or "").strip().strip('"')))
    if not text:
        raise AuthorizationError("请先在插件设置中填写“授权版多开器路径”")
    path = Path(text).resolve()
    if path.is_file():
        path = path.parent
    if not path.exists():
        raise AuthorizationError(f"多开器路径不存在：{path}")
    return path


def _load_license_key(manager_root: Path) -> str:
    candidates = [
        manager_root / "Data" / "license.json",
        manager_root / "data" / "license.json",
        manager_root / "license.json",
    ]
    for path in candidates:
        if not path.is_file():
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8-sig"))
        except Exception as exc:
            raise AuthorizationError(f"授权文件读取失败：{exc}")
        for field in ("LicenseKey", "licenseKey", "license_key", "Key", "key"):
            value = str(data.get(field) or "").strip()
            if value:
                return value
        raise AuthorizationError("多开器授权文件中没有卡密，请先完成激活")
    raise AuthorizationError("没有找到多开器授权文件，请先打开授权版多开器并完成激活")


def _load_license_record(manager_root: Path) -> dict:
    path = manager_root / "Data" / "license.json"
    if not path.is_file() or path.is_symlink() or path.stat().st_size > 64 * 1024:
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception as exc:
        raise AuthorizationError(f"授权文件读取失败：{exc}")
    return value if isinstance(value, dict) else {}


def _online_grant_present(record: dict) -> bool:
    # A saved online grant takes precedence over a legacy card.  This keeps an
    # expired/revoked grant from silently reopening through an old card left in
    # the same file after an update.
    return bool(str(record.get("OnlineGrant") or "").strip())


def _validate_workbench_grant(manager_root: Path, record: dict) -> dict:
    service = manager_root / "Data" / "desktop" / "service.json"
    if not service.is_file() or service.is_symlink() or service.stat().st_size > 8192:
        raise AuthorizationError("Anne 工作台尚未启动，请先打开工作台并完成联网授权")
    try:
        descriptor = json.loads(service.read_text(encoding="utf-8"))
        port = descriptor.get("port")
        if type(port) is not int or not 1 <= port <= 65535:
            raise ValueError("port")
        if descriptor.get("app_id") != "anne-workbench" or descriptor.get("edition") != "share":
            raise ValueError("identity")
        request = urllib.request.Request(
            f"http://127.0.0.1:{port}/desktop/license-status",
            headers={"Accept": "application/json"}, method="GET",
        )
        class _NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, *args, **kwargs):
                return None
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())
        with opener.open(request, timeout=2.5) as response:
            if response.geturl() != request.full_url:
                raise ValueError("redirect")
            raw = response.read(16385)
        if len(raw) > 16384:
            raise ValueError("response")
        status = json.loads(raw.decode("utf-8"))
    except AuthorizationError:
        raise
    except Exception as exc:
        raise AuthorizationError("工作台联网授权尚未确认，请先完成申请并批准") from exc
    if not isinstance(status, dict) or status.get("activated") is not True:
        raise AuthorizationError(str(status.get("message") or "工作台联网授权无效，请重新申请"))
    machine = str(record.get("MachineCode") or status.get("machine_code") or "").strip()
    return {
        "ok": True,
        "machine_code": machine,
        "expire_at": str(status.get("expires_at") or record.get("ExpiresAt") or "未知"),
        "manager_root": str(manager_root),
        "online": True,
    }


def _check_clock(now: int, license_hash: str) -> None:
    try:
        key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, _CLOCK_REGISTRY_PATH)
        try:
            last_seen, _ = winreg.QueryValueEx(key, "LastSeen")
            last_hash, _ = winreg.QueryValueEx(key, "LicenseHash")
        except OSError:
            last_seen, last_hash = 0, ""
        try:
            last_seen = int(last_seen)
        except Exception:
            last_seen = 0
        if last_hash == license_hash and now + 300 < last_seen:
            raise AuthorizationError("检测到系统时间被回拨，请恢复北京时间后再使用")
        winreg.SetValueEx(key, "LastSeen", 0, winreg.REG_QWORD, max(now, last_seen))
        winreg.SetValueEx(key, "LicenseHash", 0, winreg.REG_SZ, license_hash)
        winreg.CloseKey(key)
    except AuthorizationError:
        raise
    except OSError:
        # Registry hardening is supplemental; signature and expiry checks remain mandatory.
        pass


def validate_authorization(manager_path: str) -> dict:
    manager_root = _resolve_manager_root(manager_path)
    if not any(
        (manager_root / name).is_file()
        for name in (
            "Anne工作台.exe",
            "Dola长登码管理器.exe",
            "Dola长登码管理器_授权版.exe",
            "launcher_v182.exe",
            "Dola多开器_授权版.exe",
            "豆包Dola批量登录管理器_v2.exe",
        )
    ):
        raise AuthorizationError("所填目录中没有找到 Dola 长登码管理器授权版")
    record = _load_license_record(manager_root)
    if _online_grant_present(record):
        return _validate_workbench_grant(manager_root, record)
    license_key = _load_license_key(manager_root)
    parts = license_key.split(".")
    if len(parts) != 2:
        raise AuthorizationError("卡密格式错误")
    try:
        payload = _base64url_decode(parts[0])
        signature = _base64url_decode(parts[1])
    except Exception:
        raise AuthorizationError("卡密编码损坏")
    if not _verify_signature(payload, signature):
        raise AuthorizationError("卡密签名无效，请联系授权者重新生成")
    try:
        payload_text = payload.decode("utf-8")
        licensed_machine, expire_text = payload_text.rsplit("|", 1)
        expire_unix = int(expire_text)
    except Exception:
        raise AuthorizationError("卡密内容格式错误")
    machine = current_machine_code()
    if not hmac.compare_digest(licensed_machine.upper(), machine.upper()):
        raise AuthorizationError(f"卡密与本机不匹配，本机机器码：{machine}")
    now = int(time.time())
    if expire_unix <= now:
        expired_at = datetime.fromtimestamp(expire_unix).strftime("%Y-%m-%d %H:%M:%S")
        raise AuthorizationError(f"卡密已于 {expired_at} 到期")
    license_hash = hashlib.sha256(license_key.encode("utf-8")).hexdigest()
    _check_clock(now, license_hash)
    permanent = datetime.fromtimestamp(expire_unix).year >= 2099
    expire_at = "永久" if permanent else datetime.fromtimestamp(expire_unix).strftime(
        "%Y-%m-%d %H:%M:%S"
    )
    return {
        "ok": True,
        "machine_code": machine,
        "expire_at": expire_at,
        "manager_root": str(manager_root),
    }
