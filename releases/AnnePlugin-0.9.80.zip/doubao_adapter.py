"""Doubao web adapter. Uses the workbench's exact isolated page target, never Dola."""
import base64
import hashlib
import json
import re
import threading
import time
import urllib.parse
import urllib.request
from pathlib import Path
from datetime import datetime, timezone, timedelta
from contextlib import contextmanager

_locks = {}
_lock = threading.RLock()
_account_plans = {}

def diagnostic_event(page,event,**fields):
    try:
        writer=getattr(page,'diagnostic',None)
        if writer:writer(event,**fields)
    except Exception:
        pass


class QuotaRejected(RuntimeError):
    """The current response explicitly rejected generation before acceptance."""


class SubmissionIntegrityError(RuntimeError):
    """Observed an unexpected/split submission; never continue by sending text alone."""


class AccountPlanChanged(RuntimeError):
    """A presumed ordinary account became a confirmed member before submission."""

    def __init__(self,message,plan):
        super().__init__(message)
        if plan not in {'standard','trial'}:raise ValueError('Unconfirmed account plan')
        self.plan=plan


class AccountPlanUnavailable(RuntimeError):
    """The cached member plan no longer exposes the requested video model."""


class AccountLoggedOut(RuntimeError):
    """Definite login loss before submission, never a network/unknown state."""


class ContentRejectedAfterReceipt(RuntimeError):
    """The platform accepted a task, then rejected its content afterward."""


class FastNoReceipt(RuntimeError):
    """Two echoed Fast confirmations ended in another non-generation reply."""


FAST_NO_RECEIPT_RETRY_LIMIT=2


class FastAccountRotation(RuntimeError):
    """The original task was rechecked; release its lock before selecting another."""


def close_page(page):
    if page is not None:
        try:page.close()
        except Exception:pass  # A lost CDP socket must not retain the account lock.


def close_checked_account(page,row,folder,core):
    """Close a rejected inspection tab while its account lock is still held."""
    try:
        if page is None or getattr(page,'_anne_account_id',None)!=row['id']:return False
        target=getattr(page,'_anne_target_id',None)
        request=core.get('_manager_api_request')
        if not isinstance(target,str) or not target or not request:return False
        usage=account_usage(folder,row['id'])
        if any(usage.get(k) for k in ('pending','carried_pending','unresolved')):return False
        route=page.url
        parsed=urllib.parse.urlsplit(route)
        if parsed.scheme!='https' or parsed.hostname not in {'www.doubao.com','doubao.com'}:return False
        result=request('/desktop/platforms/'+row['id']+'/close',method='POST',
                       data={'target_id':target,'page_url':route},timeout=12)
        ok=result.get('success') is True
        core.get('_log',lambda text:None)('豆包账号检查完成，未使用的账号标签已关闭' if ok else
                                         '豆包账号检查完成，页面已变化或存在草稿，保留账号标签')
        return ok
    except Exception:
        core.get('_log',lambda text:None)('豆包账号检查完成，自动关闭未完成，可手动关闭账号标签')
        return False


def local_json(url, data=None):
    parsed=urllib.parse.urlsplit(url)
    if parsed.scheme!='http' or parsed.hostname not in {'127.0.0.1','localhost'}:
        raise RuntimeError('工作台接口必须位于本机')
    request=urllib.request.Request(url, data=json.dumps(data).encode() if data is not None else None,
                                   headers={'Content-Type':'application/json'})
    with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(request,timeout=20) as response:
        return json.load(response)


class Page:
    def __init__(self, account):
        import websocket
        tab=None
        for _ in range(20):
            tabs=local_json(account['cdp_url']+'/json/list')
            tab=next((t for t in tabs if t.get('id')==account['target_id'] and t.get('type')=='page'),None)
            if tab and tab.get('url','').startswith('https://'):break
            time.sleep(.5)
        if not tab:raise RuntimeError('豆包账号页面尚未就绪，请在工作台重新打开该账号')
        p=urllib.parse.urlsplit(tab['url'])
        if p.scheme!='https' or p.hostname not in {'www.doubao.com','doubao.com'}:
            raise RuntimeError('账号尚未进入豆包官网，请先完成登录')
        target=urllib.parse.urlsplit(tab['webSocketDebuggerUrl'])
        if target.hostname not in {'127.0.0.1','localhost'}:raise RuntimeError('账号调试地址不正确')
        self.ws=websocket.create_connection(tab['webSocketDebuggerUrl'],timeout=20,suppress_origin=True,
                                           http_no_proxy=['127.0.0.1','localhost'])
        self.seq=0
        self._anne_account_id=account.get('id')
        self._anne_target_id=account.get('target_id')
        self.report=lambda text:None
        self.check=lambda:None

    def call(self,method,params=None):
        import websocket
        self.seq+=1; ident=self.seq
        deadline=time.monotonic()+20
        self.ws.send(json.dumps(dict(id=ident,method=method,params=params or {})))
        while True:
            self.check()
            remaining=deadline-time.monotonic()
            if remaining<=0:raise RuntimeError(f'豆包页面响应超时（{method}，20 秒），请检查页面是否卡住')
            self.ws.settimeout(min(1.,remaining))
            try:raw=self.ws.recv()
            except websocket.WebSocketTimeoutException:continue
            if not raw:raise RuntimeError(f'豆包页面连接已断开（{method}）')
            result=json.loads(raw)
            if result.get('id')!=ident:continue
            if result.get('error'):raise RuntimeError(str(result['error'].get('message')))
            return result.get('result',{})

    def evaluate(self,expression):
        result=self.call('Runtime.evaluate',dict(expression=expression,returnByValue=True,awaitPromise=True))
        if result.get('exceptionDetails'):raise RuntimeError(str(result['exceptionDetails'].get('exception',{}).get('description','豆包页面操作未完成')).split('\n')[0])
        return result.get('result',{}).get('value')

    @property
    def url(self):return self.evaluate('location.href')

    def close(self):self.ws.close()

    def click(self, expression, before_click=None):
        point=self.evaluate('(()=>{const e=('+expression+');if(!e||e.disabled||e.getAttribute("aria-disabled")==="true"||getComputedStyle(e).visibility==="hidden")return null;const r=e.getBoundingClientRect();if(!r.width||!r.height)return null;return {x:r.x+r.width/2,y:r.y+r.height/2}})()')
        if not point:return False
        if before_click:before_click()
        for kind in ('mousePressed','mouseReleased'):
            self.call('Input.dispatchMouseEvent',dict(type=kind,button='left',clickCount=1,**point))
        return True

    def key(self,key,code):
        for kind in ('keyDown','keyUp'):
            self.call('Input.dispatchKeyEvent',dict(type=kind,key=key,code=key,windowsVirtualKeyCode=code))


def select_account(rows, params, preferred=None):
    rows=[r for r in rows if r.get('platform')=='doubao']
    if preferred:
        rows=[r for r in rows if r['id']==preferred]
    else:
        start=max(1,int(params.get('doubao_account_start') or 1))
        rows=sorted((r for r in rows if abs(int(r.get('index',0)))>=start),
                    key=lambda r:(bool(prefer_free_accounts(params) and r.get('plan') in {'standard','trial'}),abs(int(r['index']))))
    if not rows:raise RuntimeError('没有可用的豆包账号，请在 Anne 工作台点击 ＋ → 豆包，创建并登录账号')
    return rows


def prefer_free_accounts(params):
    return params.get('model')=='Seedance 2.0 Fast' and str(params.get('duration'))=='15'


def forced_start(params):
    """The Doubao start number doubles as a force switch, like Dola's queue.

    `doubao_account_start = 1` keeps the default behaviour: today's local quota
    accounting decides which account is opened.  Any higher number means the
    queue follows that number in index order and only the live page decides
    (logged out / no member plan / page-shows-quota-used are still skipped).
    """
    try:start=int(params.get('doubao_account_start') or 1)
    except (TypeError,ValueError):start=1
    return max(1,start)>1


def remembered_plan(row,folder):
    with _lock:
        observed=_account_plans.get((str(folder),row['id']))
    if observed and time.monotonic()-observed[1]<300:return observed[0]
    return row.get('plan','unknown')


def remember_plan(row,folder,plan):
    if plan in {'free','standard','trial'}:
        with _lock:_account_plans[(str(folder),row['id'])]=(plan,time.monotonic())


def account_pool(rows,params,folder,excluded,pinned=False):
    """Keep Fast ordinary/member pools separate, including concurrent reservations."""
    ordered=sorted(rows,key=lambda r:abs(int(r['index'])))
    records=quota_records(folder) if not pinned else []
    if not pinned and params.get('model')=='Seedance 2.0 Fast':
        skipped=fast_no_receipt_skips(records)
        for row in ordered:
            if row['id'] in skipped:
                excluded[row['id']]='Fast 今日两次新对话重提仍无回执，今天不再打开此账号'
    if not pinned and params.get('model') in {'Seedance 2.0','Seedance 2.5'}:
        rejected={r['account'] for r in records if r.get('member_unavailable')
                  and r.get('day')==today() and r.get('account')}
        for row in ordered:
            # Today's confirmed "no member model" marker outranks the card label,
            # so an expired membership is never opened again the same day.  An
            # explicit start number (>=2) is the user's override.
            if row['id'] in rejected and not forced_start(params):
                excluded[row['id']]='今日已确认该账号没有会员模型，今天不再打开重复识别'
    if pinned or not prefer_free_accounts(params):
        if not pinned:
            for row in ordered:
                if row['id'] in excluded:continue
                usage=account_usage(folder,row['id'],records)
                if usage.get('processing') and forced_start(params):
                    excluded[row['id']]='该账号已有任务正在生成，强制调度也不重复占用'
                elif not forced_start(params) and (usage.get('exhausted') or usage.get('remaining',0)<usage_cost(params)):
                    excluded[row['id']]='本机今日剩余额度不足本次生成，不再打开检查'
                elif not forced_start(params) and params.get('model') in {'Seedance 2.0','Seedance 2.5'} and remembered_plan(row,folder) not in {'standard','trial'}:
                    # Use the same saved plan as the account card. Unknown or
                    # unlabelled accounts must not be opened to discover a plan.
                    excluded[row['id']]='未标记标准/体验套餐，2.0 / 2.5 跳过此账号，不打开检查'
        return [r for r in ordered if r['id'] not in excluded],False
    for row in ordered:
        if row['id'] in excluded:continue
        usage=account_usage(folder,row['id'],records)
        if usage.get('unresolved'):
            excluded[row['id']]='原任务状态尚未确认，先继续原任务'
        elif usage.get('exhausted'):
            excluded[row['id']]='平台今日额度已确认用完'
        elif usage.get('remaining',0)<=0:
            excluded[row['id']]='本机今日成功/处理中额度已用完'
        elif usage['used']+usage_cost(params)>2:
            excluded[row['id']]='已达到本机今日提交上限'
    ordinary=[r for r in ordered if remembered_plan(r,folder) not in {'standard','trial'}]
    available=[r for r in ordinary if r['id'] not in excluded]
    if available:
        # One pass per credit: a free second slot must not leapfrog another
        # account's first slot, including one currently being prepared.
        first_round=min(daily_usage(folder,r['id']) for r in available)
        return [r for r in available if daily_usage(folder,r['id'])==first_round],True
    # Reserved/running ordinary jobs are not a reason to spend member quota.
    # Even the final reserved credit must finish before the fallback pool starts.
    with _lock:
        if any(_locks.get(r['id']) is not None and _locks[r['id']].locked() for r in ordinary):
            return [],True
    if any(account_usage(folder,r['id'])['pending'] for r in ordinary):
        # A local reservation is not proof the site's free quota ran out.
        # Preserve unresolved jobs instead of silently spending member quota.
        return [],True
    return [r for r in ordered if r['id'] not in excluded],False


def validate_params(params,already_submitted=False):
    allowed={'Seedance 2.0 Fast':{'15'},'Seedance 2.0':{'5','10','15'} if already_submitted else {'15'},'Seedance 2.5':{'30'}}
    if str(params.get('duration')) not in allowed.get(params.get('model'),set()):
        raise RuntimeError('豆包 2.0 / 2.0 Fast 使用 15 秒；2.5 使用 30 秒')
    if params.get('aspect_ratio') not in {'16:9','9:16'}:raise RuntimeError('请选择支持的画幅比例')


def reference_limit(params):
    """How many reference images Doubao's composer accepts for this model.

    Seedance 2.5 accepts 10 (the live composer allows the tenth reference);
    2.0 and 2.0 Fast keep the previous 9-image ceiling.
    """
    return 10 if params.get('model')=='Seedance 2.5' else 9


def assert_reference_count(params,count):
    """Refuse more references than this model's composer accepts, before upload."""
    limit=reference_limit(params)
    if count>limit:
        raise RuntimeError(f'{params.get("model") or "豆包"} 最多上传 {limit} 张参考图，请减少素材')


def today(now=None):
    return (now or datetime.now(timezone.utc)).astimezone(timezone(timedelta(hours=8))).date().isoformat()


def account_state(page):
    return page.evaluate((Path(__file__).parent/'doubao_account_state.js').read_text(encoding='utf8')) or {}


def settled_account_state(page,check,timeout=12):
    """Let the profile hydrate BEFORE opening a draft or uploading references."""
    started=time.monotonic();previous=None;stable=0
    while True:
        check();status=account_state(page)
        plan=status.get('plan','unknown')
        if plan=='logged_out':return status
        stable=stable+1 if plan==previous else 1
        previous=plan
        if plan in {'free','standard','trial'} and stable>=2:return status
        if time.monotonic()-started>=timeout:
            # Ordinary profiles may legitimately have no subscription label.
            # Unknown must never be silently promoted to a standard member.
            return status
        time.sleep(.5)


def usage_cost(params):
    return 2 if params.get('model')=='Seedance 2.5' else 1


def quota_records(folder):
    """Read atomic ledgers without mutating old jobs or exposing their contents."""
    records=[]
    for path in Path(folder).glob('*.json'):
        try:
            state=json.loads(path.read_text(encoding='utf8'))
            if not isinstance(state,dict):raise ValueError('Invalid task record')
        except (OSError,ValueError):
            raise RuntimeError('豆包任务记录暂时无法读取，未重置额度或重新提交；请保留记录后重试') from None
        records.append(state)
    return records


def mark_quota_exhausted(folder,account_id,day=None):
    """Persist a platform-confirmed exhaustion marker without reopening it."""
    day=day or today();folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    token=hashlib.sha256((str(account_id)+'-'+str(day)).encode('utf8')).hexdigest()
    path=folder/('quota-'+token+'.json')
    if path.exists():return
    payload=dict(account=str(account_id),day=day,submitted=True,quota_exhausted=True,
                 quota_cost=0,marker_schema=1)
    temporary=path.with_suffix('.json.update')
    temporary.write_text(json.dumps(payload,ensure_ascii=False),encoding='utf8')
    temporary.replace(path)


def mark_fast_no_receipt_skip(folder,account_id,day=None):
    """Skip a Fast account for the current Beijing day after retry exhaustion."""
    day=day or today();folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    token=hashlib.sha256(('fast-no-receipt-'+str(account_id)+'-'+str(day)).encode('utf8')).hexdigest()
    path=folder/('fast-no-receipt-'+token+'.json')
    if path.exists():return
    payload=dict(account=str(account_id),day=day,fast_no_receipt_skip=True,marker_schema=1)
    temporary=path.with_suffix('.json.update')
    temporary.write_text(json.dumps(payload,ensure_ascii=False),encoding='utf8')
    temporary.replace(path)


def fast_no_receipt_skips(records,day=None):
    day=day or today()
    return {str(r.get('account')) for r in records
            if r.get('fast_no_receipt_skip') is True and r.get('day')==day and r.get('account')}


def remember_member_unavailable(folder,account_id):
    """Persist a negative member-model check for this day without claiming free status."""
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    day=today()
    token=hashlib.sha256((str(account_id)+'-'+day).encode('utf8')).hexdigest()
    path=folder/('member-check-'+token+'.json')
    temporary=path.with_suffix('.json.update')
    temporary.write_text(json.dumps(dict(account=account_id,day=day,member_unavailable=True)),encoding='utf8')
    temporary.replace(path)


def account_usage(folder,account_id,records=None,day=None):
    """Count a use when a video is observed; failed/paused attempts use none."""
    day=day or today()
    result=dict(success=0,processing=0,unconfirmed=0,unresolved=0,used=0,remaining=2,
                capacity=2,exhausted=False,carried_pending=0,pending=0)
    for state in quota_records(folder) if records is None else records:
        if state.get('account')!=account_id or state.get('new_chat_exhausted'):continue
        current=state.get('day')==day
        if state.get('quota_exhausted'):
            if current:result['exhausted']=True
            continue
        if not state.get('submitted'):continue
        video_success=(state.get('media_observed') is True or state.get('returned_to_host') is True)
        failed=any(state.get(k) for k in ('failure','submission_integrity_error','mismatched_output'))
        accepted=bool(state.get('accepted') or state.get('button_confirmation_pending'))
        if not current:
            if not video_success and accepted and not failed:result['carried_pending']+=1
            continue
        try:cost=max(1,min(2,int(state.get('quota_cost',1))))
        except (TypeError,ValueError):cost=1
        if video_success:
            result['success']+=1;result['used']+=cost
        elif accepted and not failed:
            result['processing']+=1;result['used']+=cost
        elif not failed:
            result['unresolved']+=1
    result['pending']=result['processing']
    if result['exhausted']:result['used']=max(2,result['used'])
    result['remaining']=max(0,2-result['used'])
    return result


def daily_usage(folder,account_id):
    # Scheduling capacity includes active reservations and successful videos.
    return account_usage(folder,account_id)['used']


def quota_snapshot(folder,rows,params):
    records=quota_records(folder);day=today();accounts=[]
    for row in sorted((r for r in rows if r.get('platform')=='doubao'),key=lambda r:abs(int(r['index']))):
        usage=account_usage(folder,row['id'],records,day)
        plan=remembered_plan(row,folder)
        if plan not in {'free','standard','trial','unknown','logged_out'}:plan='unknown'
        accounts.append(dict(index=abs(int(row['index'])),plan=plan,
                             **{key:value for key,value in usage.items() if key!='unresolved'}))
    return dict(day=day,reset_timezone='Asia/Shanghai',reset_time='00:00',accounts=accounts,
                read_only=True,**{key:sum(r[key] for r in accounts) for key in
                ('success','processing','unconfirmed','remaining','capacity','carried_pending')})


def mark_host_return(context,params,core,result):
    """Idempotently count at the plugin's successful return boundary, never at 100%."""
    folder=Path(core['_PLUGIN_DIR'])/'data'/'doubao-tasks'
    key=core['_generation_call_key'](context,params)
    if not re.fullmatch(r'[A-Za-z0-9_-]+',str(key)):
        raise RuntimeError('豆包回传记录标识异常，未重复生成')
    path=folder/(key+'.json')
    with _lock:
        try:
            state=json.loads(path.read_text(encoding='utf8'))
            if not isinstance(state,dict):raise ValueError('Invalid task record')
            output=Path(state.get('output') or '')
            valid=(state.get('submitted') and state.get('account') and state.get('day')
                   and isinstance(result,list) and len(result)==1 and output.is_file()
                   and output.resolve()==Path(result[0]).resolve()
                   and _file_sha256(output)==state.get('sha256'))
        except (OSError,ValueError,TypeError):valid=False
        if not valid:raise RuntimeError('豆包原片回传校验未通过，未计成功；原任务保留，不重新生成')
        if state.get('returned_to_host') is True:return dict(state)
        state.update(returned_to_host=True,returned_at=datetime.now(timezone(timedelta(hours=8))).isoformat(),
                     return_schema=1)
        temporary=path.with_suffix('.json.returning')
        try:
            temporary.write_text(json.dumps(state,ensure_ascii=False),encoding='utf8')
            temporary.replace(path)
        except OSError:
            raise RuntimeError('豆包原片已保存，但回传计数写入失败；请继续原任务，不会重新生成') from None

    return dict(state)


def close_after_host_return(state,core):
    """Best-effort close at the verified plugin return boundary, never on download."""
    if not isinstance(state,dict) or state.get('returned_to_host') is not True:return False
    identifier=state.get('account');target=state.get('return_target_id');route=state.get('url')
    if not identifier or not target or not conversation_id(route):return False
    with _lock:account_lock=_locks.setdefault(identifier,threading.Lock())
    if not account_lock.acquire(blocking=False):return False
    try:
        request=core.get('_manager_api_request')
        if not request:return False
        result=request('/desktop/platforms/'+identifier+'/close',method='POST',
                       data={'target_id':target,'page_url':route},timeout=12)
        ok=result.get('success') is True
        core.get('_log',lambda text:None)('豆包原片回传校验已完成，账号标签已关闭；登录状态保留' if ok else
                                         '豆包原片回传校验已完成，页面已变化或存在草稿，保留账号标签')
        return ok
    except Exception:
        # A closed workbench/failed close must not turn a verified file into a
        # generation failure, and must never trigger a repeat submission.
        core.get('_log',lambda text:None)('豆包原片已保留，自动关闭未完成，可手动关闭账号标签')
        return False
    finally:account_lock.release()


def eligibility(status,params,used):
    if status.get('plan')=='logged_out':return '账号未登录'
    if params.get('model')!='Seedance 2.0 Fast' and status.get('plan') not in {'standard','trial'}:
        return '2.0 / 2.5 需要识别到标准/体验套餐'
    if not forced_start(params) and (status.get('exhausted') or status.get('remaining')==0):return '页面显示今日额度已用完'
    if not forced_start(params) and used+usage_cost(params)>2:return '已达到本机今日提交上限（Fast / 2.0 两个，或 2.5 一个）'
    return ''


def direct_mode(params):
    return params.get('model')=='Seedance 2.0 Fast' and params.get('_account_plan') not in {'standard','trial'}


def video_prompt(prompt,params):
    if not direct_mode(params):return prompt
    model={'Seedance 2.0 Fast':'seedance2.0fast','Seedance 2.0':'seedance2.0','Seedance 2.5':'seedance2.5'}[params['model']]
    return str(prompt or '').strip()+'\n\n视频模型：'+model+'。\n视频比例要求：'+params['aspect_ratio']+'。\n视频时长要求：'+str(params['duration'])+'s。'


def assistant_messages(page):
    # Observed Doubao DOM: user messages are justify-end; assistant roots are grid.
    return page.evaluate('''[...document.querySelectorAll('[data-message-id]')].filter(e=>e.classList.contains('grid')&&!e.classList.contains('justify-end')).map(e=>({id:e.getAttribute('data-message-id'),text:e.innerText,streaming:!!e.querySelector('[data-streaming="true"]')}))''') or []


def user_messages(page):
    return page.evaluate(USER_MESSAGES_JS) or []


USER_MESSAGES_JS=r'''(()=>{
 const identity=x=>typeof x==='string'?x:typeof x==='number'&&Number.isSafeInteger(x)?String(x):'';
 const conversation=location.pathname.match(/^\/chat\/(?:local_)?(\d+)\/?$/)?.[1]||'';
 const normalized=text=>text.replace(/\s+/g,' ').trim();
 const textOf=e=>{
  const messageId=e.getAttribute('data-message-id'),owned=new Map(),legacy=new Map(),seen=new WeakSet();
  let budget=2400,incomplete=false,foreign=false,identified=false;
  function walk(o,d){
   if(!o||typeof o!=='object'||o instanceof Node||seen.has(o))return;
   if(d>12||--budget<0){incomplete=true;return}seen.add(o);
   const blocks=o.content_block||o.contentBlocks||o.content_blocks_v2;
   if(Array.isArray(blocks)){
    const id=identity(o.message_id||o.messageId||o.id),chat=identity(o.conversation_id||o.conversationId);
    const texts=blocks.map(b=>b?.content?.text_block?.text).filter(x=>typeof x==='string');
    if(id)identified=true;
    if(id===messageId&&chat&&chat!==conversation)foreign=true;
    if(texts.length){const text=texts.join('\n');
     if(id===messageId&&(!chat||chat===conversation))owned.set(normalized(text),text);
     else if(!id&&(!chat||chat===conversation))legacy.set(normalized(text),text);
    }
    return; // A payload owns its blocks; quoted/attachment internals are not this message.
   }
   for(const k of Object.keys(o))if(!['_owner','return','sibling','alternate','stateNode','style'].includes(k))walk(o[k],d+1);
  }
  for(const n of [e,...e.querySelectorAll('[data-render-engine]')])for(const k of Object.keys(n))if(k.startsWith('__reactProps'))walk(n[k],0);
  // Never accept a preview before the complete payload, or resolve ambiguity by order.
  if(incomplete||foreign||owned.size>1)return '';
  if(owned.size===1)return owned.values().next().value;
  if(identified||legacy.size>1)return '';
  if(legacy.size===1)return legacy.values().next().value;
  const content=[...e.querySelectorAll('[data-render-engine][data-plugin-identifier="block_type:10000"]')];
  return content.length?content.map(n=>n.innerText).join('\n'):e.innerText.replace(/\n(?:展开全部|收起)\s*$/,'');
 };
 const rows=new Map();
 for(const e of document.querySelectorAll('[data-message-id]')){
  if(!e.classList.contains('justify-end'))continue;
  const id=e.getAttribute('data-message-id');if(!id)continue;
  const text=textOf(e);
  if(!rows.has(id))rows.set(id,{id,text});
  else if(normalized(rows.get(id).text)!==normalized(text))rows.get(id).text='';
 }
 return [...rows.values()];
})()'''


def prompt_fingerprint(text):
    return hashlib.sha256(re.sub(r'\s+', ' ', str(text or '')).strip().encode('utf8')).hexdigest()


def submission_matches(text,state):
    expected=state.get('prompt_fingerprint')
    if prompt_fingerprint(text)==expected:return True
    # The official video composer wraps its own outbound prompt with this prefix
    # and the selected parameters. Strip only that exact wrapper, then require the
    # hash. Newer builds also append the chosen resolution (720P / 1080P today);
    # an optional token of that exact shape is the only extra text accepted, and
    # the prompt part itself must still hash exactly.
    if state.get('account_plan') in {'standard','trial'} and text.startswith('生成视频：'):
        ratios=[state['aspect_ratio']] if state.get('aspect_ratio') else ['16:9','9:16']
        rest=text[5:]
        for ratio in ratios:
            base='，'+ratio+'，'+str(state.get('duration'))+'s'
            # Drop one trailing resolution token of the official shape before the
            # exact suffix comparison, so only that token may differ.
            tail=re.sub(r'[，,]\s*\d{3,4}\s*[Pp]$','',rest)
            if not tail.endswith(base):continue
            if prompt_fingerprint(tail[:-len(base)])==expected:return True
    return False


def conversation_id(url):
    try:
        parsed=urllib.parse.urlsplit(str(url or ''))
        official=(parsed.scheme=='https' and parsed.hostname in {'www.doubao.com','doubao.com'}
                  and parsed.username is None and parsed.password is None and parsed.port in (None,443))
    except ValueError:return None
    match=re.fullmatch(r'/chat/(?:local_)?(\d+)/?',parsed.path)
    return match[1] if official and match else None


def bind_submission_route(page,state,save):
    """Late routes may resume only when this exact new user message is present."""
    current=page.url; current_id=conversation_id(current); expected_id=conversation_id(state.get('url'))
    original_id=conversation_id(state.get('submission_route'))
    bound=state.get('route_bound') or (expected_id and expected_id!=original_id)
    if bound:
        if not current_id or current_id!=expected_id:
            raise RuntimeError('豆包对话已切换，请回到原任务继续取回；已阻止重复生成')
        return True
    fingerprint=state.get('prompt_fingerprint')
    if not state.get('submitted') or not fingerprint or not current_id:return False
    # The website can accept a new turn without changing its conversation URL.
    # Only a NEW exact user message outside the saved baseline binds this task;
    # an old receipt or an old identical prompt must never claim the new work.
    if current_id==original_id and 'user_message_ids' not in state:return False
    matches=[m for m in user_messages(page) if m['id'] not in state.get('user_message_ids',[]) and submission_matches(m['text'],state)]
    if len(matches)!=1 or conversation_id(page.url)!=current_id:return False
    previous=dict(state)
    state.update(url=current,route_bound=True,submitted_message_id=matches[0]['id'])
    try:save()
    except Exception:
        state.clear();state.update(previous)
        raise
    return True


def route_recovery_draft(page):
    """Read-only: never focus, clear, or discard an unrelated conversation's draft."""
    return page.evaluate(r'''(()=>{
      const visible=e=>{const r=e.getBoundingClientRect();return r.width&&r.height&&getComputedStyle(e).visibility!=='hidden'};
      const surfaces=[...document.querySelectorAll('.guidance-input-surface')].filter(visible);
      if(surfaces.length!==1)return {route:location.href,ready:false};
      const surface=surfaces[0];
      const editors=[...surface.querySelectorAll('textarea,.tiptap[contenteditable="true"],[contenteditable="true"][role="textbox"]')].filter(e=>visible(e)&&!e.disabled);
      if(editors.length!==1)return {route:location.href,ready:false};
      const editor=editors[0],text='''+COMPOSER_TEXT_JS+r'''(editor);
      const attachments=surface.querySelectorAll('[data-kind="image"],[data-kind="video"],[data-kind="audio"],[data-kind="file"],[class*="thumb-card-"],[class*="file-card-"],[class*="attachment-card"],[data-upload-id],[data-file-id],[data-attachment-id],[data-type="attachment"]').length;
      const selectedFiles=[...surface.querySelectorAll('input[type="file"]')].some(e=>e.files?.length);
      const inlineMedia=!!editor.querySelector('img,video,audio');
      const uploading=!!surface.querySelector('[role="progressbar"],[aria-busy="true"],[data-uploading="true"]');
      return {route:location.href,ready:true,empty:!text.trim(),attachments:attachments+(selectedFiles?1:0)+(inlineMedia?1:0),uploading,
        message_count:document.querySelectorAll('[data-message-id]').length};
    })()''')


def _recovery_source_route(url):
    """Only an official chat page may be left; never navigate away from login/payment."""
    if conversation_id(url):return True
    try:
        parsed=urllib.parse.urlsplit(str(url or ''))
        return (parsed.scheme=='https' and parsed.hostname in {'www.doubao.com','doubao.com'}
                and parsed.username is None and parsed.password is None and parsed.port in (None,443)
                and parsed.path in {'/chat','/chat/'})
    except ValueError:return False


def _route_recovery_loading_error(error):
    # These are the transient CDP errors produced by navigation destroying the
    # previous document. Unknown transport errors and user stops are not retried.
    return any(label in str(error) for label in ('Execution context was destroyed',
        'Cannot find context with specified id','Cannot find default execution context'))


def _ready_route_recovery_draft(page,current,check,deadline):
    """Allow a briefly loading composer, but never follow another manual route."""
    while True:
        check()
        draft=None
        try:
            if page.url!=current:
                raise RuntimeError('等待输入区域时对话再次变化，未自动离开；请手动回到原任务继续')
            draft=route_recovery_draft(page)
        except RuntimeError as error:
            if not _route_recovery_loading_error(error):raise
        if isinstance(draft,dict):
            if draft.get('route')!=current:
                raise RuntimeError('等待输入区域时页面再次变化，未自动离开；请手动回到原任务继续')
            # Even a partially loaded composer must not discard content already seen.
            if draft.get('empty') is False or draft.get('attachments') not in (None,0) or draft.get('uploading') is True:
                raise RuntimeError('当前对话有未发送内容或附件，已保留且未自动离开；请手动回到原生成对话继续')
            if draft.get('ready'):
                if draft.get('empty') is not True or draft.get('attachments')!=0 or draft.get('uploading') is not False:
                    raise RuntimeError('当前对话草稿状态尚未确认，已保留且未自动离开；请手动回到原任务继续')
                return draft
        if time.monotonic()>=deadline:
            raise RuntimeError('当前页面输入区域尚未加载完成，未自动离开；请回到原任务继续，不会重复生成')
        time.sleep(.25)


def _verify_recovered_task(page,state,save,check,progress):
    """A restored URL alone is insufficient: require the original message and hash."""
    expected_id=conversation_id(state.get('url'))
    deadline=time.monotonic()+20
    while True:
        check()
        current=None;matches=[]
        try:
            current=page.url
            if conversation_id(current)==expected_id:
                matches=[m for m in user_messages(page) if m.get('id')==state['submitted_message_id']]
        except RuntimeError as error:
            if not _route_recovery_loading_error(error):raise
        if current is not None and conversation_id(current)!=expected_id:
            raise RuntimeError('返回原任务时对话再次变化，已保留任务；请手动回到原对话，不会重复生成')
        if len(matches)==1 and submission_matches(matches[0].get('text',''),state):
            check()
            if conversation_id(page.url)!=expected_id:
                raise RuntimeError('核对原任务时对话再次变化，已保留任务；不会重复生成')
            state['route_recovery_pending']=False
            save()
            progress('已自动返回原生成对话，继续等待原视频；不会重新上传或发送',30)
            return bind_submission_route(page,state,save)
        if time.monotonic()>=deadline:
            raise RuntimeError('已返回原对话，但暂未核对到本任务原消息；任务已保留，不会重新上传或发送，请页面加载后继续')
        time.sleep(.25)


def ensure_task_route(page,state,save,check,progress):
    """Restore an already-bound submission, without any upload, send, or confirmation.

    Run before reading/auditing messages in every submitted-task poll. The caller
    must pass the original isolated Page carrying its verified account identity.
    Late route binding remains the existing read-only path; it never navigates.
    """
    check()
    current=page.url
    expected_id=conversation_id(state.get('url'))
    same_route=bool(expected_id and conversation_id(current)==expected_id)
    pending=bool(state.get('route_recovery_pending'))
    if same_route and not pending:return bind_submission_route(page,state,save)
    # Legacy/unbound ledgers can bind only by the existing exact-message rule.
    if not state.get('submitted') or not state.get('route_bound'):
        return bind_submission_route(page,state,save)
    recoverable=(expected_id and state.get('submitted_message_id') and not state.get('output')
                 and re.fullmatch(r'[a-f0-9]{64}',str(state.get('prompt_fingerprint','')))
                 and isinstance(getattr(page,'_anne_account_id',None),str)
                 and page._anne_account_id==state.get('account'))
    if not recoverable:
        raise RuntimeError('豆包对话已切换，缺少原任务的安全恢复信息；请手动回到原对话，已阻止重复生成')
    if same_route:return _verify_recovered_task(page,state,save,check,progress)
    if not _recovery_source_route(current):
        raise RuntimeError('账号页面不在豆包对话中，未自动跳转；请手动回到原任务，不会重复生成')
    try:
        count=int(state.get('route_recovery_count',0))
        last=float(state.get('route_recovery_last_at',0))
        if not -float('inf')<last<float('inf'):raise ValueError('invalid recovery timestamp')
    except (TypeError,ValueError,OverflowError):
        raise RuntimeError('原任务恢复记录异常，未自动跳转；请手动回到原对话，不会重复生成')
    now=time.time()
    if count<0 or count>=2 or (count and now-last<30):
        raise RuntimeError('对话连续切换，已暂停自动返回以免打断手动操作；请回到原任务继续，不会重复生成')
    # A newly opened conversation can briefly lack its composer. The same short
    # loading window covers all three readbacks; never navigate away during it.
    draft_deadline=time.monotonic()+6
    for attempt in range(2):
        _ready_route_recovery_draft(page,current,check,draft_deadline)
        if attempt==0:time.sleep(.2)
    check()
    progress('检测到误切对话，正在返回原生成任务；不会重新上传或发送',30)
    _ready_route_recovery_draft(page,current,check,draft_deadline)
    check()
    state.update(route_recovery_count=count+1,route_recovery_last_at=time.time(),route_recovery_pending=True)
    save()  # Only an attempted (possibly uncertain) navigation consumes a recovery.
    check()
    # Restore only the known exact official chat path, discarding query/fragment.
    target=urllib.parse.urlsplit(state['url'])
    result=page.call('Page.navigate',{'url':urllib.parse.urlunsplit((target.scheme,target.netloc,target.path,'',''))})
    if not isinstance(result,dict) or result.get('errorText') or result.get('isDownload'):
        raise RuntimeError('原任务对话暂时无法打开；任务已保留，不会重新上传或发送')
    # Page.navigate may return before location commits. Wait without navigating again.
    deadline=time.monotonic()+20
    while True:
        check()
        try:url=page.url
        except RuntimeError as error:
            if not _route_recovery_loading_error(error):raise
            url=current
        if conversation_id(url)==expected_id:break
        if url!=current:
            raise RuntimeError('返回原任务时页面跳到其他地址，已停止自动跳转；不会重复生成')
        if time.monotonic()>=deadline:
            raise RuntimeError('返回原任务对话超时；任务已保留，不会重新上传或发送')
        time.sleep(.25)
    return _verify_recovered_task(page,state,save,check,progress)


def generation_started(text):
    text=re.sub(r'[*_`]+','',str(text or ''))
    if re.search(r'视频(?:正在)?生成中|视频生成(?:任务)?(?:已提交(?:成功)?|提交成功|排队中|进行中|处理中)|你的视频(?:已经)?生成好了',text):return True
    if confirmation_requested(text):return False
    if re.search(r'(?:正在|已经开始|已开始)(?:为[你您])?(?:生成|制作)(?:一条|这条|该)?视频|(?:视频|生成)任务已(?:经)?(?:进入|加入)(?:生成)?队列',text):return True
    # An estimate or a storyboard's future tense alone is not an acceptance.
    return bool(re.search(r'本次(?:将)?使用\s*(?:Dreamina\s*)?Seedance\s*\d+[.．]\d+(?:\s*Fast)?\s*生成',text,re.I)
                and (receipt_wait_hint(text) or re.search(r'视频生成好后.{0,20}(?:发送|发给|通知)',text)))


def generation_receipt_ready(text,params):
    """Strictly recognize the platform's model/ETA receipt before stopping replies."""
    text=re.sub(r'[*_`]+','',str(text or ''))
    model=str(params.get('model') or '').strip()
    model_match=re.search(r'本次(?:将)?使用\s*(?:Dreamina\s*)?(Seedance\s*\d+[.．]\d+(?:\s*Fast)?)\s*生成',text,re.I)
    if not model_match:return False
    normalize=lambda value:re.sub(r'\s+','',str(value).replace('．','.')).lower()
    if normalize(model_match.group(1))!=normalize(model):raise RuntimeError('豆包实际使用的模型与请求不符，已停止；未自动重新生成')
    explicit=re.search(r'(?:生成|制作)\s*(?:一条|一个)?\s*(\d+)\s*(?:秒|s)(?=[^。！？\n]{0,100}视频)'
                       r'|视频(?:总)?时长\s*(?:为|是|：|:)?\s*(\d+)\s*(?:秒|s)',text,re.I)
    if explicit and int(next(g for g in explicit.groups() if g))!=int(params.get('duration') or 0):
        raise RuntimeError('豆包回执中的视频时长与请求不符，已停止；未自动重新生成')
    return bool(receipt_wait_hint(text)) and not confirmation_requested(text)


def receipt_wait_hint(text):
    """Display only the estimate present in this task's actual receipt, not an ETA."""
    plain=re.sub(r'[*_`]+','',str(text or ''))
    match=re.search(r'预计(?:需要)?\s*等待\s*(?:大约|约)?\s*\d+(?:\s*[-~～至到]\s*\d+)?\s*(?:分钟|小时|秒钟|秒)',plain)
    return re.sub(r'\s+',' ',match.group(0)).strip() if match else ''


def generation_wait_status(state,params,elapsed):
    seconds=max(0,int(elapsed));minutes,seconds=divmod(seconds,60)
    waited=f'{minutes} 分 {seconds} 秒' if minutes else f'{seconds} 秒'
    if state.get('media_observed'):
        return f'豆包已检测到视频，原片同步中；本轮已等待 {waited}；不重复提交',80
    if state.get('button_confirmation_pending'):
        label='已点击确认生成，等待平台受理' if state.get('button_confirmation_clicked') else '等待确认生成按钮就绪'
        return f'豆包{label}；本轮已等待 {waited}；不重复提交',25
    return f'豆包已受理，排队/生成中（{params["model"]}）；本轮已等待 {waited}；不重复提交',35


def quota_rejected(text):
    # A depleted balance in a successful receipt is not rejection of that video.
    if generation_started(text):return False
    return bool(re.search(r'(?:今日|今天).{0,16}(?:次数|额度).{0,12}(?:已(?:经)?(?:用完|耗尽|达(?:到)?上限)|不足)|(?:每日|今日)?免费额度已用完',text))


def task_replies(page,state,save):
    anchor=state.get('submitted_message_id')
    if not anchor:
        # Old ledgers can resume on their bound URL, but may never cause a resend.
        return [m for m in assistant_messages(page) if m['id'] not in state.get('message_ids',[])]
    rows=page.evaluate('''(()=>{const users=new Map(('''+USER_MESSAGES_JS+''').map(m=>[m.id,m.text])),seenUsers=new Set();
      return [...document.querySelectorAll('[data-message-id]')].filter(e=>{
        if(!e.classList.contains('justify-end'))return e.classList.contains('grid');
        const id=e.getAttribute('data-message-id');if(seenUsers.has(id))return false;
        seenUsers.add(id);return true;
      }).map(e=>{
        const id=e.getAttribute('data-message-id'),user=e.classList.contains('justify-end');
        return {id,text:user?(users.get(id)??e.innerText):e.innerText,user,streaming:!!e.querySelector('[data-streaming="true"]')};
      });})()''') or []
    start=next((n for n,m in enumerate(rows) if m['id']==anchor),None)
    if start is None:return []  # A virtualized/offscreen task is not another task.
    result=[];seen_confirmation=False;seen_button_request=False;seen_button_echo=False;seen_replies=set()
    for message in rows[start+1:]:
        if message.get('user'):
            latest=result[-1] if result else {}
            records=state.get('generation_replies',[])
            matching=[r for r in records if r['assistant_id']==latest.get('id') and r['assistant_id'] not in seen_replies
                      and (not r.get('user_message_id') or r['user_message_id']==message['id'])]
            if len(matching)==1 and generation_reply_echo(message['text'],state):
                record=matching[0];seen_replies.add(record['assistant_id']);seen_confirmation=True
                if not record.get('user_message_id'):
                    record['user_message_id']=message['id'];save()
                continue
            button_echo=(state.get('button_confirmation_clicked') and seen_button_request and not seen_button_echo and
                         latest.get('id')==state.get('button_confirmation_message_id') and
                         (prompt_fingerprint(message['text'])==prompt_fingerprint('确认生成') or generation_reply_echo(message['text'],state)))
            if button_echo and (not state.get('button_confirmation_user_message_id') or
                                state['button_confirmation_user_message_id']==message['id']):
                seen_button_echo=True
                if not state.get('button_confirmation_user_message_id'):
                    state['button_confirmation_user_message_id']=message['id'];save()
                continue
            if not state.get('confirmed') and not state.get('accepted') and not seen_confirmation and generation_reply_echo(message['text'],state) and needs_confirmation(str(latest.get('text',''))):
                state.update(confirmed=True,manual_confirmation=True,confirmation_message_id=message['id']);save()
            # Adopt exactly one legacy/manual confirmation, never arbitrary
            # same-text messages or a second unrecorded user continuation.
            allowed=(not records and latest and state.get('confirmed') and not seen_confirmation
                     and generation_reply_echo(message['text'],state))
            if not allowed or (state.get('confirmation_message_id') and message['id']!=state['confirmation_message_id']):
                if not state.get('conversation_continued'):
                    state['conversation_continued']=True;save()
                break
            seen_confirmation=True
            if not state.get('confirmation_message_id'):
                state['confirmation_message_id']=message['id'];save()
            state['generation_replies']=[dict(assistant_id=latest['id'],
                reply_fingerprint=prompt_fingerprint(latest['text']),user_message_id=message['id'],
                manual=bool(state.get('manual_confirmation')))];save()
            seen_replies.add(latest['id'])
        else:
            result.append(message)
            if message['id']==state.get('button_confirmation_message_id'):seen_button_request=True
    return result


def generation_reply_echo(text,state):
    # The standard video composer may wrap even a short follow-up. Accept only
    # its exact original ratio/duration wrapper, never arbitrary added text.
    return submission_matches(text,dict(state,prompt_fingerprint=prompt_fingerprint('生成视频')))


def confirmation_requested(text):
    text=re.sub(r'[*_`]+','',str(text or ''))
    return bool(re.search(
        r'(?:确认|确定)后[^\n。！？?]{0,40}(?:生成|制作)[^\n。！？?]{0,12}视频'
        r'|(?:请|你|您)(?:回复|确认)[^\n。！？?]{0,25}(?:生成视频|开始生成)'
        r'|回复[\s“「"\'：:]{0,4}生成视频'
        r'|(?:是否确认|确认吗|可以开始吗|是否开始)[^\n。！？?]{0,24}(?:生成|制作)[^\n。！？?]{0,8}视频'
        r'|(?:生成|制作)[^\n。！？?]{0,8}视频[^\n。！？?]{0,24}(?:是否确认|确认吗|可以开始吗|是否开始)'
        r'|(?:^|\n)\s*确认生成\s*[→➜➔›»>]?\s*(?:$|\n)',text))


def needs_confirmation(text):
    return confirmation_requested(text) and not generation_started(text)


def should_confirm(state,replies,stable_seconds):
    return (bool(state.get('submitted_message_id')) and not any(state.get(k) for k in ('conversation_continued','confirmed','accepted','button_confirmation_pending'))
            and bool(replies) and not any(m.get('streaming') for m in replies) and stable_seconds>=15
            and needs_confirmation(replies[-1]['text']))


def _generation_reply_ready(state,replies,stable_seconds,params):
    """Shared guards for a stable, unaccepted assistant turn."""
    if not state.get('submitted_message_id') or not replies or stable_seconds<15:return False
    if any(state.get(k) for k in ('conversation_continued','accepted','media_observed','output',
                                  'button_confirmation_pending','button_confirmation_clicked','retry_pending',
                                  'generation_reply_blocked')):return False
    records=state.get('generation_replies',[])
    if any(not r.get('user_message_id') for r in records):return False
    if state.get('confirmed') and not records:return False  # Legacy uncertain send.
    latest=replies[-1]
    if not latest.get('id') or not str(latest.get('text') or '').strip() or any(m.get('streaming') for m in replies):return False
    for reply in replies:
        text=reply.get('text','')
        if generation_started(text) or quota_rejected(text) or generation_failure(text) or generation_reply_blocker(text):return False
        if generation_receipt_ready(text,params):return False
    return True


def should_reply_generation(state,replies,stable_seconds,params):
    """Fast allows two echoed replies per chat; other models keep their policy."""
    if not _generation_reply_ready(state,replies,stable_seconds,params):return False
    records=state.get('generation_replies',[])
    if params.get('model')=='Seedance 2.0 Fast' and len(records)>=2:return False
    latest=replies[-1]
    return (latest['id'] not in {r['assistant_id'] for r in records}
            and state.get('last_generation_reply_assistant_id')!=latest['id'])


def should_retry_fast_no_receipt(state,replies,stable_seconds,params):
    if params.get('model')!='Seedance 2.0 Fast':return False
    records=state.get('generation_replies',[])
    if len(records)<2 or any(state.get(k) for k in ('failure','submission_integrity_error','preparation_blocked')):return False
    if not _generation_reply_ready(state,replies,stable_seconds,params):return False
    # The main loop resets stable_at when an exact user echo is persisted. That
    # quiet window is the no-receipt signal after the second confirmation; a
    # third assistant message is optional and will reset the window if it arrives.
    ids=[m['id'] for m in replies]
    return (all(r.get('assistant_id') in ids for r in records)
            and all(r.get('user_message_id') for r in records))


def confirm_fast_no_receipt_retry(page,state,replies,params,stable_seconds,save,check):
    """Recheck the original task immediately before abandoning its conversation."""
    if not should_retry_fast_no_receipt(state,replies,stable_seconds,params):return False
    check()
    if not bind_submission_route(page,state,save):return False
    if (getattr(page,'_anne_account_id',None)!=state.get('account') or
            (state.get('return_target_id') and getattr(page,'_anne_target_id',None)!=state['return_target_id'])):
        raise RuntimeError('豆包账号页面已变化，已停止新对话重提；请检查原任务')
    users=user_messages(page)
    anchor=[m for m in users if m['id']==state.get('submitted_message_id')]
    if len(anchor)!=1 or not submission_matches(anchor[0]['text'],state):
        raise RuntimeError('原任务消息尚未核对，已停止新对话重提')
    fresh=task_replies(page,state,save)
    if task_has_video(page,[m['id'] for m in fresh]):
        state['media_observed']=True;save();return False
    signature=lambda rows:[(m['id'],prompt_fingerprint(m['text']),bool(m.get('streaming'))) for m in rows]
    if signature(fresh)!=signature(replies):return False
    if not should_retry_fast_no_receipt(state,fresh,stable_seconds,params) or confirmation_button(page,fresh):return False
    for record in state.get('generation_replies',[]):
        echoes=[m for m in users if m['id']==record.get('user_message_id')]
        if len(echoes)!=1 or not generation_reply_echo(echoes[0]['text'],state):return False
    draft=route_recovery_draft(page)
    if (not isinstance(draft,dict) or not draft.get('ready') or not draft.get('empty')
            or draft.get('attachments')!=0 or draft.get('uploading')
            or conversation_id(draft.get('route'))!=conversation_id(state.get('url'))):
        raise RuntimeError('原对话输入框有草稿、附件或尚未就绪，已停止新对话重提')
    return True


def fast_reply_signature(replies):
    return [[m['id'],prompt_fingerprint(m['text']),bool(m.get('streaming'))] for m in replies]


def fast_reply_batch_round(state):
    records=state.get('generation_replies',[])
    if not state.get('submitted_message_id') or any(not r.get('user_message_id') for r in records):return []
    return [state['submitted_message_id']]+[r['user_message_id'] for r in records]


def fast_reply_batch_ready(state,replies,stable_seconds,params):
    if params.get('model')!='Seedance 2.0 Fast':return True
    batch=state.get('fast_reply_batch') or {}
    return bool(replies and fast_reply_batch_round(state) and batch.get('round')==fast_reply_batch_round(state)
                and batch.get('phase')=='refreshed' and stable_seconds>=15
                and not any(m.get('streaming') for m in replies)
                and set(batch.get('message_ids',[])).issubset({m['id'] for m in replies}))


def _fast_reply_refresh_identity(page,state):
    if (not state.get('route_bound') or not conversation_id(state.get('url'))
            or conversation_id(page.url)!=conversation_id(state['url'])
            or getattr(page,'_anne_account_id',None)!=state.get('account')
            or not state.get('return_target_id')
            or getattr(page,'_anne_target_id',None)!=state['return_target_id']):
        raise RuntimeError('豆包原账号或对话已变化，已停止刷新核对；任务保留，不会重复提交')
    users=user_messages(page)
    anchor=[m for m in users if m['id']==state.get('submitted_message_id')]
    if not anchor:return False
    if len(anchor)!=1 or not submission_matches(anchor[0]['text'],state):
        raise RuntimeError('豆包原提示词未通过核对，已保留任务，不会刷新或重复提交')
    for record in state.get('generation_replies',[]):
        echoes=[m for m in users if m['id']==record.get('user_message_id')]
        if not echoes:return False
        if len(echoes)!=1 or not generation_reply_echo(echoes[0]['text'],state):
            raise RuntimeError('豆包原确认消息已变化，已保留任务，不会重复提交')
    return True


def _fast_reply_refresh_draft(page):
    draft=route_recovery_draft(page)
    if (not isinstance(draft,dict) or not draft.get('ready')):return False
    if (draft.get('route')!=page.url or draft.get('empty') is not True
            or draft.get('attachments')!=0 or draft.get('uploading') is not False):
        raise RuntimeError('豆包输入框有草稿或附件，已停止刷新核对并保留内容；不会重复提交')
    return True


def _fast_reply_result_ready(page,state,replies,params,save):
    if task_has_video(page,[m['id'] for m in replies]):
        if not state.get('media_observed'):state['media_observed']=True;save()
        return True
    receipts=[m for m in replies if generation_started(m.get('text',''))]
    if receipts:
        for reply in receipts:validate_receipt(reply['text'],params)
        state['accepted']=True
        hint=receipt_wait_hint(receipts[-1]['text'])
        if hint:state['receipt_wait_hint']=hint
        save();return True
    return False


def _fast_reply_timeout_recovered(page,state,batch,params,save):
    """Accept a slow reload only after the exact task state is still visible."""
    if not _fast_reply_refresh_identity(page,state):return False
    if not _fast_reply_refresh_draft(page):return False
    fresh=task_replies(page,state,save)
    if state.get('conversation_continued') or any(m.get('streaming') for m in fresh):return False
    if _fast_reply_result_ready(page,state,fresh,params,save):return True
    message_ids={m.get('id') for m in fresh}
    if not set(batch.get('message_ids',())).issubset(message_ids):return False
    batch['phase']='refreshed';batch['recovery']='same_bound_document';save()
    return True


def _fast_reply_loader(page,state):
    result=page.call('Page.getFrameTree')
    frame=(result or {}).get('frameTree',{}).get('frame',{})
    if conversation_id(frame.get('url'))!=conversation_id(state.get('url')):return ''
    return str(frame.get('loaderId') or '')


def _wait_fast_reply_refresh(page,state,batch,params,save,check):
    deadline=time.monotonic()+20
    while True:
        check()
        try:
            if _fast_reply_refresh_identity(page,state):
                loader=_fast_reply_loader(page,state)
                if loader and loader!=batch.get('loader_id'):
                    fresh=task_replies(page,state,save)
                    if state.get('conversation_continued'):
                        raise RuntimeError('豆包刷新后出现其他用户消息，已保留原任务，不会重复提交')
                    if _fast_reply_result_ready(page,state,fresh,params,save):return
                    complete=set(batch['message_ids']).issubset({m['id'] for m in fresh})
                    if complete and _fast_reply_refresh_draft(page):return
        except RuntimeError as error:
            if not _route_recovery_loading_error(error):raise
        if time.monotonic()>=deadline:
            try:
                if _fast_reply_timeout_recovered(page,state,batch,params,save):
                    diagnostic_event(page,'fast_reply_refresh',success=True,recovery='same_bound_document')
                    getattr(page,'report',lambda text:None)('豆包刷新标记未变化，但原任务已核对，继续等待；不会重新上传素材')
                    return
            except RuntimeError as error:
                if not _route_recovery_loading_error(error):raise
            raise RuntimeError('豆包刷新后原任务页面尚未恢复；记录已保留，请稍后继续原任务，不会重新上传或发送')
        time.sleep(.25)


def refresh_fast_reply_batch(page,state,replies,params,stable_seconds,save,check,progress):
    """One reload per confirmed user turn; late results always win over more sends."""
    if params.get('model')!='Seedance 2.0 Fast':return False
    round_id=fast_reply_batch_round(state)
    if not round_id or any(state.get(k) for k in ('accepted','media_observed','output','conversation_continued',
                                                 'button_confirmation_pending','button_confirmation_clicked')):return False
    batch=state.get('fast_reply_batch') or {}
    if batch.get('round')==round_id:
        if batch.get('phase')=='refreshed':return False
        if batch.get('phase')=='refreshing':
            _wait_fast_reply_refresh(page,state,batch,params,save,check)
            batch['phase']='refreshed';save();return True
    if not _generation_reply_ready(state,replies,stable_seconds,params):return False
    expected=fast_reply_signature(replies)
    for _ in range(2):
        check()
        if not _fast_reply_refresh_identity(page,state):return False
        fresh=task_replies(page,state,save)
        if state.get('conversation_continued') or fast_reply_signature(fresh)!=expected:return False
        if _fast_reply_result_ready(page,state,fresh,params,save):return False
        if not _fast_reply_refresh_draft(page):return False
    loader=_fast_reply_loader(page,state)
    if not loader:raise RuntimeError('豆包原页面尚未就绪，已保留任务，暂不刷新或重复提交')
    check()
    batch=dict(round=round_id,phase='refreshing',message_ids=[m['id'] for m in fresh],loader_id=loader)
    state['fast_reply_batch']=batch;save()
    progress('豆包 Fast 回复已稳定，正在刷新原对话核对完整回复；不会重新上传素材',22)
    page.call('Page.reload',{'ignoreCache':False})
    _wait_fast_reply_refresh(page,state,batch,params,save,check)
    batch['phase']='refreshed';save()
    return True


def fast_retry_history(state):
    """Keep only retry metadata across the existing failure/rotation transitions."""
    return {k:state[k] for k in ('fast_no_receipt_retries','fast_no_receipt_account','avoid_accounts',
                                 'fast_no_receipt_avoid_day','fast_no_receipt_avoid_accounts',
                                 'rejected_attempts') if k in state}


def generation_reply_blocker(text):
    """Fixed categories only; never store the assistant's private full reply."""
    if re.search(r'验证码|安全验证|人机验证|请.{0,8}(?:登录|登陆)|登录(?:已)?(?:失效|过期)|verify.{0,10}human|log\s*in',text,re.I):
        return '登录或安全验证需要手动处理'
    if re.search(r'(?:访问|请求|操作|生成).{0,8}(?:频繁|过快)|(?:系统|服务).{0,8}(?:繁忙|异常|不可用)|稍后再试|rate.?limit|too many requests',text,re.I):
        return '平台限流或暂时不可用'
    if content_rejection(text):return '内容合规审查拒绝'
    if re.search(r'(?:额度|次数|积分|余额).{0,10}(?:不足|耗尽|用完)|(?:不支持|无法|不能|不允许).{0,15}(?:生成|制作).{0,10}视频|违反.{0,8}(?:规则|政策)|内容.{0,8}(?:违规|不合规)|无法满足.{0,12}(?:请求|要求)',text):
        return '平台拒绝本次生成或额度不足'
    return ''


def content_rejection(text):
    """Recognize the post-receipt content refusal without storing its prose."""
    return bool(re.search(
        r'(?:疑似|可能).{0,30}(?:侵权|违规)|(?:侵权|违规).{0,20}内容'
        r'|无法返回该内容|换个主题再试试|生成额度未扣除',str(text or ''),re.I))


def send_generation_reply(page,state,replies,params,save,check):
    """One reserved send per assistant turn; an uncertain Enter is never retried."""
    expected=[(m['id'],prompt_fingerprint(m['text']),bool(m.get('streaming'))) for m in replies]
    def ready(prepared=False):
        check();bind_submission_route(page,state,save)
        if getattr(page,'_anne_account_id',None)!=state.get('account'):
            raise RuntimeError('豆包账号已变化，未发送确认；请检查原任务')
        anchor=[m for m in user_messages(page) if m['id']==state.get('submitted_message_id')]
        if len(anchor)!=1 or not submission_matches(anchor[0]['text'],state):
            raise RuntimeError('原任务消息尚未核对，未发送确认；不会重提提示词')
        fresh=task_replies(page,state,save)
        if task_has_video(page,[m['id'] for m in fresh]):
            state['media_observed']=True;save();return False
        if [(m['id'],prompt_fingerprint(m['text']),bool(m.get('streaming'))) for m in fresh]!=expected:return False
        if not should_reply_generation(state,fresh,15,params) or confirmation_button(page,fresh):return False
        draft=route_recovery_draft(page)
        if (not isinstance(draft,dict) or not draft.get('ready') or draft.get('attachments')!=0 or draft.get('uploading')
                or conversation_id(draft.get('route'))!=conversation_id(state.get('url'))
                or (not prepared and not draft.get('empty'))):
            raise RuntimeError('原对话输入框有草稿、附件或尚未就绪，未发送确认；请检查后继续')
        return True
    if not ready():return False
    class ReplyChanged(RuntimeError):pass
    def reserve():
        if not ready(prepared=True):raise ReplyChanged()
        latest=replies[-1]
        state.setdefault('generation_replies',[]).append(dict(assistant_id=latest['id'],
            reply_fingerprint=prompt_fingerprint(latest['text'])))
        state['confirmed']=True
        save()  # Reserve before Enter, including uncertain transport/restarts.
    try:send_composer(page,'生成视频',check,reserve)
    except ReplyChanged:return False
    return True


def confirmation_button_expression(message_id):
    return r'''(()=>{
      const root=[...document.querySelectorAll('[data-message-id]')].find(e=>e.getAttribute('data-message-id')==='''+json.dumps(message_id)+r''');
      if(!root||root.classList.contains('justify-end')||root.querySelector('video,[class*="block-video-"]'))return null;
      const matches=[...root.querySelectorAll('button,[role="button"],a,[class*="button"]')].filter(e=>{
        const r=e.getBoundingClientRect();return r.width&&r.height&&getComputedStyle(e).visibility!=='hidden'&&
          (e.innerText||'').replace(/\s+/g,'').replace(/[→➜➔›»>]+$/,'')==='确认生成';
      });
      const leaves=matches.filter(e=>!matches.some(other=>other!==e&&e.contains(other)));
      return leaves.length===1?leaves[0]:null;
    })()'''


def confirmation_button(page,replies):
    if not replies:return None
    latest=replies[-1]
    value=page.evaluate('(()=>{const e=('+confirmation_button_expression(latest['id'])+');'
                        'if(!e)return null;return {present:true,enabled:!e.disabled&&e.getAttribute("aria-disabled")!=="true"}})()')
    if not isinstance(value,dict) or value.get('present') is not True:return None
    return dict(value,message_id=latest['id'])


def handle_generation_confirmation(page,state,replies,stable_seconds,save,check,progress):
    """Persist before the native button click; no retry after an ambiguous click."""
    if not state.get('submitted_message_id') or any(state.get(k) for k in ('conversation_continued','media_observed','output')):
        return False
    if any(not r.get('user_message_id') for r in state.get('generation_replies',[])):return False
    if any(generation_started(m.get('text','')) for m in replies):return False
    if replies and (generation_reply_blocker(replies[-1]['text']) or generation_failure(replies[-1]['text']) or quota_rejected(replies[-1]['text'])):return False
    control=confirmation_button(page,replies)
    if not control:return False
    if re.search(r'视频(?:正在)?生成中|视频生成(?:任务)?(?:已提交(?:成功)?|提交成功|排队中|进行中|处理中)|你的视频(?:已经)?生成好了',str(replies[-1].get('text',''))):
        return False
    if task_has_video(page,[m['id'] for m in replies]):return False
    if not state.get('button_confirmation_pending') or state.get('accepted'):
        state['button_confirmation_pending']=True;state['accepted']=False;save()
        progress('豆包要求点击确认生成，正在核对原任务',25)
    if state.get('button_confirmation_clicked') or not control.get('enabled') or stable_seconds<2 or any(m.get('streaming') for m in replies):
        return True
    check();bind_submission_route(page,state,save)
    fresh=task_replies(page,state,save)
    if state.get('conversation_continued') or not fresh or fresh[-1]['id']!=control['message_id'] or any(m.get('streaming') for m in fresh):
        return True
    def mark_clicked():
        check()
        bind_submission_route(page,state,save)
        current=task_replies(page,state,save)
        if state.get('conversation_continued') or not current or current[-1]['id']!=control['message_id']:
            raise RuntimeError('原对话已变化，尚未点击确认生成；请检查原任务')
        state.update(button_confirmation_clicked=True,button_confirmation_message_id=control['message_id'])
        save()  # A restart or transport error must not spend credits twice.
    clicked=page.click(confirmation_button_expression(control['message_id']),before_click=mark_clicked)
    if clicked:
        diagnostic_event(page,'submission_key',method='button',count=1)
        progress('已点击“确认生成”，等待平台受理；不会重复点击',25)
    return True


def should_retry_new_chat(state,replies,stable_seconds,has_video=False):
    # Compatibility for old integrations: text replies never re-upload a task.
    return False


def task_has_video(page,message_ids):
    return bool(page.evaluate('''(()=>{const ids='''+json.dumps(list(message_ids))+''';return [...document.querySelectorAll('[data-message-id]')].some(e=>ids.includes(e.getAttribute('data-message-id'))&&!!e.querySelector('video,[class*="block-video-"]'))})()'''))


def validate_receipt(text,params):
    generation_receipt_ready(text,params)
    if re.search(r'(?:暂不支持|无法生成|不能生成|不支持).{0,12}'+str(params['duration'])+r'\s*(?:秒|s)',text,re.I):
        raise RuntimeError('豆包回复不支持本次时长，已停止；未降低时长或重复生成')


def generation_failure(text):
    match=re.search(r'(?:无法|不能|暂不能)针对.{0,25}(?:图片|素材).{0,20}(?:创作|生成)|(?:视频生成|生成视频|视频制作)(?:失败|未成功)|请更换(?:图片|素材)后再试',text)
    return str(text).strip()[:220] if match else ''


COMPOSER_TEXT_JS=r'''(e=>{
 if(!e)return '';
 if(e.tagName==='TEXTAREA')return e.value;
 const doc=e.editor?.view?.state?.doc||e.editor?.state?.doc||e.pmViewDesc?.node;
 // A block separator alone drops ProseMirror's inline hardBreak nodes. Keep
 // actual line breaks, and never silently discard an unfamiliar inline atom.
 if(doc?.textBetween)return doc.textBetween(0,doc.content.size,'\n',node=>{
  if(/^(hard_?break|line_?break)$/i.test(node.type?.name||'')||node.type?.spec?.linebreakReplacement)return '\n';
  return typeof node.type?.spec?.leafText==='function'?node.type.spec.leafText(node):'\ufffc';
 });
 // DOM fallback uses explicit text/block/BR nodes, not visual line wrapping.
 const isBlock=n=>n.nodeType===1&&/^(P|DIV|LI|UL|OL|BLOCKQUOTE|PRE|H[1-6])$/.test(n.tagName);
 function read(node){
  if(node.nodeType===3)return node.nodeValue||'';
  if(node.nodeType!==1)return '';
  if(node.tagName==='BR')return node.classList.contains('ProseMirror-trailingBreak')?'':'\n';
  if(/^(SCRIPT|STYLE)$/.test(node.tagName))return '';
  const children=[...node.childNodes].filter(n=>n.nodeType===1||n.nodeType===3);
  if(isBlock(node)&&children.length===1&&children[0].nodeType===1&&children[0].tagName==='BR')return '';
  if(!children.length)return /^(IMG|VIDEO|AUDIO|INPUT|HR)$/.test(node.tagName)?'\ufffc':'';
  let text='',previous=null;
  for(const child of children){
   if(previous&&(isBlock(previous)||isBlock(child)))text+='\n';
   text+=read(child);previous=child;
  }
  return text;
 }
 return read(e);
})'''


def composer_snapshot(page,focus=False):
    return page.evaluate('''(()=>{const e=document.querySelector('[data-anne-composer]');if(!e)return null;'''+('e.focus();' if focus else '')+'''
    const surface=e.closest('.guidance-input-surface');
    const video=!![...(surface?.querySelectorAll('[data-input-engine-actionbar-control-key="video-model"]')||[])].find(n=>{const r=n.getBoundingClientRect();return r.width&&r.height&&getComputedStyle(n).visibility!=='hidden'});
    return {text:'''+COMPOSER_TEXT_JS+'''(e),focused:document.activeElement===e||e.contains(document.activeElement),route:location.href,mode:video?'video':'chat'};})()''')


def composer_input_text(text):
    # Qt Chromium preserves CR in CDP insertText, then ProseMirror turns it into
    # a space. Canonicalize line endings BEFORE input, without trimming any
    # spaces, tabs, blank lines, punctuation or user-visible text.
    return str(text or '').replace('\r\n','\n').replace('\r','\n')


def normalized_composer_text(text):
    # Rendering inserts blank lines between paragraphs; the document model does not.
    # Only normalize line endings and NBSP, preserving all actual words and spacing.
    return composer_input_text(text).replace('\u00a0',' ').strip()


def same_composer_text(left,right):
    return normalized_composer_text(left)==normalized_composer_text(right)


def composer_mismatch_detail(expected,actual):
    """Only lengths/character categories are logged, never the user's full prompt."""
    expected=normalized_composer_text(expected);actual=normalized_composer_text(actual)
    position=next((i for i,(a,b) in enumerate(zip(expected,actual)) if a!=b),min(len(expected),len(actual)))
    def kind(value):
        if position>=len(value):return '文本结束'
        c=value[position]
        if c=='\n':return '换行'
        if c=='\t':return '制表符'
        if c.isspace():return '空白'
        if c=='\ufffc':return '未识别的内嵌内容'
        if ord(c)<32 or c in '\u200b\u200c\u200d\u2060\ufeff':return '不可见字符'
        return '普通文字'
    return (f"预期 {len(expected)} 字符/{expected.count(chr(10))+1} 行，"
            f"读回 {len(actual)} 字符/{actual.count(chr(10))+1} 行；"
            f"第 {position+1} 字符：预期{kind(expected)}、读回{kind(actual)}")

def composer_diagnostic(expected,actual):
    left=normalized_composer_text(expected);right=normalized_composer_text(actual)
    position=next((i for i,(a,b) in enumerate(zip(left,right)) if a!=b),min(len(left),len(right)))
    def kind(text):
        if position>=len(text):return 'end'
        char=text[position]
        if char=='\n':return 'newline'
        if char=='\t':return 'tab'
        if char.isspace():return 'space'
        if char=='\ufffc':return 'atom'
        if ord(char)<32 or char in '\u200b\u200c\u200d\u2060\ufeff':return 'invisible'
        return 'text'
    return dict(expected_chars=len(left),actual_chars=len(right),expected_lines=left.count('\n')+1,
                actual_lines=right.count('\n')+1,difference_index=position+1,
                expected_kind=kind(left),actual_kind=kind(right))


def require_composer_mode(snapshot,expected_mode):
    if expected_mode is None:return
    if not snapshot or snapshot.get('mode')!=expected_mode:
        if expected_mode=='chat':
            raise RuntimeError('普通号 Fast 15 秒应在普通对话发送；页面已进入视频生成模式，尚未发送。请关闭输入框下方“视频生成”标签后重试，不要点“强开15秒”')
        raise RuntimeError('豆包已退出视频生成模式，尚未发送；请保持所选模型与参数页面')


@contextmanager
def emulate_composer_focus(page):
    nested=getattr(page,'_anne_emulated_focus',None) is True
    if not nested:
        page.call('Emulation.setFocusEmulationEnabled',{'enabled':True})
        page._anne_emulated_focus=True
    try:yield
    finally:
        if not nested:
            page._anne_emulated_focus=False
            try:page.call('Emulation.setFocusEmulationEnabled',{'enabled':False})
            except Exception:pass  # Do not replace a submission/transport error.


def prepare_composer(page,text,check,expected_mode=None):
    if getattr(page,'_anne_fast_button_submit',None) is True:
        with emulate_composer_focus(page):
            return _prepare_composer(page,text,check,expected_mode)
    return _prepare_composer(page,text,check,expected_mode)


def _prepare_composer(page,text,check,expected_mode=None):
    check()
    raw=str(text or '')
    diagnostic_event(page,'composer_input',chars=len(raw),lines=composer_input_text(raw).count('\n')+1,
                     crlf=raw.count('\r\n'),bare_cr=raw.count('\r')-raw.count('\r\n'),
                     bare_lf=raw.count('\n')-raw.count('\r\n'))
    if not composer(page):raise RuntimeError('输入框未就绪，尚未发送')
    initial=composer_snapshot(page,True)
    if not initial:raise RuntimeError('输入框未就绪，尚未发送')
    require_composer_mode(initial,expected_mode)
    if initial['text'].strip() and not same_composer_text(initial['text'],text):
        raise RuntimeError('输入框已有不同内容，请保留或清空后继续；未覆盖手动输入')
    if getattr(page,'_anne_fast_button_submit',None) is True:
        # A real click gives the background editor the same input path as the UI.
        expression='''(()=>{const e=document.querySelector('[data-anne-composer]');
          if(!e)return null;const r=e.getBoundingClientRect(),hit=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);
          return hit&&(hit===e||e.contains(hit))?e:null})()'''
        if not page.click(expression):raise RuntimeError('豆包输入框被遮挡或尚未就绪，尚未发送')
        current=composer_snapshot(page)
        if not current or current['route']!=initial['route'] or not same_composer_text(current['text'],initial['text']):
            raise RuntimeError('聚焦时输入框或页面已变化，尚未发送')
        initial=current
    if not initial['focused']:raise RuntimeError('输入框无法获得焦点，尚未发送')
    assert_preparation_intact(page)
    if not initial['text'].strip():page.call('Input.insertText',{'text':composer_input_text(text)})
    # Slower machines may need more than 1.2s to commit a long editor document.
    # Only wait/read again: never overwrite, clear or append the prompt twice.
    for _ in range(50):
        check();snapshot=composer_snapshot(page)
        if not snapshot or snapshot['route']!=initial['route']:raise RuntimeError('输入时账号页面已切换，尚未发送')
        require_composer_mode(snapshot,expected_mode)
        if same_composer_text(snapshot['text'],text):
            if not snapshot['focused']:snapshot=composer_snapshot(page,True)
            require_composer_mode(snapshot,expected_mode)
            if snapshot and snapshot['route']==initial['route'] and snapshot['focused'] and same_composer_text(snapshot['text'],text):
                diagnostic_event(page,'composer_verified',success=True,chars=len(normalized_composer_text(text)),
                                 lines=normalized_composer_text(text).count('\n')+1)
                return snapshot
        time.sleep(.1)
    detail=composer_mismatch_detail(text,snapshot['text'])
    diagnostic_event(page,'composer_mismatch',**composer_diagnostic(text,snapshot['text']))
    report=getattr(page,'report',lambda text:None)
    report('发送前文本核对未通过：'+detail+'；输入内容已保留，未发送任务')
    raise RuntimeError('输入框实际文本与分镜提示词不一致，尚未发送；'+detail+'。输入已保留，请勿重复追加提示词')


FAST_SEND_CONTROL_JS=r'''(()=>{
 const editor=document.querySelector('[data-anne-composer]'),surface=editor?.closest('.guidance-input-surface');
 if(!editor||!surface)return {state:'missing'};
 const visible=e=>{if(!e)return false;const r=e.getBoundingClientRect();
   for(let n=e;n;n=n.parentElement){const s=getComputedStyle(n);
     if(s.display==='none'||s.visibility==='hidden'||s.opacity==='0'||n.getAttribute('aria-hidden')==='true')return false}
   return r.width>0&&r.height>0};
 // Never guess by position: the rightmost neighbouring button can be a tool.
 const fixed=[...surface.querySelectorAll('[id="flow-end-msg-send"]')].filter(visible);
 const controls=fixed.length?fixed:[...surface.querySelectorAll('button,[role="button"]')].filter(e=>visible(e)&&
   /^(发送|发送消息|Send|Send message)$/i.test((e.getAttribute('aria-label')||e.getAttribute('title')||e.innerText||'').trim()));
 if(controls.length!==1)return {state:controls.length?'ambiguous':'missing'};
 const button=controls[0];
 if(button.disabled||button.getAttribute('aria-disabled')==='true'||button.getAttribute('data-disabled')==='true')
   return {state:'disabled'};
 const r=button.getBoundingClientRect(),x=r.x+r.width/2,y=r.y+r.height/2,hit=document.elementFromPoint(x,y);
 if(!hit||(hit!==button&&!button.contains(hit)))return {state:'blocked'};
 return {state:'ready',button,x,y};
})()'''


def fast_send_snapshot(page):
    return page.evaluate('''(()=>{const e=document.querySelector('[data-anne-composer]'),control=('''+FAST_SEND_CONTROL_JS+''');
      const video=!![...(e?.closest('.guidance-input-surface')?.querySelectorAll('[data-input-engine-actionbar-control-key="video-model"]')||[])]
        .find(n=>{const r=n.getBoundingClientRect();return r.width&&r.height&&getComputedStyle(n).visibility!=='hidden'});
      return {route:location.href,text:e?'''+COMPOSER_TEXT_JS+'''(e):null,focused:document.hasFocus(),mode:video?'video':'chat',
        messages:[...document.querySelectorAll('[data-message-id]')].map(n=>n.getAttribute('data-message-id')),
        streaming:!!document.querySelector('[data-streaming="true"]'),
        control:{state:control.state,x:control.x,y:control.y}}})()''')


def fast_send_advanced(before,current):
    # These are stop-retry signals; task binding still verifies the exact prompt.
    return (current['route']!=before['route'] or current.get('mode')!=before.get('mode') or current['messages']!=before['messages'] or
            current['text'] is None or not same_composer_text(current['text'],before['text']) or
            (current.get('streaming') and not before.get('streaming')))


def fast_background_submit(page,before):
    """Choose one UI handler before any native send click has been dispatched."""
    return page.evaluate('''(async()=>{const expected='''+json.dumps(before,ensure_ascii=False)+''';
      const e=document.querySelector('[data-anne-composer]'),control=('''+FAST_SEND_CONTROL_JS+''');
      const video=!![...(e?.closest('.guidance-input-surface')?.querySelectorAll('[data-input-engine-actionbar-control-key="video-model"]')||[])]
        .find(n=>{const r=n.getBoundingClientRect();return r.width&&r.height&&getComputedStyle(n).visibility!=='hidden'});
      if(!e||location.href!==expected.route||'''+COMPOSER_TEXT_JS+'''(e)!==expected.text||
         (video?'video':'chat')!==expected.mode||
         JSON.stringify([...document.querySelectorAll('[data-message-id]')].map(n=>n.getAttribute('data-message-id')))!==JSON.stringify(expected.messages)||
         document.querySelector('[data-streaming="true"]')||control.state!=='ready')return false;
       const button=control.button;
       // Doubao's composer has two React shapes in the wild.  Some builds put
       // onClick on the rendered button; others put it on a fiber parent while
       // the button only carries aria/DOM props.  Resolve one handler from the
       // current button's fiber chain before falling back to a native event.
       // This mirrors the manager's clickSubmit path, but never searches a
       // different composer or dispatches a second click after an uncertain
       // native press.
       const propKeys=node=>Object.keys(node||{}).filter(k=>k.startsWith('__reactProps'));
       const handlerFromProps=props=>props&&typeof props.onClick==='function'?props:null;
       let props=null;
       for(const key of propKeys(button)){
         props=handlerFromProps(button[key]);
         if(props)break;
       }
       if(!props){
         const fiberKey=Object.keys(button).find(k=>k.startsWith('__reactFiber')||k.startsWith('__reactInternalInstance'));
         let fiber=fiberKey?button[fiberKey]:null;
         const seen=new Set();
         for(let depth=0;fiber&&depth<12&&!props;depth++,fiber=fiber.return){
           if(seen.has(fiber))break;seen.add(fiber);
           props=handlerFromProps(fiber.memoizedProps)||handlerFromProps(fiber.pendingProps);
         }
       }
       if(props?.disabled||props?.['aria-disabled']===true||props?.['aria-disabled']==='true')return false;
      const nativeEvent=new MouseEvent('click',{bubbles:true,cancelable:true,composed:true,view:window});
      if(typeof props?.onClick==='function'){
        const event={type:'click',target:button,currentTarget:button,nativeEvent,button:0,buttons:0,
          preventDefault:()=>nativeEvent.preventDefault(),stopPropagation:()=>nativeEvent.stopPropagation(),
          isDefaultPrevented:()=>nativeEvent.defaultPrevented,isPropagationStopped:()=>nativeEvent.cancelBubble,persist:()=>{}};
        await props.onClick(event);
      }else{button.dispatchEvent(nativeEvent)}
      return true;
    })()''')


def send_fast_composer(page,text,check,before_send,expected_mode):
    """One reserved send, followed only by reads; never retry an uncertain click."""
    with emulate_composer_focus(page):
        prepared=prepare_composer(page,text,check,expected_mode)
        identity=safety_page_identity(page)
        if identity is None:raise RuntimeError('豆包账号页面尚未确认，尚未发送')
        guard=getattr(page,'_anne_submission_guard',None)
        if isinstance(guard,dict):
            for _ in range(3):
                check();assert_preparation_intact(page,require_uploaded=True)
                current=composer_snapshot(page);require_composer_mode(current,expected_mode)
                if not current or current['route']!=prepared['route'] or not same_composer_text(current['text'],text):
                    raise RuntimeError('图文等待确认时输入框或对话已变化，未发送；输入已保留')
                time.sleep(.15)
        dismiss_safety_confirmation(page,check,getattr(page,'report',None),timeout=0.0,identity=identity)
        before=fast_send_snapshot(page);deadline=time.monotonic()+5
        while True:
            check();require_safety_page_identity(page,identity)
            current=fast_send_snapshot(page)
            if fast_send_advanced(before,current) or current['route']!=prepared['route'] or not same_composer_text(current['text'],text):
                raise RuntimeError('发送前消息或输入框已变化，尚未发送')
            if current.get('streaming'):raise RuntimeError('豆包仍在回复，已保留当前输入，尚未发送')
            status=current['control']['state']
            if status=='ready':break
            if status=='ambiguous' or time.monotonic()>=deadline:
                raise RuntimeError('豆包发送按钮未就绪或被遮挡，已保留输入，尚未发送')
            time.sleep(.2)
        # Persist before either single send path. Recheck after callbacks too.
        check();assert_preparation_intact(page,require_uploaded=True)
        last=composer_snapshot(page);require_composer_mode(last,expected_mode)
        before_send()
        check();require_safety_page_identity(page,identity)
        assert_preparation_intact(page,require_uploaded=True)
        latest=fast_send_snapshot(page)
        require_composer_mode(latest,expected_mode)
        if fast_send_advanced(before,latest) or latest['control']['state']!='ready':
            raise RuntimeError('发送前页面已变化，已保留原任务，未重复发送')
        if latest['focused']:
            point={k:latest['control'][k] for k in ('x','y')}
            page.call('Input.dispatchMouseEvent',dict(type='mouseMoved',**point))
            # Hover can open a tooltip/menu. Recheck the target before pressing.
            latest=fast_send_snapshot(page)
            require_composer_mode(latest,expected_mode)
            if fast_send_advanced(before,latest) or latest['control']['state']!='ready':
                raise RuntimeError('点击发送前按钮或页面已变化，已保留原任务')
            point={k:latest['control'][k] for k in ('x','y')}
            for kind in ('mousePressed','mouseReleased'):
                page.call('Input.dispatchMouseEvent',dict(type=kind,button='left',clickCount=1,**point))
        elif not fast_background_submit(page,latest):
            raise RuntimeError('豆包后台发送条件已变化，已保留原任务，未重复发送')
        page._anne_submission_guard=None
        diagnostic_event(page,'submission_key',success=True,method='button',count=1)
        deadline=time.monotonic()+8
        while True:
            check();require_safety_page_identity(page,identity,allow_route_change=True)
            current=fast_send_snapshot(page)
            if fast_send_advanced(before,current):return
            dismiss_safety_confirmation(page,check,getattr(page,'report',None),timeout=0.0,
                                        identity=identity,defer_route_change=True)
            if time.monotonic()>=deadline:
                raise RuntimeError('豆包已点击发送，暂未确认消息回显；原任务已保留，请继续核对原对话，未再次点击或上传')
            time.sleep(.2)


def send_composer(page,text,check,before_send=lambda:None,expected_mode=None):
    if getattr(page,'_anne_fast_button_submit',None) is True:
        return send_fast_composer(page,text,check,before_send,expected_mode)
    prepared=prepare_composer(page,text,check,expected_mode)
    safety_identity=safety_page_identity(page)
    # A settled editor document is not proof its attachments still belong to this draft.
    # Re-read both across a short stable window; never issue another insert or send.
    if isinstance(getattr(page,'_anne_submission_guard',None),dict):
        for _ in range(3):
            check();assert_preparation_intact(page,require_uploaded=True)
            current=composer_snapshot(page)
            require_composer_mode(current,expected_mode)
            if not current or current['route']!=prepared['route'] or not same_composer_text(current['text'],text):
                raise RuntimeError('图文等待确认时输入框或对话已变化，未发送；输入已保留')
            time.sleep(.15)
    # A first use of Doubao's video composer can show a web safety-consent
    # dialog after the draft is prepared (and, on some builds, just before the
    # Enter key is delivered).  It is a Doubao-only modal; acknowledge it
    # without touching any Dola page or issuing a second submission.
    # Handle a modal that was already open, without delaying a normal send.
    dismiss_safety_confirmation(page, check, report=getattr(page,'report',None), timeout=0.0,identity=safety_identity)
    check();before_send() # Persist uncertain submissions before the irreversible key.
    last=composer_snapshot(page,True)
    require_composer_mode(last,expected_mode)
    if not last or last['route']!=prepared['route'] or not last['focused'] or not same_composer_text(last['text'],text):
        raise RuntimeError('发送前输入框或页面已变化；任务已保留，未重复发送')
    assert_preparation_intact(page,require_uploaded=True)
    guard=getattr(page,'_anne_submission_guard',None)
    if isinstance(guard,dict):
        diagnostic_event(page,'submission_preflight',success=True,total=len(guard['paths']),
                         chars=len(normalized_composer_text(text)),method='enter')
    page.key('Enter',13)
    # The consent dialog is opened asynchronously by the Enter action.  Poll
    # briefly so the original submission can continue, but never press Enter
    # again if the transport is delayed or ambiguous.
    dismiss_safety_confirmation(page, check, report=getattr(page,'report',None), timeout=4.0,
                                identity=safety_identity,defer_route_change=True)
    diagnostic_event(page,'submission_key',success=True)
    page._anne_submission_guard=None


def click_text(page, pattern, selector='button,[role="button"],[role="option"]'):
    return page.click('''[...document.querySelectorAll('''+json.dumps(selector)+''')].find(e=>e.getBoundingClientRect().width&&new RegExp('''+json.dumps(pattern)+''','i').test((e.innerText||e.getAttribute('aria-label')||'').trim()))''')


def visible_model_options(page):
    """Return loaded Seedance options without treating an empty menu as expiry."""
    try:
        return page.evaluate(r'''[...document.querySelectorAll('[role="menuitem"],[role="option"]')]
          .filter(e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);
            return r.width&&r.height&&s.visibility!=='hidden'&&s.display!=='none'})
          .map(e=>(e.innerText||e.getAttribute('aria-label')||'').trim())
          .filter(t=>/Seedance|Dreamina/i.test(t))''') or []
    except Exception:
        return []


def safety_confirmation_locator_expression(snapshot=False):
    """Locate only Doubao's material-rights notice, never a generic confirm.

    Doubao has used both a role=dialog node and a nested ``*modal*`` wrapper.
    The deepest semantic match is authoritative; two unrelated visible matches
    are ambiguous and therefore never clicked.  The wording below intentionally
    excludes login, captcha, payment/subscription and generation confirmations.
    """
    result=r'''(()=>{
      const visible=e=>{if(!e)return false;const r=e.getBoundingClientRect(),s=getComputedStyle(e);
        if(!(r.width&&r.height)||s.visibility==='hidden'||s.display==='none'||e.getAttribute('aria-hidden')==='true')return false;
        for(let p=e.parentElement;p;p=p.parentElement){const ps=getComputedStyle(p);
          if(ps.visibility==='hidden'||ps.display==='none'||p.getAttribute('aria-hidden')==='true')return false}
        return true};
      const text=e=>(e?.innerText||e?.textContent||'').replace(/\s+/g,'');
      const roots=[...document.querySelectorAll(
        '[role="dialog"],[aria-modal="true"],[data-testid*="dialog" i],'+
        '[class*="modal" i],[class*="dialog" i]')].filter(visible).filter(e=>{
          if(e.closest('[data-message-id]'))return false; // never act on history/message markup
          // Official builds also render the title in a div/span or h4-h6.
          // Keep an exact, visible title inside the same semantic modal.
          const t=text(e),head=[...e.querySelectorAll('h1,h2,h3,h4,h5,h6,[role="heading"],div,span,p')]
            .filter(el=>visible(el)&&!el.closest('[data-message-id]')).map(text);
          return head.includes('安全确认')&&t.includes('你在本功能中上传、使用的素材')&&
            t.includes('均已获充分授权');
        });
      const deepest=roots.filter(e=>!roots.some(other=>other!==e&&e.contains(other)));
      if(deepest.length!==1)return {state:deepest.length?'ambiguous':'absent',count:deepest.length};
      const root=deepest[0],buttons=[...root.querySelectorAll('button,[role="button"]')].filter(visible);
      const confirms=buttons.filter(e=>text(e)==='确认');
      if(confirms.length!==1)return {state:'ambiguous',count:confirms.length};
      const button=confirms[0],disabled=!!button.disabled||button.getAttribute('aria-disabled')==='true';
      return {state:disabled?'disabled':'ready',button,signature:'doubao-material-safety-v1'};
    })()'''
    if snapshot:
        return r'''(()=>{const x=('''+result+r''');return {state:x.state,count:x.count||0,
          enabled:x.state==='ready',signature:x.signature||''}})()'''
    return r'''(()=>{const x=('''+result+r''');return x.state==='ready'?x.button:null})()'''


def safety_confirmation_button_expression():
    """Backward-compatible exact button locator used by offline DOM checks."""
    return safety_confirmation_locator_expression(False)


def safety_confirmation_snapshot(page):
    value=page.evaluate(safety_confirmation_locator_expression(True))
    # Lightweight compatibility pages may return a non-object for a missing
    # modal. Treat that as absent; a real CDP Page returns the structured
    # state above, while malformed/ambiguous visible dialogs still stop below.
    if not isinstance(value,dict) or value.get('state') not in {'absent','ambiguous','disabled','ready'}:
        return dict(state='absent',count=0,enabled=False,signature='')
    return value


def safety_confirmation_present(page):
    return safety_confirmation_snapshot(page).get('state') in {'ready','disabled'}


def safety_page_identity(page):
    try:
        route=getattr(page,'url',None)
    except AttributeError:
        # Lightweight offline stubs do not model navigation.  Production
        # Page objects always expose .url and therefore still get binding.
        return None
    if not isinstance(route,str) or not route:
        return None
    account=getattr(page,'_anne_account_id',None)
    if not route.startswith(('https://www.doubao.com/','https://doubao.com/')):
        raise RuntimeError('豆包页面地址已变化，未确认素材安全提示')
    cid=conversation_id(route)
    route_key=('conversation',cid) if cid else ('chat-root',)
    return account,getattr(page,'_anne_target_id',None),route_key,route


def require_safety_page_identity(page,identity,allow_route_change=False):
    if identity is None:return
    current=safety_page_identity(page)
    if current[0]!=identity[0] or current[1]!=identity[1] or (
            not allow_route_change and current[2]!=identity[2]):
        raise RuntimeError('豆包页面或账号已变化，未继续确认素材安全提示')


def dismiss_safety_confirmation(page,check=None,report=None,timeout=0.0,identity=None,
                                defer_route_change=False):
    """Click the exact notice once, then verify closure before releasing it.

    A transport error or an unclosed modal retains the reservation. Only an
    observed disappearance permits a later new notice in the same chat.
    After Enter, a new route is left to exact-message task binding; this
    helper never clicks a modal on an unverified replacement route.
    """
    if not callable(getattr(page,'click',None)):
        return False
    if identity is None:identity=safety_page_identity(page)
    # A lightweight test/compatibility page may not expose a route. Production
    # Page objects do, so route/account binding still applies to real clicks.
    if identity is None:return False
    timeout=max(0.0,float(timeout or 0));deadline=time.monotonic()+timeout
    observed=False;disabled_deadline=None
    while True:
        if check:check()
        current=safety_page_identity(page)
        if (defer_route_change and current is not None and current[0]==identity[0]
                and current[1]==identity[1] and current[2]!=identity[2]):
            return False
        require_safety_page_identity(page,identity,allow_route_change=defer_route_change)
        value=safety_confirmation_snapshot(page);state=value['state']
        if state=='ready':
            observed=True
            token=(identity,value.get('signature') or 'doubao-material-safety-v1')
            attempted=getattr(page,'_anne_safety_confirmation_attempts',set())
            if token in attempted:
                raise RuntimeError('豆包素材安全提示已尝试确认但尚未确认关闭，未重复点击；请检查原窗口')
            def reserve():
                if check:check()
                require_safety_page_identity(page,identity,allow_route_change=defer_route_change)
                fresh=safety_confirmation_snapshot(page)
                if fresh.get('state')!='ready' or fresh.get('signature')!=value.get('signature'):
                    raise RuntimeError('豆包素材安全弹窗已变化或被取消，未继续确认')
                current=set(getattr(page,'_anne_safety_confirmation_attempts',set()))
                if token in current:raise RuntimeError('豆包素材安全提示已尝试确认，未重复点击')
                current.add(token);page._anne_safety_confirmation_attempts=current
            expression=safety_confirmation_button_expression()
            try:
                clicked=page.click(expression,before_click=reserve)
            except TypeError as error:
                # A small offline wrapper may expose only click(expression).
                # Reserve first, then perform exactly one click; never retry a
                # real transport error from the production Page class.
                if 'before_click' not in str(error):
                    raise
                reserve()
                clicked=page.click(expression)
            if not clicked:
                raise RuntimeError('豆包素材安全弹窗已变化，未确认点击结果；请检查原窗口，未重复提交')
            close_deadline=time.monotonic()+3
            while True:
                if check:check()
                current=safety_page_identity(page)
                if current is None or current[0]!=identity[0] or current[1]!=identity[1]:
                    raise RuntimeError('豆包账号已变化，未继续确认素材安全提示')
                if current[2]!=identity[2]:
                    if not defer_route_change:
                        require_safety_page_identity(page,identity)
                    # The new route must pass ensure_task_route before any
                    # subsequent click. Do not report the modal as closed.
                    if report:report('已点击豆包素材安全提示，页面已跳转，继续核对原任务')
                    return True
                fresh=safety_confirmation_snapshot(page)
                if fresh['state']=='absent':
                    pending=set(getattr(page,'_anne_safety_confirmation_attempts',set()))
                    pending.discard(token);page._anne_safety_confirmation_attempts=pending
                    if report:report('已自动确认豆包素材安全提示，弹窗已关闭')
                    return True
                if fresh['state']=='ambiguous':
                    raise RuntimeError('点击后豆包素材安全弹窗出现歧义，未重复点击；请检查原窗口')
                if time.monotonic()>=close_deadline:
                    raise RuntimeError('已点击豆包素材安全提示，但弹窗 3 秒后仍未关闭；已保留原任务，未重复点击')
                time.sleep(.1)
        elif state=='ambiguous':
            raise RuntimeError('豆包素材安全弹窗不唯一或按钮不唯一，已停止当前操作')
        elif state=='disabled':
            observed=True
            if disabled_deadline is None:disabled_deadline=time.monotonic()+3
            if time.monotonic()>=disabled_deadline:
                raise RuntimeError('豆包素材安全弹窗的“确认”按钮持续不可用，已保留原任务')
            time.sleep(.1)
            continue
        elif observed:
            raise RuntimeError('豆包素材安全提示已取消或消失，未继续点击或提交')
        if time.monotonic()>=deadline:return False
        time.sleep(.1)


def dismiss_task_safety_confirmation(page,state,check,report=None):
    """Poll late notices only in the already-owned account and task route."""
    if not state.get('submitted') or state.get('output') or state.get('conversation_continued'):
        return False
    identity=safety_page_identity(page)
    if identity is None or not state.get('account') or identity[0]!=state.get('account'):
        raise RuntimeError('豆包账号与原任务不一致，未确认素材安全提示')
    expected=state.get('url') if state.get('route_bound') else state.get('submission_route') or state.get('url')
    expected_id=conversation_id(expected)
    if state.get('route_bound'):
        if not expected_id or conversation_id(identity[3])!=expected_id:
            raise RuntimeError('豆包对话与原任务不一致，未确认素材安全提示')
    elif identity[3]!=expected:
        # A newly assigned chat id is trusted only after the submitted prompt
        # binds it. Never use the material-rights notice itself as identity.
        return False
    return dismiss_safety_confirmation(page,check,report,timeout=0.0,identity=identity,
                                       defer_route_change=True)


def composer(page):
    return page.evaluate('''(()=>{document.querySelectorAll('[data-anne-composer]').forEach(e=>e.removeAttribute('data-anne-composer'));const e=[...document.querySelectorAll('.guidance-input-surface textarea,.guidance-input-surface .tiptap[contenteditable="true"],.guidance-input-surface [contenteditable="true"][role="textbox"]')].find(e=>e.getBoundingClientRect().width&&getComputedStyle(e).visibility!=='hidden'&&!e.disabled);
      if(!e)return false;e.setAttribute('data-anne-composer','1');return true})()''')


VIDEO_MODE_ACTIVE_JS=r'''(()=>[...document.querySelectorAll('.guidance-input-surface [data-input-engine-actionbar-control-key="video-model"]')].some(e=>{const r=e.getBoundingClientRect();return r.width&&r.height&&getComputedStyle(e).visibility!=='hidden'}))()'''

# Doubao also exposes video generation in the composer's Skills picker. Both
# expressions stay inside the current composer, never a history row or sidebar.
SKILL_ENTRY_JS=r'''(()=>{
 const visible=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'};
 const surfaces=[...document.querySelectorAll('.guidance-input-surface')].filter(visible);
 if(surfaces.length!==1)return null;
 const surface=surfaces[0],label=e=>(e.innerText||e.getAttribute('aria-label')||'').replace(/\s+/g,'').trim();
 const controls=[...surface.querySelectorAll('button,[role="button"]')].filter(e=>visible(e)&&/^(技能|更多技能|技能中心|Skills?)$/i.test(label(e)));
 if(controls.length)return controls.length===1?controls[0]:null;
 const leaves=[...surface.querySelectorAll('span,div')].filter(e=>visible(e)&&/^(技能|更多技能|技能中心|Skills?)$/i.test(label(e))&&
   ![...e.children].some(child=>/^(技能|更多技能|技能中心|Skills?)$/i.test(label(child))));
 return leaves.length===1?leaves[0]:null;
})()'''

# Some Doubao accounts put the same picker under "更多" / "更多技能" in the
# composer. Keep its scope identical to Skills: never match the sidebar's "更多".
MORE_ENTRY_JS=SKILL_ENTRY_JS.replace('(技能|更多技能|技能中心|Skills?)','(更多|更多技能|技能中心|More)')

SKILL_VIDEO_OPTION_JS=r'''(()=>{
 const visible=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'};
 const surfaces=[...document.querySelectorAll('.guidance-input-surface')].filter(visible);
 if(surfaces.length!==1)return null;
 const box=surfaces[0].getBoundingClientRect();
 const leaves=[...document.querySelectorAll('span,div,p,button,[role="option"],[role="menuitem"]')].filter(e=>{
   if(!visible(e)||e.closest('nav,aside,[data-message-id]'))return false;
   if((e.innerText||'').replace(/\s+/g,'').trim()!=='视频生成')return false;
   if([...e.children].some(child=>(child.innerText||'').replace(/\s+/g,'').trim()==='视频生成'))return false;
   const r=e.getBoundingClientRect();
   return r.left>=box.left-16&&r.right<=box.right+16&&r.top>=box.top-720&&r.bottom<=box.bottom+16;
 });
 // Both "推荐" and "快捷功能" may contain the same skill; either is valid.
 return leaves[0]||null;
})()'''


def ensure_plain_chat(page,check):
    if not page.evaluate(VIDEO_MODE_ACTIVE_JS):return
    close=r'''[...document.querySelectorAll('.guidance-input-surface [class*="exit-skill-close-btn-icon"]')].find(e=>{const r=e.getBoundingClientRect();return r.width&&r.height&&getComputedStyle(e).visibility!=='hidden'})'''
    if not page.click(close):
        raise RuntimeError('普通号 Fast 15 秒采用普通对话；无法退出“视频生成”标签，尚未发送，请关闭该标签后重试')
    for _ in range(50):
        check()
        if not page.evaluate(VIDEO_MODE_ACTIVE_JS):return
        time.sleep(.1)
    raise RuntimeError('普通对话模式尚未就绪，尚未发送；请关闭“视频生成”标签后重试，不要点“强开15秒”')



def prepare_new_task_conversation(page,params,check):
    """Finish navigation/model hydration before any task text or files exist."""
    initial=route_recovery_draft(page)
    initial_route=initial.get('route') if isinstance(initial,dict) else None
    report=getattr(page,'report',lambda text:None)
    owner=(getattr(page,'_anne_account_id',None),getattr(page,'_anne_target_id',None))
    def verify_owner():
        check()
        if owner!=(getattr(page,'_anne_account_id',None),getattr(page,'_anne_target_id',None)):
            raise RuntimeError('账号页面已变化，未填写或上传')
    for attempt in range(2):
        verify_owner()
        new_route=(open_new_conversation(page,verify_owner,force_navigation=True)
                   if attempt else open_new_conversation(page,verify_owner))
        if direct_mode(params):
            report('普通号 Fast 15 秒：使用普通对话并附加参数，不操作视频时长面板')
            ensure_plain_chat(page,verify_owner)
        else:
            report('选择 '+params['model']+' / '+str(params['duration'])+' 秒 / '+params['aspect_ratio'])
            setup_video_controls(page,params,verify_owner)
        # A transient empty DOM is insufficient. Check again after controls
        # settle; a hydrated old route is recovered only before preparation.
        deadline=time.monotonic()+3;stable_since=None
        while True:
            verify_owner();value=None
            try:value=route_recovery_draft(page)
            except RuntimeError as error:
                if not _route_recovery_loading_error(error):raise
            now=time.monotonic()
            if isinstance(value,dict):
                if value.get('empty') is False or value.get('attachments') not in (None,0) or value.get('uploading') is True:
                    raise RuntimeError('当前输入框出现草稿或附件，已保留，未重新新建对话或上传')
                if value.get('route') not in {initial_route,new_route}:
                    raise RuntimeError('准备期间切到其他对话，未继续填写或上传')
                if _empty_conversation_snapshot(value) and value['route']==new_route:
                    if stable_since is None:stable_since=now
                    if now-stable_since>=1:
                        require_empty_new_conversation(page,new_route)
                        return new_route
                else:stable_since=None
            if now>=deadline:
                if not isinstance(value,dict) or value.get('ready') is not True:
                    raise RuntimeError('新对话页面尚未就绪，已阻止填写和上传')
                break
            time.sleep(.25)
        if attempt:
            raise RuntimeError('重新新建后仍未确认空白对话，已阻止填写和上传')
        report('旧聊天重新出现，正在重新建立空白对话；尚未填写或上传')



def setup(page,params,paths,check,prompt=None):
    report=getattr(page,'report',lambda text:None)
    report('检查登录状态')
    cached_plan=params.get('_account_plan')
    live_status=account_state(page)
    if live_status.get('login_state')=='logged_out' or live_status.get('plan')=='logged_out':
        raise AccountLoggedOut('豆包账号已掉线，尚未填写或上传')
    observed_plan=cached_plan if cached_plan in {'free','standard','trial'} else live_status.get('plan','unknown')
    if params.get('_free_account_phase') and observed_plan in {'standard','trial'}:
        raise AccountPlanChanged('账号识别为会员套餐，先调度其他普通号；尚未发送',observed_plan)
    if observed_plan!='unknown' or not params.get('_account_plan'):params['_account_plan']=observed_plan
    check()
    report('打开新对话')
    new_route=prepare_new_task_conversation(page,params,check)
    # Profile labels can finish loading while the new conversation opens.
    # Reclassify here, before any prompt bytes or attachment upload.
    if params.get('_free_account_phase'):
        phase_plan=account_state(page).get('plan')
        if phase_plan in {'standard','trial'}:
            raise AccountPlanChanged('账号识别为会员套餐，在上传参考图前继续选择普通号',phase_plan)
    require_empty_new_conversation(page,new_route)
    submitted_prompt=None
    if prompt is not None:
        submitted_prompt=video_prompt(prompt,params)
        page._anne_joint_audit_complete=False
        page._anne_last_submission_observation=None
        page._anne_submission_guard=dict(route=page.url,user_ids={m['id'] for m in user_messages(page)},
                                         paths=list(paths),uploaded=False,signature=None)
        report('先填写并核对提示词，再上传参考图；图文准备完成后只发送一次')
        prepare_composer(page,submitted_prompt,check,expected_mode='chat' if direct_mode(params) else 'video')
    report(f'开始上传 {len(paths)} 张参考图')
    upload_references(page,paths,check,params)
    if prompt is not None:
        guard=page._anne_submission_guard
        assert_preparation_intact(page)
        guard['signature']=ready_attachment_signature(upload_state(page),paths)
        guard['uploaded']=True
        assert_preparation_intact(page,require_uploaded=True)
    report('参考图就绪，检查输入框')
    if not composer(page):raise RuntimeError('豆包输入框未就绪，尚未发送任务')
    return submitted_prompt


NEW_CHAT_ENTRY_JS=r'''(()=>{
 const visible=e=>{const r=e.getBoundingClientRect();return r.width&&r.height&&getComputedStyle(e).visibility!=='hidden'};
 const excluded=e=>e.closest('[data-message-id],.guidance-input-surface,[role="dialog"],[role="menu"]');
 // Prefer the official creation control, never a history row titled "新对话".
 const official=[...document.querySelectorAll('[data-testid="create_conversation_button"]')]
   .filter(e=>visible(e)&&!excluded(e)&&!e.disabled);
 if(official.length)return official.length===1?official[0]:null;
 const candidates=[...document.querySelectorAll('button,[role="button"],a')].filter(e=>{
   if(!visible(e)||excluded(e)||e.disabled)return false;
   const link=e.closest('a[href]');
   if(link){try{const u=new URL(link.href,location.href);
     if(u.origin!==location.origin||!/^\/chat\/?$/.test(u.pathname))return false;
   }catch{return false}}
   if(e.closest('[data-conversation-id],[data-testid*="conversation-item"],[data-testid*="conversation_item"]'))return false;
   return /^新对话(?:CtrlShiftK)?$/i.test((e.innerText||e.getAttribute('aria-label')||'').replace(/[\s+]+/g,''));
 });
 return candidates.length===1?candidates[0]:null;
})()'''


def _empty_conversation_snapshot(value):
    return (isinstance(value,dict) and value.get('ready') is True and value.get('empty') is True
            and value.get('attachments')==0 and value.get('uploading') is False
            and value.get('message_count')==0 and _recovery_source_route(value.get('route')))


def require_empty_new_conversation(page,expected_route):
    value=route_recovery_draft(page)
    if not _empty_conversation_snapshot(value) or value['route']!=expected_route:
        raise RuntimeError('新对话尚未确认或已出现旧消息/草稿，已阻止填写和上传；不会在旧对话追加提交')
    return value


def open_new_conversation(page,check,timeout=25,force_navigation=False):
    """A successful click is not proof: require a stable empty new conversation."""
    check();before=route_recovery_draft(page)
    if (not isinstance(before,dict) or not before.get('ready') or not _recovery_source_route(before.get('route'))):
        raise RuntimeError('豆包对话页面尚未就绪，未填写或上传，请页面加载完成后重试')
    if before.get('empty') is not True or before.get('attachments')!=0 or before.get('uploading') is not False:
        raise RuntimeError('当前输入框已有未发送文字或附件，已保留草稿，未新建对话或上传')
    previous=before['route'];previous_id=conversation_id(previous)
    clicked=False if force_navigation else page.click(NEW_CHAT_ENTRY_JS)
    started=time.monotonic();deadline=started+timeout
    stable_route=None;stable_since=None;fallback=False
    while True:
        check()
        try:value=route_recovery_draft(page)
        except RuntimeError as error:
            if not _route_recovery_loading_error(error):raise
            value=None
        now=time.monotonic()
        if isinstance(value,dict):
            if value.get('empty') is False or value.get('attachments') not in (None,0) or value.get('uploading') is True:
                raise RuntimeError('新建对话期间出现未发送内容或附件，已保留，未继续填写或上传')
            fresh=(_empty_conversation_snapshot(value) and
                   (not previous_id or conversation_id(value['route'])!=previous_id))
            if fresh and (not force_navigation or fallback):
                if stable_route!=value['route']:stable_route=value['route'];stable_since=now
                if now-stable_since>=.5:
                    require_empty_new_conversation(page,stable_route)
                    diagnostic_event(page,'new_chat_ready',success=True,message_count=0)
                    getattr(page,'report',lambda text:None)('已确认空白新对话，开始准备本次图文')
                    return stable_route
            else:stable_route=None;stable_since=None
            if (not fallback and (not clicked or now-started>=3) and value.get('route')==previous
                    and value.get('ready') is True and value.get('empty') is True
                    and value.get('attachments')==0 and value.get('uploading') is False):
                # Sidebar event can be dropped. One fallback to the observed
                # official blank-chat entry, only while the old draft is empty.
                check();latest=route_recovery_draft(page)
                if (not isinstance(latest,dict) or latest.get('route')!=previous or latest.get('empty') is not True
                        or latest.get('attachments')!=0 or latest.get('uploading') is not False):
                    raise RuntimeError('新建对话前页面发生变化，未导航或上传，请检查当前草稿')
                route=urllib.parse.urlsplit(previous)
                fallback=True
                result=page.call('Page.navigate',{'url':urllib.parse.urlunsplit((route.scheme,route.netloc,'/chat/','',''))})
                if not isinstance(result,dict) or result.get('errorText') or result.get('isDownload'):
                    raise RuntimeError('新对话无法打开，未填写或上传；不会在旧对话提交')
        if now>=deadline:
            raise RuntimeError('未能确认空白新对话，已阻止填写和上传；不会继续在旧对话提交')
        time.sleep(.25)


def open_video_model(page,params,check):
    """Use the direct video entry, Skills, or More in the composer, once.

    Doubao can render the composer and its text entry a few seconds after a new
    conversation is ready. A missing selector during that hydration window is
    transient: keep polling it, but never prepare/upload/send anything here.
    """
    check()
    identity=safety_page_identity(page)
    deadline=time.monotonic()+max(1,min(60,int(params.get('video_entry_timeout') or 25)))
    selector='[...document.querySelectorAll(\'.guidance-input-surface [data-input-engine-actionbar-control-key="video-model"]\')].find(e=>{const r=e.getBoundingClientRect();return r.width&&r.height&&getComputedStyle(e).visibility!=="hidden"})'
    entry_requested=False
    menu_open_requested=''
    next_entry_attempt=0.0
    # Clear a safety notice before touching the entry. The same check is
    # repeated below because the notice can appear while the composer hydrates.
    dismiss_safety_confirmation(page,check,getattr(page,'report',None),timeout=0.0,identity=identity)
    while True:
        check()
        now=time.monotonic()
        dismissed=dismiss_safety_confirmation(page,check,getattr(page,'report',None),timeout=.25,identity=identity)
        if dismissed and safety_confirmation_snapshot(page).get('state')!='absent':
            raise RuntimeError('豆包素材安全弹窗尚未关闭，未继续操作视频模型')
        active=bool(page.evaluate(VIDEO_MODE_ACTIVE_JS))
        # Retry only failed text-entry attempts. Once clicked, do not click it
        # again while the selector hydrates.
        if not active and not entry_requested:
            if menu_open_requested:
                entry_requested=bool(page.click(SKILL_VIDEO_OPTION_JS))
            elif now>=next_entry_attempt:
                entry_requested=bool(click_text(page,r'^(视频生成|生成视频|Create videos)$'))
                if not entry_requested:
                    if page.click(SKILL_ENTRY_JS):
                        menu_open_requested='技能'
                    elif page.click(MORE_ENTRY_JS):
                        menu_open_requested='更多'
                    if menu_open_requested:
                        getattr(page,'report',lambda text:None)('已打开豆包“'+menu_open_requested+'”菜单，等待视频生成入口')
                next_entry_attempt=now+.75
        if active or entry_requested:
            if page.click(selector):
                # Some builds raise the safety notice while entering video
                # mode. Acknowledge it before model/ratio/duration actions.
                dismiss_safety_confirmation(page,check,report=getattr(page,'report',None),timeout=1.5,identity=identity)
                return
        if now>=deadline:
            if entry_requested or active:
                raise RuntimeError('豆包模型选择器未就绪，尚未发送任务')
            if menu_open_requested:
                raise RuntimeError('豆包'+menu_open_requested+'菜单未显示视频生成入口，尚未发送任务')
            raise RuntimeError('豆包未显示视频生成入口，尚未发送任务')
        time.sleep(.25)


VIDEO_QUALITY_SELECTOR=('[data-creation-params-panel-id] button,[data-creation-params-panel-id] [role="button"],'
                        '[data-creation-params-panel-id] [role="radio"],[data-creation-params-panel-id] label')
# The composer's argument button: "自动 · 10s", "16:9 · 30s", and — since the
# resolution row exists — "自动 · 10s · 720P" / "16:9 · 30s · 1080P".
PARAMS_SUMMARY_PATTERN=r'^(自动|\d+:\d+)\s*·\s*\d+s(?:\s*·\s*\d{3,4}\s*[Pp])?$'
PANEL_OPTION_SELECTOR='[data-creation-params-panel-id] button'


def video_panel_open(page,params):
    """True when the expanded argument panel is showing this ratio option.

    The collapsed composer bar carries the same data attribute as the expanded
    panel, so the ratio option itself (exact label, visible) is the only honest
    signal that the panel is open.
    """
    try:
        return bool(page.evaluate('''(()=>{const visible=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);
 return !!(r.width&&r.height)&&s.visibility!=='hidden'&&s.display!=='none'};
 const want='''+json.dumps(params['aspect_ratio'])+''';
 return [...document.querySelectorAll('''+json.dumps(PANEL_OPTION_SELECTOR)+''')]
  .filter(visible).some(e=>((e.innerText||e.textContent||'').replace(/\\s+/g,' ').trim()===want))})()'''))
    except Exception:
        return False


VIDEO_QUALITY_JS=r'''(()=>{
 const visible=e=>{if(!e)return false;const r=e.getBoundingClientRect(),s=getComputedStyle(e);
  return r.width&&r.height&&s.visibility!=='hidden'&&s.display!=='none'};
 const pattern=/^(?:720|1080)\s*[Pp]$/;
 const panels=[...document.querySelectorAll('[data-creation-params-panel-id]')].filter(visible);
 const listed=p=>[...p.querySelectorAll('button,[role="button"],[role="radio"],label')]
  .filter(visible).map(e=>(e.innerText||e.textContent||'').replace(/\s+/g,' ').trim())
  .filter(text=>pattern.test(text)).filter((text,index,all)=>all.indexOf(text)===index).length;
 // Doubao marks the collapsed composer bar with the same attribute as the
 // expanded panel (two visible nodes on a real 2.5 page), so the expanded panel
 // is the one that owns the duration slider this plugin already drives.  Without
 // a unique slider panel, the panel listing the most resolution options wins.
 let anchors=panels.filter(p=>p.querySelector('[role="slider"]'));
 if(anchors.length!==1){
  const counts=panels.map(listed),best=Math.max(0,...counts);
  const leaders=panels.filter((p,index)=>counts[index]===best&&best>0);
  if(leaders.length===1)anchors=leaders;
 }
 if(anchors.length!==1)return {found:false,panels:panels.length,options:[]};
 const options=[],seen=new Set();
 for(const element of anchors[0].querySelectorAll('button,[role="button"],[role="radio"],label')){
  if(!visible(element))continue;
  const text=(element.innerText||element.textContent||'').replace(/\s+/g,' ').trim();
  if(!pattern.test(text)||seen.has(text))continue;
  seen.add(text);options.push(text);
 }
 return {found:options.length>0,panels:panels.length,options};
})()'''


def video_quality_option_expression(target):
    """Locate one resolution option inside the creation panel, scrolling it in.

    Page.click() dispatches a real mouse event at the element's viewport centre,
    so a row that sits below the fold has to be brought into view first.
    """
    return ('[].find.call(document.querySelectorAll('+json.dumps(VIDEO_QUALITY_SELECTOR)+'),'
            'n=>((n.innerText||n.textContent||"").replace(/\\s+/g," ").trim()==='+json.dumps(target)+'))')


def select_video_quality(page,params,check,wait_seconds=3):
    """Pick the account's 1080P resolution when this 2.5 page offers one.

    The resolution row has only ever appeared with Seedance 2.5, so 2.0 keeps its
    existing behaviour untouched and never runs this step.  For 2.5, an account
    without the option (or without the row at all) is a normal page state: the
    page default is kept.  A row that exists but cannot be clicked must stop the
    task instead of silently sending a lower resolution, so the caller only
    continues after the read-back check.
    """
    if params.get('model')!='Seedance 2.5':return None
    deadline=time.monotonic()+wait_seconds
    while True:
        check()
        info=page.evaluate(VIDEO_QUALITY_JS)
        if isinstance(info,dict) and info.get('found') is True:
            options=[str(value) for value in info.get('options') or []]
            target=next((value for value in options if re.fullmatch(r'1080\s*[Pp]',value)),None)
            if target is None:return None
            expression=video_quality_option_expression(target)
            located=page.evaluate('(()=>{const e='+expression+';'
                                 'if(!e||e.disabled||e.getAttribute("aria-disabled")==="true")return false;'
                                 'e.scrollIntoView({block:"center",inline:"center"});return true})()')
            if located is not True:raise RuntimeError('豆包分辨率控件未就绪，尚未发送任务')
            if not page.click(expression):raise RuntimeError('豆包分辨率控件未就绪，尚未发送任务')
            return target
        if time.monotonic()>=deadline:return None
        time.sleep(.25)


def setup_video_controls(page,params,check):
    report=getattr(page,'report',lambda text:None)
    open_video_model(page,params,check)
    identity=safety_page_identity(page)
    dismiss_safety_confirmation(page,check,report,timeout=.5,identity=identity)
    time.sleep(.4)
    patterns={'Seedance 2.0':r'^Seedance\s*2[.．]0(?!\s*Fast)(?:\s|$|[（(])',
              'Seedance 2.0 Fast':r'^Seedance\s*2[.．]0\s*Fast(?:\s|$|[（(])',
              'Seedance 2.5':r'^(?:Dreamina\s*)?Seedance\s*2[.．]5(?:\s|$|[（(])'}
    model_pattern=patterns[params['model']]
    model_deadline=time.monotonic()+8
    reopen_at=time.monotonic()+1.5
    selected_model=False
    while time.monotonic()<model_deadline:
        check()
        dismiss_safety_confirmation(page,check,report,timeout=.25,identity=identity)
        if click_text(page,model_pattern,'[role="menuitem"],[role="option"]'):
            selected_model=True
            break
        # The video menu can finish hydrating after the entry button returns.
        # Reopen it at most a few times instead of classifying a transient empty
        # menu as an expired membership.
        if time.monotonic()>=reopen_at:
            try:open_video_model(page,params,check)
            except Exception:pass
            reopen_at=time.monotonic()+1.5
        time.sleep(.25)
    if not selected_model:
        loaded=visible_model_options(page)
        if params.get('_account_plan') in {'standard','trial'} and loaded:
            raise AccountPlanUnavailable('已确认模型菜单加载完成，但页面没有 '+params['model']+'；正在切换账号')
        raise RuntimeError('豆包模型菜单未加载完成，已重试 8 秒；未判断为套餐失效，也未发送任务')
    # Selecting a model may itself trigger the same rights notice on older
    # Doubao builds; clear it before touching ratio/duration controls.
    dismiss_safety_confirmation(page,check,report,timeout=.75,identity=identity)
    report('模型已选中，设置画幅与时长')
    time.sleep(.4)
    # Doubao's argument button reads "自动 · 10s" on 2.0 builds and
    # "自动 · 10s · 720P" once a resolution row exists (Seedance 2.5), so the
    # resolution tail is optional here; anything else still fails the match.
    if not video_panel_open(page,params):
        # The argument button toggles the panel, so it is only pressed when the
        # panel is actually closed; otherwise a click would close it again.
        if not click_text(page,PARAMS_SUMMARY_PATTERN):
            raise RuntimeError('豆包画幅与时长控件未就绪，尚未发送任务')
        time.sleep(.4)
    if not click_text(page,'^'+re.escape(params['aspect_ratio'])+'$',PANEL_OPTION_SELECTOR):
        # Re-open once in case another writer toggled the panel between the
        # state check and this click; never guess a different ratio.
        click_text(page,PARAMS_SUMMARY_PATTERN)
        time.sleep(.5)
        if not click_text(page,'^'+re.escape(params['aspect_ratio'])+'$',PANEL_OPTION_SELECTOR):
            # A page without this ratio cannot run the task: hand the account back
            # to the scheduler (it will be marked and another account tried).
            raise AccountPlanUnavailable('该账号页面不支持所选画幅 '+params['aspect_ratio']+'（可能已无会员）；正在切换账号')
    slider='document.querySelector(\'[data-creation-params-panel-id] [role="slider"]\')'
    if not page.click(slider):raise RuntimeError('豆包时长滑块未就绪，尚未发送任务')
    bounds=page.evaluate('''(()=>{const e='''+slider+''';return {min:Number(e.getAttribute('aria-valuemin')),max:Number(e.getAttribute('aria-valuemax')),text:e.closest('[data-creation-params-panel-id]').innerText}})()''')
    seconds=[int(x) for x in re.findall(r'(\d+)\s*(?:s|秒)',bounds['text'])]
    minimum=min(seconds) if seconds else 4
    target=int(params['duration'])-minimum+int(bounds['min'])
    if not int(bounds['min'])<=target<=int(bounds['max']):
        page.key('Escape',27)
        raise RuntimeError('标准会员页面尚未提供 '+str(params['duration'])+' 秒时长；未追加文字、未降级或发送任务')
    page.key('Home',36)
    for _ in range(target-int(bounds['min'])):check();page.key('ArrowRight',39)
    time.sleep(.3)
    actual=page.evaluate(slider+'?.getAttribute("aria-valuenow")')
    if actual is None or int(actual)!=target:
        raise RuntimeError('豆包时长未正确应用，尚未发送任务')
    # Newer builds add a resolution row (720P / 1080P) for Seedance 2.5 only.
    # Membership decides whether 1080P is offered, so an absent option keeps the
    # page default and 2.0 never enters this step at all.
    quality=select_video_quality(page,params,check)
    if quality:report('已选择 '+quality+' 分辨率')
    page.key('Escape',27)
    time.sleep(.3)
    selected=page.evaluate("[...document.querySelectorAll('button')].filter(e=>e.getBoundingClientRect().width).map(e=>e.innerText.trim())")
    if not any(re.search(re.escape(params['aspect_ratio'])+r'\s*·\s*'+str(params['duration'])+'s',text) for text in selected):
        raise RuntimeError('豆包参数回读不一致，尚未发送任务')
    if quality and not any(re.search(r'1080',text,re.I) for text in selected):
        raise RuntimeError('豆包分辨率未正确应用，尚未发送任务')


UPLOAD_STATE_JS=r'''(()=>{
 const surface=[...document.querySelectorAll('.guidance-input-surface')].find(e=>e.getBoundingClientRect().width&&getComputedStyle(e).visibility!=='hidden');
 if(!surface)return {found:false,items:[]};
 const cards=[...surface.querySelectorAll('[data-kind="image"],[class*="thumb-card-"]')];
 const items=[],seen=new Set(),objects=new WeakSet();let found=false,unresolvedCount=0;
 function committedChain(fiber){
  // A DOM node's cached fiber is not necessarily the committed branch. Rebuild
  // its ancestor path via root.current and child links; shared (bailed-out)
  // children can still have return pointers into the previous render.
  const path=[],visited=new Set();
  for(let node=fiber;node;node=node.return){
   if(visited.has(node)||path.length>=256)return null;
   visited.add(node);path.push(node);
  }
  if(!path.length)return null;
  const root=path[path.length-1],current=root.stateNode?.current;
  if(!current){
   // A single non-buffered chain has no competing state; an ambiguous pair
   // must wait rather than choosing whichever branch reports more progress.
   return root.tag===3||path.some(node=>node.alternate)?null:path;
  }
  if(current!==root&&current!==root.alternate)return null;
  const committed=[current];let parent=current,budget=8192;
  for(let i=path.length-2;i>=0;i--){
   const wanted=path[i];let match=null;
   for(let child=parent.child;child;child=child.sibling){
    if(--budget<=0)return null;
    if(child===wanted||child===wanted.alternate){match=child;break;}
   }
   if(!match)return null;
   committed.push(match);parent=match;
  }
  return committed.reverse();
 }
 function add(x){
  if(!x||x.type!=='image'||objects.has(x))return;
  const key=x.localKey||x.fileKey;
  if(key&&seen.has(key))return;
  objects.add(x);if(key)seen.add(key);
  items.push({name:x.fileName,md5:x.md5||'',identity:String(x.localKey||x.fileKey||''),percent:Number(x.uploadPercent||0),status:String(x.status||''),hasKey:!!x.fileKey});
 }
 for(const card of cards.slice(0,32)){
  const chain=committedChain(card[Object.keys(card).find(k=>k.startsWith('__reactFiber'))]);
  if(!chain){unresolvedCount++;continue;}
  for(const fiber of chain.slice(0,16)){
   if(fiber.stateNode instanceof Element && fiber.stateNode!==card && !surface.contains(fiber.stateNode))break;
   const props=fiber.memoizedProps||{};
   if(props.attachmentState?.type==='image'){found=true;add(props.attachmentState);break;}
   if(Array.isArray(props.attachmentStates)){found=true;props.attachmentStates.forEach(add);break;}
   if(fiber.stateNode===surface)break;
  }
 }
 return {found,items,cardCount:cards.length,unresolvedCount};
})()'''


def upload_state(page):
    return page.evaluate(UPLOAD_STATE_JS) or {'found':False,'items':[]}

def ready_attachment_signature(state,paths):
    from collections import Counter
    if not isinstance(state,dict):raise RuntimeError('无法确认发送前附件状态，未发送')
    items=state.get('items',[])
    expected=Counter(Path(path).name for path in paths)
    names=Counter(item.get('name','') for item in items)
    ready=(not state.get('unresolvedCount') and names==expected and len(items)==len(paths)
           and all(item.get('percent',0)>=100 and item.get('status')=='Normal' and item.get('hasKey') for item in items))
    if paths and not state.get('found'):ready=False
    if not paths and state.get('cardCount',0):ready=False
    if not ready:raise RuntimeError('发送前参考图数量或上传状态已变化，已阻止单独发送文字；请检查原输入框')
    # Opaque attachment identities remain only in memory; never write them to logs.
    return tuple(sorted((str(item.get('name','')),str(item.get('identity','')),str(item.get('md5',''))) for item in items))


def assert_preparation_intact(page,require_uploaded=False):
    guard=getattr(page,'_anne_submission_guard',None)
    if not isinstance(guard,dict):return
    current_ids={message['id'] for message in user_messages(page)}
    added=current_ids-guard['user_ids']
    if added:
        diagnostic_event(page,'submission_integrity',success=False,error='unexpected_submission',
                         message_count=len(added),total=len(guard['paths']))
        raise SubmissionIntegrityError('准备图文期间页面已提前出现新消息，已停止；不会把提示词单独补发。请检查原对话，未自动重试')
    if page.url!=guard['route']:
        diagnostic_event(page,'submission_integrity',success=False,error='preparation_changed',route_changed=True)
        raise RuntimeError('图文准备期间对话地址已变化，未继续发送；请检查原页面')
    if require_uploaded or guard.get('uploaded'):
        if not guard.get('uploaded'):
            raise RuntimeError('图文尚未共同就绪，未发送')
        signature=ready_attachment_signature(upload_state(page),guard['paths'])
        if signature!=guard['signature']:
            diagnostic_event(page,'submission_integrity',success=False,error='attachment_changed',total=len(guard['paths']))
            raise RuntimeError('参考图在发送前被替换或改变，已停止；不会单独发送文字')


SUBMISSION_SNAPSHOT_JS=r'''(()=>{
 const id=x=>typeof x==='string'?x:typeof x==='number'&&Number.isSafeInteger(x)?String(x):'';
 const identity=x=>{const v=id(x);return v&&v!=='0'?v:''};
 const rows=[],seenIds=new Set();
 for(const e of document.querySelectorAll('[data-message-id]')){
  const messageId=id(e.getAttribute('data-message-id'));
  if(!messageId||seenIds.has(messageId))continue;
  const user=e.classList.contains('justify-end'),assistant=!user&&e.classList.contains('grid');
  if(!user&&!assistant)continue;
  seenIds.add(messageId);
  if(!user){rows.push({id:messageId,role:'assistant'});continue}
  let best=null,bestScore=-1,budget=2400;const seen=new WeakSet();
  function walk(o,depth){
   if(!o||typeof o!=='object'||o instanceof Node||depth>10||--budget<0||seen.has(o))return;
   seen.add(o);
   const blocks=o.content_block||o.contentBlocks||o.content_blocks_v2;
   if(Array.isArray(blocks)&&id(o.message_id||o.messageId||o.id)===messageId){
    const conversation=identity(o.conversation_id||o.conversationId),section=identity(o.section_id||o.sectionId),created=identity(o.create_time||o.createTime);
    const score=Number(!!conversation)+Number(!!section)+Number(!!created);
    if(score>bestScore){
     const texts=blocks.map(b=>b?.content?.text_block?.text).filter(x=>typeof x==='string');
     const attachments=blocks.flatMap(b=>Array.isArray(b?.content?.attachment_block?.attachments)?b.content.attachment_block.attachments:[]);
     best={id:messageId,role:'user',text:texts.join('\n'),images:attachments.length,
           payload:true,conversation,section,created};bestScore=score;
    }
   }
   for(const key of Object.keys(o))
    if(!['_owner','return','sibling','alternate','stateNode','style'].includes(key))walk(o[key],depth+1);
  }
  for(const n of [e,...e.querySelectorAll('[data-render-engine]')])
   for(const key of Object.keys(n))if(key.startsWith('__reactProps'))walk(n[key],0);
  // Display nodes, avatars and lazy thumbnails are not authoritative message attachments.
  rows.push(best||{id:messageId,role:'user',payload:false});
 }
 return {route:location.href,messages:rows};
})()'''


def submission_snapshot(page):
    result=page.evaluate(SUBMISSION_SNAPSHOT_JS)
    if not isinstance(result,dict) or not isinstance(result.get('messages'),list):
        return {'route':'','messages':[]}
    return result


def submission_evidence(snapshot,state):
    """Classify one atomic snapshot, using server payload and contiguous turn ownership."""
    rows=snapshot.get('messages',[])
    baseline=set(state.get('user_message_ids',[]))
    users=[row for row in rows if row.get('role')=='user' and row.get('id') not in baseline]
    authoritative=[row for row in users if row.get('payload') is True]
    matching=[row for row in authoritative if submission_matches(row.get('text',''),state)]
    if state.get('submitted_message_id'):
        matching=[row for row in matching if row.get('id')==state['submitted_message_id']]
    expected=state.get('expected_reference_count',0)
    observed=dict(message_count=len(users),matching_messages=len(matching),
                  image_only_messages=sum(bool(row.get('images',0)) and not row.get('text','').strip() for row in authoritative),
                  total=expected,attachment_count=0)
    result=dict(status='pending',observed=observed,route=snapshot.get('route',''),text_id=None,created=None)
    if len(matching)!=1:return result
    text=matching[0];result.update(text_id=text['id'],created=text.get('created'))
    observed['attachment_count']=text.get('images',0)
    if text.get('images',0)==expected:
        result['status']='joint'
        return result
    if not expected:return result
    def group(row):
        values=tuple(row.get(key) for key in ('conversation','section','created'))
        return values if all(isinstance(value,str) and value and value!='0' for value in values) else None
    key=group(text)
    if key:
        related=[row for row in authoritative if group(row)==key]
        related_ids={row['id'] for row in related}
        positions=[i for i,row in enumerate(rows) if row.get('id') in related_ids]
        contiguous=(positions and all(row.get('role')=='user' and row.get('id') in related_ids
                                      for row in rows[min(positions):max(positions)+1]))
        # Other text in the group is user content, not an attachment-only companion.
        companions_only=all(row['id']==text['id'] or not row.get('text','').strip() for row in related)
        count=sum(row.get('images',0) for row in related)
        if contiguous and companions_only and count==expected:
            observed['attachment_count']=count
            result['status']='joint'
            return result
    # Separate DOM IDs alone are normal in Doubao. Only an intervening assistant
    # reply proves that an earlier image submission already received its own answer.
    text_position=next((i for i,row in enumerate(rows) if row.get('id')==text['id']),None)
    for image in authoritative:
        if image['id']==text['id'] or not image.get('images',0):continue
        image_position=next((i for i,row in enumerate(rows) if row.get('id')==image['id']),None)
        if image_position is None or text_position is None or image_position>=text_position:continue
        if text.get('images',0)==0 and any(row.get('role')=='assistant' for row in rows[image_position+1:text_position]):
            result['status']='split'
            return result
    return result


def audit_submission(page,state,save):
    """Observe metadata only; a detected split never triggers repair/resubmission."""
    if 'expected_reference_count' not in state or getattr(page,'_anne_joint_audit_complete',False) is True:return
    evidence=submission_evidence(submission_snapshot(page),state)
    observed=evidence['observed'];signature=(evidence['status'],*observed.values())
    if getattr(page,'_anne_last_submission_observation',None)!=signature:
        diagnostic_event(page,'submission_observed',**observed)
        page._anne_last_submission_observation=signature
    if evidence['status']=='split':
        state['submission_integrity_error']='split_submission'
        state['submission_integrity_error_version']=2
        save()
        diagnostic_event(page,'submission_integrity',success=False,error='split_submission',**observed)
        raise SubmissionIntegrityError('网页把参考图和提示词分成了不同消息，已停止并保留原对话；不会自动补发或重试，避免重复生成')
    if evidence['status']=='joint':
        page._anne_joint_audit_complete=True
    return evidence


def legacy_split_recheckable(state):
    return (state.get('submission_integrity_error')=='split_submission'
            and not state.get('submission_integrity_error_version')
            and state.get('submitted') is True and bool(state.get('account'))
            and isinstance(state.get('expected_reference_count'),int) and state['expected_reference_count']>0
            and bool(re.fullmatch(r'[a-f0-9]{64}',str(state.get('prompt_fingerprint','')))))


def recheck_legacy_split(page,state,save,error_time,check):
    """Read-only page revalidation of old v1 false positives; never sends or navigates."""
    if not legacy_split_recheckable(state):raise SubmissionIntegrityError('此任务需先核对原对话，禁止自动重提')
    deadline=time.monotonic()+5
    while True:
        check()
        evidence=audit_submission(page,state,save)
        if evidence and evidence['status']=='joint':
            current_id=conversation_id(evidence['route'])
            original_id=conversation_id(state.get('url'))
            try:near_record=abs(float(evidence.get('created'))-float(error_time))<=120
            except (TypeError,ValueError):near_record=False
            # Bound tasks require the exact old conversation. An old unbound
            # record additionally requires its server timestamp to match the failure.
            if current_id and ((original_id and current_id==original_id) or (not original_id and near_record)):
                updated=dict(state,url=evidence['route'],route_bound=True,submitted_message_id=evidence['text_id'],
                             submission_integrity_rechecked=True)
                updated.pop('submission_integrity_error',None)
                updated.pop('submission_integrity_error_version',None)
                previous=dict(state)
                state.clear();state.update(updated)
                try:save()
                except Exception:
                    state.clear();state.update(previous);raise
                diagnostic_event(page,'submission_integrity',success=True,**evidence['observed'])
                return
            break
        if time.monotonic()>=deadline:break
        time.sleep(.25)
    raise SubmissionIntegrityError('尚不能确认这是原任务的同组图文，旧记录未改动；请保持原对话后继续，不会自动重发')


def wait_upload_ready(page,paths,check,params):
    from collections import Counter
    expected=Counter(Path(path).name for path in paths)
    report=getattr(page,'report',lambda text:None)
    timeout=max(1,int(params.get('upload_timeout',180)));started=time.monotonic();last_report=-10
    safety_identity=safety_page_identity(page)
    state={'found':False,'items':[]};ready_count=0;detail=''
    def describe(items,ready):
        parts=[]
        names=Counter(x.get('name','') for x in items)
        missing=list((expected-names).elements());extra=list((names-expected).elements())
        label=lambda value:re.sub(r'[\r\n\t]+',' ',str(value))[:100]
        if missing:parts.append('缺少附件：'+', '.join(label(name) for name in missing))
        if extra:parts.append('多出附件：'+', '.join(label(name) for name in extra))
        for item in items:
            if item in ready:continue
            parts.append(f"{label(item.get('name') or '未命名图片')}：{item.get('percent',0)}%，"
                         f"状态 {label(item.get('status') or '未知')}，服务端标识{'有' if item.get('hasKey') else '无'}")
        if state.get('unresolvedCount'):parts.append(f"{state['unresolvedCount']} 个附件的当前状态尚未确认")
        return '；'.join(parts)
    while time.monotonic()-started<timeout:
        assert_preparation_intact(page)
        check();state=upload_state(page);items=state.get('items',[])
        # Upload progress can be covered by the rights notice.  Handle only
        # that exact modal and re-read upload state afterwards; never reselect
        # files when the notice is slow or ambiguous.
        dismiss_safety_confirmation(page,check,getattr(page,'report',None),timeout=.25,identity=safety_identity)
        require_safety_page_identity(page,safety_identity)
        state=upload_state(page);items=state.get('items',[])
        errors=[x for x in items if re.search('error|fail|reject',x.get('status',''),re.I)]
        if errors:raise RuntimeError('参考图上传失败：'+', '.join(x.get('name','图片') for x in errors)+'；尚未发送任务')
        ready=[x for x in items if x.get('percent',0)>=100 and x.get('status')=='Normal' and x.get('hasKey')]
        ready_names=Counter(x.get('name','') for x in ready)
        ready_count=sum((ready_names&expected).values())
        if state.get('found') and not state.get('unresolvedCount') and len(items)==len(paths) and ready_names==expected:
            diagnostic_event(page,'upload_progress',ready=len(ready),total=len(paths),success=True)
            report(f'参考图上传完成：{len(ready)}/{len(paths)}');return
        detail=describe(items,ready)
        elapsed=int(time.monotonic()-started)
        if elapsed-last_report>=10:
            diagnostic_event(page,'upload_progress',ready=ready_count,total=len(paths),elapsed=elapsed)
            if not state.get('found'):report(f'正在识别参考图上传状态，已等待 {elapsed} 秒')
            else:report(f'等待参考图上传：{ready_count}/{len(paths)}，已等待 {elapsed} 秒'+('；'+detail if detail else ''))
            last_report=elapsed
        time.sleep(1)
    if not state.get('found'):
        raise RuntimeError(f'未能识别当前页面的参考图上传状态（等待 {timeout} 秒）；{detail}；尚未发送任务，请更新插件后重试')
    raise RuntimeError(f'参考图上传超时（{timeout} 秒，完成 {ready_count}/{len(paths)}）；{detail}；尚未发送任务')


UPLOAD_BUTTON_EXPR='document.querySelector(\'[data-testid="upload_file_button"]\')'
ADD_IMAGE_EXPR=r'''(()=>{const visible=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);
 return !!(r.width&&r.height)&&s.visibility!=='hidden'&&s.display!=='none'};
 const item=[...document.querySelectorAll('*')].filter(visible)
  .filter(e=>(e.innerText||'').trim()==='添加图片').pop();
 return item||null})()'''


def find_upload_input(page):
    """Return (node id, intercepted) for the composer's attachment input.

    Older builds kept a static ``input[type=file]``.  Current builds create it
    only after the attach button is pressed — and in a re-tried conversation that
    can take a few seconds — so the button is pressed again and polled in rounds.
    The OS file chooser is intercepted (after Page.enable, which CDP requires)
    so nothing ever opens on screen.
    """
    root=page.call('DOM.getDocument',{'depth':0,'pierce':False})['root']['nodeId']

    def scoped():
        return page.call('DOM.querySelector',{'nodeId':root,'selector':'.guidance-input-surface input[type="file"]'}).get('nodeId')

    def any_input():
        nodes=page.call('DOM.querySelectorAll',{'nodeId':root,'selector':'input[type="file"]'}).get('nodeIds') or []
        best=None
        for node in nodes:
            attributes=page.call('DOM.describeNode',{'nodeId':node}).get('node',{}).get('attributes') or []
            accept=''
            for index in range(0,len(attributes),2):
                if attributes[index]=='accept':accept=str(attributes[index+1] or '')
            if not accept or 'image' in accept.lower() or accept.startswith('.'):
                return node
            best=best or node
        return best

    def wait_for_input(rounds):
        for _ in range(rounds):
            time.sleep(.4)
            node=scoped() or any_input()
            if node:return node
        return None

    node=scoped() or any_input()
    if node:return node,False
    # Page.enable is required before interception takes effect; without it the
    # real OS file dialog would open on the user's screen.
    try:page.call('Page.enable',{})
    except Exception:pass
    page.call('Page.setInterceptFileChooserDialog',{'enabled':True})
    intercepted=True
    for _attempt in range(2):
        # A re-tried conversation sometimes needs a second press, and the input
        # can appear a couple of seconds after the first one.
        clicked=page.click(UPLOAD_BUTTON_EXPR)
        node=wait_for_input(6)
        if node:return node,intercepted
        if clicked and page.click(ADD_IMAGE_EXPR):
            # Some builds open a small menu first ("添加图片").
            node=wait_for_input(6)
            if node:return node,intercepted
    return None,intercepted


def upload_references(page,paths,check,params):
    if paths:
        report=getattr(page,'report',lambda text:None)
        check()
        file_node,intercepted=find_upload_input(page)
        if not file_node:raise RuntimeError('豆包参考图上传入口未就绪，尚未发送任务')
        page.call('DOM.setFileInputFiles',{'nodeId':file_node,'files':[str(path) for path in paths]})
        if intercepted:
            # The files are attached; release the interception so a later manual
            # click on the same page can open a real dialog again.
            try:page.call('Page.setInterceptFileChooserDialog',{'enabled':False})
            except Exception:pass
        wait_upload_ready(page,paths,check,params)


def result_models(page,message_ids=None):
    allowed=json.dumps(message_ids) if message_ids is not None else 'null'
    return page.evaluate(r'''(()=>{
      const allowed='''+allowed+r''';
      // Completed cards can show only a cover until the user presses play.
      // Read their own props without playing, clicking or scanning another reply.
      const nodes=[...document.querySelectorAll('video,[class*="block-video-"]')].filter(e=>{
        const message=e.closest('[data-message-id]');
        return message&&!message.classList.contains('justify-end')&&
          (allowed===null||allowed.includes(message.getAttribute('data-message-id')));
      });
      const node=nodes.at(-1);if(!node)return [];
      const message=node.closest('[data-message-id]'),messageId=message.getAttribute('data-message-id');
      const card=node.closest('[class*="image-box-grid-item-"]')||node.closest('[class*="block-video-"]');
      if(!card||card.closest('[data-message-id]')!==message)return [];
      const conversation=location.pathname.match(/^\/chat\/(\d+)\/?$/)?.[1]||'';
      const found=[],seen=new WeakSet();let budget=5000,truncated=false;
      function walk(o,depth=0){
        if(!o)return;
        if(--budget<=0){truncated=true;return}
        if(depth>12)return;
        if(typeof o==='string'&&o.length<400000&&/video_id|video_list|fallback_api/.test(o)){try{walk(JSON.parse(o),depth+1)}catch{}return}
        if(typeof o!=='object'||o instanceof Node||seen.has(o))return;seen.add(o);
        for(const key of ['message_id','messageId','msg_id','msgId'])
          if(o[key]!=null&&String(o[key])!==messageId)return;
        for(const key of ['conversation_id','conversationId'])
          if(o[key]!=null&&String(o[key])!==conversation)return;
        if(o.video_id&&(o.video_list||o.fallback_api)){found.push(o);return}
        for(const k of Object.keys(o)){if(!['_owner','_store','return','sibling','stateNode','alternate'].includes(k))walk(o[k],depth+1)}
      }
      for(let e=node;e&&e!==message;e=e.parentElement){
        for(const k of Object.keys(e)){if(k.startsWith('__reactProps'))walk(e[k])}
        if(e===card)break;
      }
      const models=[...new Map(found.map(m=>[m.video_id,m])).values()];
      // Never guess between unrelated/ambiguous models carried by one card.
      return !truncated&&models.length===1?models:[];
    })()''') or []


def master_candidates(page,core,baseline,message_ids=None):
    models=[m for m in result_models(page,message_ids) if m.get('video_id') and m['video_id'] not in baseline]
    if not models:return []
    page.evaluate((Path(__file__).parent/'doubao_original.js').read_text(encoding='utf8'))
    candidates=[]
    for model in models:
        lookup=page.evaluate('window.__anneDoubaoOriginal.poll('+json.dumps(model['video_id'])+')') or {}
        signature=(lookup.get('status'),lookup.get('reason'),lookup.get('attempt'))
        if signature!=getattr(page,'_anne_original_lookup_status',None):
            diagnostic_event(page,'original_lookup',lookup_status=lookup.get('status'),
                             lookup_reason=lookup.get('reason'),count=lookup.get('attempt',0),
                             elapsed=lookup.get('elapsed',0))
            page._anne_original_lookup_status=signature
        result=lookup.get('result') if lookup.get('status')=='ready' else None
        if result and result.get('video_id')==model['video_id'] and result.get('source')=='doubao.official_download' and official_original_url(result.get('url')):
            candidates.append(result)
    return sorted(candidates,key=core['_declared_quality_rank'],reverse=True)


def official_original_url(value):
    try:
        parsed=urllib.parse.urlsplit(str(value or ''))
        return (parsed.scheme=='https' and not parsed.username and not parsed.password and
                bool(re.fullmatch(r'(?:[a-z0-9-]+-)?videoweb(?:-download)?\.doubao\.com',parsed.hostname or '')) and
                urllib.parse.parse_qs(parsed.query).get('download')==['true'])
    except ValueError:return False

def _file_sha256(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
    return digest.hexdigest()


def download(candidate,path,core):
    if candidate.get('source')!='doubao.official_download' or not official_original_url(candidate.get('url')):
        raise RuntimeError('拒绝非官方原片地址，不使用低码率预览片')
    check=core.get('_check_stopped',lambda:None)
    check()
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);temp=path.with_suffix('.mp4.downloading');meta_path=temp.with_suffix('.meta.json')
    identity=hashlib.sha256(json.dumps({'video_id':candidate.get('video_id'),'url':candidate.get('url'),'size':candidate.get('declared_size')},sort_keys=True).encode()).hexdigest()
    if meta_path.exists():
        try:
            if json.loads(meta_path.read_text(encoding='utf8')).get('identity')!=identity:
                temp.unlink(missing_ok=True);meta_path.unlink(missing_ok=True)
        except Exception:
            temp.unlink(missing_ok=True);meta_path.unlink(missing_ok=True)
    if temp.exists() and not meta_path.exists(): temp.unlink()
    meta_path.write_text(json.dumps({'identity':identity},ensure_ascii=True),encoding='utf8')
    declared=int(candidate.get('declared_size') or 0)
    expected_total=declared
    keep_temp=True
    try:
        last_error=None
        for attempt in range(4):
            check()
            offset=temp.stat().st_size if temp.exists() else 0
            if expected_total and offset>expected_total:
                temp.unlink();offset=0
            headers={'Accept-Encoding':'identity'}
            if offset:headers['Range']=f'bytes={offset}-'
            request=urllib.request.Request(candidate['url'],headers=headers)
            try:
                with urllib.request.urlopen(request,timeout=120) as response:
                    if not official_original_url(response.geturl()):
                        keep_temp=False;raise RuntimeError('原片下载跳转地址校验失败')
                    code=getattr(response,'getcode',lambda:200)() or 200
                    content_range=str(response.headers.get('Content-Range') or '')
                    match=re.fullmatch(r'bytes\s+(\d+)-(\d+)/(\d+)',content_range)
                    if offset and code==206 and (not match or int(match.group(1))!=offset):
                        raise RuntimeError('原片续传范围不匹配，未回传')
                    range_total=int(match.group(3)) if match else 0
                    response_length=int(response.headers.get('Content-Length') or 0)
                    if not offset and declared and response_length and response_length!=declared:
                        keep_temp=False;raise RuntimeError('豆包原片声明大小与响应不一致')
                    if offset and code==200:
                        # CDN ignored Range; restart safely from byte zero.
                        temp.unlink();offset=0
                    elif offset and code not in (206,):
                        raise RuntimeError('原片续传响应不支持，未回传')
                    if not expected_total:
                        expected_total=range_total or (offset+response_length if code==206 else response_length)
                    mode='ab' if offset else 'wb'
                    with temp.open(mode) as stream:
                        if not offset:
                            header=response.read(32)
                            if b'ftyp' not in header:
                                keep_temp=False;raise RuntimeError('原片地址没有返回 MP4')
                            stream.write(header)
                        while block:=response.read(1024*1024):
                            check();stream.write(block)
                    size=temp.stat().st_size
                    if expected_total and size<expected_total:
                        last_error=RuntimeError('豆包原片本次连接提前结束')
                        if attempt<3:time.sleep(.5);continue
                        raise RuntimeError('豆包原片未完整下载，请继续原任务')
                    if expected_total and size>expected_total:
                        keep_temp=False;temp.unlink();raise RuntimeError('豆包原片大小异常，未回传')
                    break
            except RuntimeError:
                raise
            except Exception as error:
                last_error=error
                if attempt>=3:raise RuntimeError('豆包原片未完整下载，请继续原任务') from None
                time.sleep(.5)
        else:
            raise RuntimeError('豆包原片未完整下载，请继续原任务')
        size=temp.stat().st_size
        if size<131072 or (declared and size!=declared):
            raise RuntimeError('豆包原片未完整下载，请继续原任务')
        keep_temp=False
        metrics=core['_video_metrics'](str(temp))
        if not metrics.get('duration') or not metrics.get('width'):raise RuntimeError('原片视频校验失败')
        for field in ('width','height'):
            if candidate.get(field) and float(metrics.get(field) or 0)<float(candidate[field]):
                raise RuntimeError('下载视频低于官方原片声明的画质，已阻止回传')
        if candidate.get('bitrate') and float(metrics.get('bitrate') or 0)<float(candidate['bitrate'])*.90:
            raise RuntimeError('下载视频低于官方原片声明的码率，已阻止回传')
        check()
        temp.replace(path);keep_temp=False;return str(path)
    finally:
        # Keep an incomplete .downloading file so the next retry can resume
        # with Range; invalid media is removed by the caller's normal retry.
        if temp.exists() and not keep_temp:temp.unlink()
        if meta_path.exists() and not keep_temp:meta_path.unlink()


def generate(context,params,core):
    params=dict(params)
    check=core['_check_stopped'];progress=lambda text,n:core['_progress'](context.get('progress_callback'),text,n)
    base=core.get('_manager_api_base',lambda:core['_MANAGER_API_ROOT'])()
    def manager_json(path,data=None):
        # Production transport pins the selected workbench identity before
        # every request, including opening a page after a workbench restart.
        request=core.get('_manager_api_request')
        if request:return request(path,method='POST' if data is not None else 'GET',data=data,timeout=20)
        return local_json(base+path,data)
    progress('连接 Anne 工作台，读取豆包账号',2)
    key=core['_generation_call_key'](context,params)
    folder=Path(core['_PLUGIN_DIR'])/'data'/'doubao-tasks';folder.mkdir(parents=True,exist_ok=True)
    state_path=folder/(key+'.json')
    state=json.loads(state_path.read_text(encoding='utf8')) if state_path.exists() else {}
    # Fast no-receipt rotation is a same-day guard.  A new Beijing day clears
    # only the accounts added by that guard; other task history is retained.
    if state.get('fast_no_receipt_avoid_day') and state.get('fast_no_receipt_avoid_day')!=today():
        daily=set(str(value) for value in state.get('fast_no_receipt_avoid_accounts',[]) if value)
        if daily:
            state['avoid_accounts']=[value for value in state.get('avoid_accounts',[]) if str(value) not in daily]
        state.pop('fast_no_receipt_avoid_day',None)
        state.pop('fast_no_receipt_avoid_accounts',None)
        state_path.write_text(json.dumps(state,ensure_ascii=False),encoding='utf8')
    # A failed/paused submission is retried as a fresh conversation. Only a
    # task with an observed video remains bound to the old conversation for
    # original-file retrieval.
    if (state.get('submitted') and not state.get('output') and not state.get('media_observed')
            and state.get('failure') and not state.get('submission_integrity_error')
            and not state.get('preparation_blocked')):
        state=dict(fast_retry_history(state),retry_after_failure=True,previous_failure=str(state.get('failure'))[:120])
        state_path.write_text(json.dumps(state,ensure_ascii=False),encoding='utf8')
    validate_params(params,already_submitted=bool(state.get('submitted')))
    if state.get('submitted'):
        for field in ('model','duration','aspect_ratio'):
            if state.get(field) is not None and str(state[field])!=str(params.get(field)):
                raise RuntimeError('原任务的模型、时长或画幅已变化，未继续发送；请恢复原参数后继续取回')
    if state.get('retry_pending') or state.get('new_chat_exhausted'):
        raise RuntimeError('此任务留有旧版新对话重提记录，已保留并停止自动重提；请先检查原任务，不会重传图文')
    if state.get('preparation_blocked'):
        raise RuntimeError('本次图文草稿已保留：上传后账号套餐发生变化，已停止自动换号；不会重新上传或重发，请先检查原账号草稿')
    recheck_split=legacy_split_recheckable(state)
    split_error_time=state_path.stat().st_mtime if recheck_split else None
    if state.get('submission_integrity_error') and not recheck_split:
        raise SubmissionIntegrityError('此任务曾出现图文拆分或意外提前发送，原记录已保留；请先检查原对话，不会自动重新提交')
    if state.get('output') and Path(state['output']).is_file():
        result=Path(state['output'])
        if state.get('sha256')==_file_sha256(result):
            progress('豆包原片已下载完成，正在回传字字，不重复生成',99)
            return [str(result)]
    avoid_accounts={str(value) for value in state.get('avoid_accounts',[]) if value}
    preferred=state.get('account')
    if preferred in avoid_accounts:
        if state.get('submitted'):raise RuntimeError('原任务账号与切号记录不一致，已停止自动提交；请检查原任务')
        preferred=None
    rows=select_account(manager_json('/desktop/platforms')['accounts'],params,preferred)
    if avoid_accounts:rows=[row for row in rows if row['id'] not in avoid_accounts]
    if not rows:raise RuntimeError('没有可用的豆包账号，已跳过本任务中连续未生成或被拒绝的账号')
    if not state.get('submitted'):
        progress('从豆包 '+str(max(1,int(params.get('doubao_account_start') or 1)))+' 号开始向后调度'+
                 ('；强制模式：按起始号顺序推进，不再因当天额度或未标记套餐跳过（页面现场判定）' if forced_start(params) else '')+
                 ('；Fast 15 秒先用普通号，普通号全部不可用后才用标准/体验套餐' if prefer_free_accounts(params) and not state.get('account') else ''),2)
    chosen=None; lock=None; page=None; excluded={};prepared=False
    deadline=time.monotonic()+int(params.get('account_wait_timeout',7200));last_wait=0;scheduling_day=today()
    while not chosen and time.monotonic()<deadline:
        check()
        if today()!=scheduling_day:
            excluded.clear();scheduling_day=today()  # Never delete task ledgers at midnight.
        pool,ordinary_phase=account_pool(rows,params,folder,excluded,pinned=bool(state.get('account')))
        reclassified=False
        for row in pool:
            if row['id'] in excluded:continue
            with _lock:lock=_locks.setdefault(row['id'],threading.Lock())
            if not lock.acquire(blocking=False):continue
            try:
                if not state.get('account'):
                    # Another worker may have advanced this round since the
                    # candidate list was read. Recheck after acquiring ownership.
                    current_pool,current_phase=account_pool(rows,params,folder,excluded)
                    if row['id'] not in {r['id'] for r in current_pool}:
                        lock.release();reclassified=True;break
                    ordinary_phase=current_phase
                progress('正在打开豆包账号 '+str(abs(int(row.get('index',-1)))),3)
                account=manager_json('/desktop/platforms/'+row['id']+'/open',{})
                if not account.get('success'):raise RuntimeError(account.get('error','豆包账号打开失败'))
                page=Page(account)
                page.diagnostic=lambda event,**fields:core.get('_diagnostic_record',lambda *a,**k:None)(event,**fields)
                page.report=lambda text:progress('豆包：'+text,8)
                page.check=check
                progress('已连接豆包页面，检查套餐与额度',5)
                if not state.get('submitted'):
                    for _ in range(15):
                        check()
                        if composer(page):break
                        time.sleep(1)
                    known_plan=remembered_plan(row,folder)
                    if known_plan in {'standard','trial'}:
                        # Cache selects the member pool, not whether it is still logged in.
                        live_status=account_state(page)
                        if live_status.get('login_state')=='logged_out' or live_status.get('plan')=='logged_out':
                            status=dict(live_status,plan='logged_out')
                        elif (params.get('model') in {'Seedance 2.0','Seedance 2.5'}
                              and live_status.get('plan') not in {'standard','trial'}):
                            # 2.0 / 2.5 need the membership shown on the page itself.
                            # A stale card or cached label never authorises use, so
                            # re-read until the label settles before deciding.
                            status=settled_account_state(page,check)
                        else:
                            status=dict(live_status,plan=known_plan)
                    else:
                        status=settled_account_state(page,check)
                    if status.get('exhausted') or status.get('remaining')==0:
                        mark_quota_exhausted(folder,row['id'])
                    plan=status.get('plan','unknown')
                    if (plan=='unknown' and params.get('model') not in {'Seedance 2.0','Seedance 2.5'}
                            and remembered_plan(row,folder) in {'free','standard','trial'}):
                        # 2.0 / 2.5 never inherit a remembered member label: without a
                        # membership read from the page they are treated as ordinary.
                        plan=remembered_plan(row,folder);status=dict(status,plan=plan)
                    remember_plan(row,folder,plan)
                    if ordinary_phase and plan in {'standard','trial'}:
                        close_checked_account(page,row,folder,core)
                        close_page(page);page=None;lock.release();reclassified=True;break
                    params['_account_plan']=plan
                    reason=eligibility(status,params,daily_usage(folder,row['id']))
                    if reason:
                        if params.get('model') in {'Seedance 2.0','Seedance 2.5'} and plan in {'free','unknown'}:
                            remember_member_unavailable(folder,row['id'])
                        progress('跳过豆包账号 '+str(abs(int(row.get('index',-1))))+'：'+reason,5)
                        excluded[row['id']]=reason
                        close_checked_account(page,row,folder,core)
                        close_page(page);page=None;lock.release();continue
                params['_free_account_phase']=ordinary_phase
                chosen=row;state['return_target_id']=account.get('target_id','');break
            except Exception:
                close_page(page);page=None
                lock.release();raise
        if reclassified:continue  # Rebuild pools before any prompt or upload.
        if not chosen and ordinary_phase:
            ordinary=[r for r in rows if remembered_plan(r,folder) not in {'standard','trial'}]
            with _lock:running=any(_locks.get(r['id']) is not None and _locks[r['id']].locked() for r in ordinary)
            if not running and any(account_usage(folder,r['id'])['pending'] for r in ordinary):
                raise RuntimeError('普通号仍有未回传的处理中任务，不计成功，也不直接消耗会员额度；请继续原分镜取回视频，未重新提交')
        if not chosen and len(excluded)==len(rows):
            raise RuntimeError('没有符合本次模型与额度要求的账号：'+'；'.join(sorted(set(excluded.values()))))
        if not chosen:
            if time.monotonic()-last_wait>10:
                progress('普通号正在处理其他分镜，等待普通号空闲；暂不使用标准/体验套餐额度' if ordinary_phase else
                         '豆包账号正在被其他分镜使用，等待空闲账号',3)
                last_wait=time.monotonic()
            time.sleep(.5)
    if not chosen:raise RuntimeError('豆包账号仍在处理其他任务，请稍后继续')
    def save():
        temp=state_path.with_suffix('.json.update');temp.write_text(json.dumps(state,ensure_ascii=False),encoding='utf8');temp.replace(state_path)
    try:
        check()
        page._anne_fast_button_submit=params.get('model')=='Seedance 2.0 Fast'
        if state.get('submitted') and not state.get('output') and not state.get('fast_no_receipt_next'):
            # This task already entered generation and the original was never fetched
            # back (interrupted run, closed program, or a failed download). Return to the
            # bound conversation first: if the video is already there it is downloaded
            # without submitting anything again, which also avoids paying a second time.
            # Best effort: if the route cannot be restored the normal path continues.
            try:
                ensure_task_route(page,state,save,check,progress)
                progress('已回到原对话取回豆包原片，不重新生成',6)
            except Exception as route_error:
                progress('回到原对话未成功（'+str(route_error)[:60]+'），按正常流程继续',6)
        if state.get('fast_no_receipt_next'):
            # Keep the original binding across reconnects/crashes. A late receipt
            # must cancel the planned retry before setup can leave this chat.
            params['_account_plan']=state.get('account_plan',params.get('_account_plan','unknown'))
            ensure_task_route(page,state,save,check,progress)
            audit_submission(page,state,save)
            fresh=task_replies(page,state,save)
            destination=state.pop('fast_no_receipt_next')
            expected=state.pop('fast_no_receipt_signature',None)
            if (fast_reply_signature(fresh)==expected and
                    confirm_fast_no_receipt_retry(page,state,fresh,params,15,save,check)):
                target=state.get('return_target_id','')
                state.clear();state.update(destination,return_target_id=target);save()
                if state.get('account')!=chosen['id']:
                    close_checked_account(page,chosen,folder,core)
                    raise FastAccountRotation()
            else:
                save()
                progress('豆包原对话有新状态，继续核对原任务回执',20)
        if state.get('submitted'):save()  # Refresh the exact page generation for resumed tasks.
        if recheck_split:
            progress('正在核对原对话的图文归属；不会重新上传或发送提示词',8)
            recheck_legacy_split(page,state,save,split_error_time,check)
        if state.get('submitted'):
            params['_account_plan']=state.get('account_plan',params.get('_account_plan','unknown'))
            if not state.get('url'):
                raise RuntimeError('豆包原任务已提交但缺少原对话记录，已阻止重复生成')
            progress('继续等待豆包原任务，不重复提交',20)
        else:
            if prefer_free_accounts(params) and not state.get('account') and params.get('_account_plan') in {'standard','trial'}:
                progress('普通号均无可用账号或额度，开始使用标准/体验套餐账号',5)
            prompt=str(context.get('prompt') or '').strip()
            if not prompt:raise RuntimeError('分镜提示词为空')
            paths=core['_reference_paths'](context)
            progress(f'已识别 {len(paths)} 张参考图，开始准备豆包页面',6)
            assert_reference_count(params,len(paths))
            submitted_prompt=setup(page,params,paths,check,prompt=prompt)
            prepared=True
            baseline=[m.get('video_id') for m in result_models(page)]
            message_ids=[m['id'] for m in assistant_messages(page)]
            user_message_ids=[m['id'] for m in user_messages(page)]
            if submitted_prompt is None:submitted_prompt=video_prompt(prompt,params)
            def mark_submitted():
                current_status=account_state(page)
                if params.get('_free_account_phase') and current_status.get('plan') in {'standard','trial'}:
                    raise AccountPlanChanged('账号套餐已变化，先调度普通号；尚未发送',current_status.get('plan'))
                reason=eligibility(current_status,params,daily_usage(folder,chosen['id']))
                if reason:raise RuntimeError(reason+'；尚未发送')
                route=page.url
                state.update(account=chosen['id'],account_plan=params.get('_account_plan','unknown'),submitted=True,day=today(),quota_cost=usage_cost(params),model=params['model'],aspect_ratio=params['aspect_ratio'],duration=int(params['duration']),url=route,submission_route=route,route_bound=False,baseline=baseline,message_ids=message_ids,user_message_ids=user_message_ids,prompt_fingerprint=prompt_fingerprint(submitted_prompt),output=None)
                state['expected_reference_count']=len(paths)
                if params.get('model')=='Seedance 2.0 Fast' and state.get('fast_no_receipt_account')!=chosen['id']:
                    state.update(fast_no_receipt_account=chosen['id'],fast_no_receipt_retries=0)
                state.setdefault('new_chat_attempt',1)
                state.pop('retry_pending',None);state.pop('retry_source',None)
                save()
            send_composer(page,submitted_prompt,check,mark_submitted,expected_mode='chat' if direct_mode(params) else 'video')
            progress('提示词已发送，等待豆包回复',20)
        route_started=time.monotonic()
        while True:
            bound=ensure_task_route(page,state,save,check,progress)
            if dismiss_task_safety_confirmation(page,state,check,getattr(page,'report',None)):
                continue  # Re-bind and re-read after the modal or route changes.
            audit_submission(page,state,save)
            if bound:break
            check()
            if time.monotonic()-route_started>=60:
                diagnostic_event(page,'submission_integrity',success=False,error='route_unconfirmed',elapsed=60)
                raise RuntimeError('尚未确认本次豆包对话地址，请回到包含本次提示词的原对话后继续；已保留记录，不重新提交')
            time.sleep(1)
        clock=core.get('_active_wait_clock',time.monotonic)
        started=clock();last_retry=0;last_text='';stable_at=time.monotonic();last_reply_check=0;replies=[];text=''
        waiting_since=None;last_wait_report=None;last_wait_phase=None;last_lookup_error=None;batch_ready=False
        while clock()-started<int(params.get('generation_timeout',5400)):
            check()
            ensure_task_route(page,state,save,check,progress)
            if dismiss_task_safety_confirmation(page,state,check,getattr(page,'report',None)):
                continue
            audit_submission(page,state,save)
            if time.monotonic()-last_reply_check>=1:
                last_reply_check=time.monotonic()
                replies=task_replies(page,state,save)
                text='\n'.join(m['text'] for m in replies)[-16000:]
                for reply in replies:
                    if not reply.get('streaming'):validate_receipt(reply['text'],params)
                # Cards may have no receipt text. Observe them BEFORE any send.
                if task_has_video(page,[m['id'] for m in replies]) and not state.get('media_observed'):
                    state['media_observed']=True;save()
                latest_text=replies[-1]['text'] if replies and not replies[-1].get('streaming') else ''
                accepted_before=bool(state.get('accepted') or any(
                    generation_started(m.get('text','')) for m in replies[:-1]))
                if (latest_text and content_rejection(latest_text) and accepted_before
                        and not state.get('media_observed')):
                    state['failure']='content_policy_after_receipt';save()
                    raise ContentRejectedAfterReceipt('内容合规审查拒绝')
                failure=generation_failure(latest_text) if latest_text else ''
                if failure and accepted_before and not state.get('media_observed'):
                    state['failure']='generation_rejected_after_receipt';save()
                    raise ContentRejectedAfterReceipt('受理后生成被平台拒绝')
                if failure:
                    state['failure']=failure;save()
                    raise RuntimeError('豆包生成未成功：'+failure+'（原任务已保留，未重复提交）')
                signature=json.dumps([[(m['id'],m['text'],bool(m.get('streaming'))) for m in replies],
                                      [r.get('user_message_id') for r in state.get('generation_replies',[])]],ensure_ascii=False)
                if signature!=last_text:
                    last_text=signature;stable_at=time.monotonic()
                    if replies and not any(state.get(k) for k in ('accepted','media_observed','conversation_continued')) and not generation_started(replies[-1]['text']):
                        progress('等待豆包回复稳定；尚未开始生成时，在原对话只回复“生成视频”',22)
                button_waiting=handle_generation_confirmation(page,state,replies,time.monotonic()-stable_at,save,check,progress)
                receipts=[m for m in replies if generation_started(m['text'])]
                if receipts and not button_waiting:
                    hint=receipt_wait_hint(receipts[-1]['text'])
                    if not state.get('accepted') or (hint and hint!=state.get('receipt_wait_hint')):
                        state['accepted']=True
                        state.pop('button_confirmation_pending',None)
                        if hint:state['receipt_wait_hint']=hint
                        save()
                if refresh_fast_reply_batch(page,state,replies,params,time.monotonic()-stable_at,save,check,progress):
                    last_text='';stable_at=time.monotonic();last_reply_check=0;replies=[];text='';batch_ready=False
                    continue  # Re-read the restored task before considering any further action.
                batch_ready=fast_reply_batch_ready(state,replies,time.monotonic()-stable_at,params)
                if (replies and not any(state.get(k) for k in ('accepted','media_observed','conversation_continued'))
                        and not any(m.get('streaming') for m in replies) and time.monotonic()-stable_at>=15):
                    blocker=generation_reply_blocker(replies[-1]['text'])
                    if blocker and not quota_rejected(replies[-1]['text']):
                        state['generation_reply_blocked']=blocker;save()
                        raise RuntimeError('豆包'+blocker+'；已停止自动回复，原任务保留，未重复生成')
                if batch_ready and should_reply_generation(state,replies,time.monotonic()-stable_at,params):
                    if send_generation_reply(page,state,replies,params,save,check):
                        progress('已在原对话回复“生成视频”，继续等待正式生成回执',25)
            # Accepted jobs were already being polled, but previously never sent
            # a new host status, leaving "waiting for receipt" on screen for minutes.
            if state.get('accepted') or state.get('media_observed') or state.get('button_confirmation_pending'):
                now=clock()
                if waiting_since is None:waiting_since=now
                phase='original' if state.get('media_observed') else 'confirmation' if state.get('button_confirmation_pending') else 'generation'
                if last_wait_report is None or phase!=last_wait_phase or now-last_wait_report>=30:
                    progress(*generation_wait_status(state,params,now-waiting_since))
                    last_wait_report=now;last_wait_phase=phase
            # Check lazy result cards each wait tick and poll the SAME background
            # job. This adds no parallel/restarted API chain and accepts no preview.
            if time.monotonic()-last_retry>=1:
                last_retry=time.monotonic()
                media_present=task_has_video(page,[m['id'] for m in replies])
                if media_present and not state.get('media_observed'):
                    state['media_observed']=True;save()
                lookup_ok=True
                try:
                    candidates=master_candidates(page,core,set(state.get('baseline',[])),[m['id'] for m in replies])
                except Exception:
                    candidates=[];lookup_ok=False
                    if last_lookup_error is None or time.monotonic()-last_lookup_error>=30:
                        last_lookup_error=time.monotonic()
                        diagnostic_event(page,'original_lookup',lookup_status='waiting',lookup_reason='page_unavailable')
                        if state.get('media_observed'):
                            progress('豆包视频原片同步中，继续等待原任务',80)
                        else:
                            progress('豆包页面结果暂未同步，继续等待原任务，不重复提交',35 if state.get('accepted') else 25)
                if candidates:
                    ensure_task_route(page,state,save,check,progress)
                    progress('正在下载豆包最高画质无水印原片',90)
                    output=download(candidates[0],core['_output_path'](context),core)
                    metrics=core['_video_metrics'](output)
                    if abs(float(metrics.get('duration',0))-int(params['duration']))>1:
                        state['mismatched_output']=output;save()
                        raise RuntimeError(f'豆包实际成片为 {metrics.get("duration",0):.2f} 秒，与请求 {params["duration"]} 秒不符；原片已保留，未重复生成')
                    state['output']=output;state['sha256']=_file_sha256(output);save()
                    diagnostic_event(page,'original_download',success=True,width=metrics.get('width',0),
                                     height=metrics.get('height',0),bitrate=metrics.get('bitrate',0),
                                     content_length=metrics.get('content_length',0))
                    quality=(f'（{int(metrics["width"])}×{int(metrics["height"])} / {float(metrics["bitrate"])/1000000:.2f} Mbps）'
                             if all(metrics.get(k) for k in ('width','height','bitrate')) else '')
                    progress('豆包无水印原片已下载，正在回传字字'+quality,99)
                    return [output]
                if not state.get('accepted') and not state.get('media_observed') and state.get('submitted_message_id') and quota_rejected(text) and not any(m.get('streaming') for m in replies) and time.monotonic()-stable_at>=15:
                    raise QuotaRejected('豆包明确拒绝本次生成：今日额度已用完')
                if lookup_ok and batch_ready and confirm_fast_no_receipt_retry(page,state,replies,params,time.monotonic()-stable_at,save,check):
                    raise FastNoReceipt('两次确认后仍无生成回执')
            time.sleep(1)
        raise RuntimeError('豆包原片尚未取回；任务记录已保留，下次继续原对话，不重新生成')
    except AccountLoggedOut:
        guard=getattr(page,'_anne_submission_guard',None)
        if state.get('submitted') or prepared or isinstance(guard,dict):
            if not state.get('submitted'):
                state.update(account=chosen['id'],preparation_blocked=True,
                             preparation_blocked_reason='logged_out_after_prepare')
                save()
            raise RuntimeError('账号掉线，但已有图文草稿或提交记录；已保留，不会自动切号重复上传或发送')
        remember_plan(chosen,folder,'logged_out')
        avoided=set(state.get('avoid_accounts',[]));avoided.add(chosen['id'])
        state.update(avoid_accounts=sorted(avoided))
        state.pop('account',None);state.pop('return_target_id',None);save()
        progress('账号 '+str(abs(int(chosen.get('index',-1))))+' 已掉线，尚未填写或上传，正在检查其他账号',5)
    except AccountPlanUnavailable:
        close_checked_account(page,chosen,folder,core)
        remember_plan(chosen,folder,'free')
        progress('账号 '+str(abs(int(chosen.get('index',-1))))+' 当前页面不支持所选模型，正在检查其他账号',5)
    except AccountPlanChanged as error:
        remember_plan(chosen,folder,error.plan)
        guard=getattr(page,'_anne_submission_guard',None)
        if prepared or isinstance(guard,dict):
            # Already prepared bytes must not trigger another account/upload.
            # Preserve only metadata; never persist the full prompt or filenames.
            state.update(account=chosen['id'],preparation_blocked=True,
                         preparation_blocked_reason='account_plan_changed_after_prepare',
                         account_plan=error.plan,expected_reference_count=len(paths),
                         prompt_fingerprint=prompt_fingerprint(video_prompt(prompt,params)))
            save()
            diagnostic_event(page,'submission_integrity',success=False,error='account_plan_changed',
                             total=int(len(guard.get('paths',[]))) if isinstance(guard,dict) else len(paths))
            raise RuntimeError('参考图上传后才识别到账号为会员套餐，已保留原图文草稿并停止；不会自动切号再次上传或发送')
        progress('该账号确认为会员套餐，在填写图文前继续检查普通号；尚未上传或发送',5)
    except FastNoReceipt:
        retries=int(state.get('fast_no_receipt_retries',0) or 0) if state.get('fast_no_receipt_account')==chosen['id'] else 0
        history=fast_retry_history(state)
        history.update(fast_no_receipt_account=chosen['id'],fast_no_receipt_retries=retries)
        if retries<FAST_NO_RECEIPT_RETRY_LIMIT:
            history['fast_no_receipt_retries']=retries+1
            destination=dict(history,account=chosen['id'],
                         account_plan=params.get('_account_plan','unknown'),new_chat_attempt=retries+2,
                         previous_failure='fast_no_receipt')
            progress(f'豆包 Fast 已回复两次仍无生成回执，正在同一账号新建对话重提（第 {retries+1}/{FAST_NO_RECEIPT_RETRY_LIMIT} 次）',10)
        else:
            avoided=set(history.get('avoid_accounts',[]));avoided.add(chosen['id'])
            history['avoid_accounts']=sorted(avoided)
            history['fast_no_receipt_avoid_day']=today()
            daily_avoided=set(history.get('fast_no_receipt_avoid_accounts',[]));daily_avoided.add(chosen['id'])
            history['fast_no_receipt_avoid_accounts']=sorted(daily_avoided)
            mark_fast_no_receipt_skip(folder,chosen['id'])
            destination=dict(history,previous_failure='fast_no_receipt')
            progress(f'豆包 Fast 新建对话重提{FAST_NO_RECEIPT_RETRY_LIMIT}次仍无生成回执，今天跳过此账号，正在切换下一个账号',10)
        state.update(fast_no_receipt_next=destination,fast_no_receipt_signature=fast_reply_signature(replies));save()
    except FastAccountRotation:
        pass
    except ContentRejectedAfterReceipt:
        attempts=int(state.get('content_rejection_attempts',0) or 0)
        history=fast_retry_history(state)
        if attempts<1:
            state.clear();state.update(history,content_rejection_attempts=attempts+1,
                         non_generation_attempts=attempts+1,account=chosen['id'],
                         account_plan=params.get('_account_plan','unknown'),new_chat_attempt=2,
                         previous_failure='content_policy_after_receipt')
            progress('豆包已先受理后拒绝生成，正在同一账号新建对话重提（第 1 次）',10)
        else:
            avoided=set(history.get('avoid_accounts',[]));avoided.add(chosen['id'])
            history['avoid_accounts']=sorted(avoided)
            state.clear();state.update(history,content_rejection_attempts=attempts+1,
                         non_generation_attempts=attempts+1,
                         previous_failure='content_policy_after_receipt')
            progress('同一账号第二次被平台拒绝生成，正在切换下一个豆包账号',10)
        save()
    except SubmissionIntegrityError:
        if not state.get('submission_integrity_error'):
            state.update(account=chosen['id'],submission_integrity_error='unexpected_submission')
            save()
        raise
    except QuotaRejected:
        # Only an explicit pre-acceptance refusal permits moving this storyboard.
        # Unknown network errors, accepted receipts and interrupted sends stay bound.
        marker=folder/('quota-'+hashlib.sha256((chosen['id']+today()).encode()).hexdigest()+'.json')
        pending=marker.with_suffix('.json.update')
        pending.write_text(json.dumps(dict(account=chosen['id'],day=today(),submitted=True,quota_exhausted=True)),encoding='utf8')
        pending.replace(marker)
        attempts=list(state.get('rejected_attempts',[]))
        attempts.append({k:state.get(k) for k in ('account','day','url','model','duration','submitted_message_id')})
        retry_state=dict(fast_retry_history(state),**{k:state[k] for k in ('non_generation_attempts','new_chat_attempt') if k in state})
        state.clear();state.update(retry_state,rejected_attempts=attempts);save()
        close_checked_account(page,chosen,folder,core)
        progress('该豆包账号额度已用完，正在选择下一个符合条件的账号',10)
    except Exception as error:
        if state.get('submitted') and any(token in str(error) for token in
                ('用户已停止','正在停止','插件所有操作已暂停','任务已取消')):
            state['failure']='paused';state['failure_reason']='user_stop';save()
        raise
    finally:
        close_page(page)
        lock.release()
    return generate(context,params,core)
