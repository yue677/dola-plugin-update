﻿(options) => {
  'use strict';
  const key = '__anneDolaDurationHook';
  // v4 additionally rewrites the ability_param model, so accounts whose picker no
  // longer lists Seedance 2.5 can still submit it (verified on the wire).
  // A page holding an older frozen hook needs a normal client restart.
  const version = 5;
  const fail = reason => ({verified: false, reason});
  // Wire values observed from the client itself: the picker's "2.0 Fast" sends
  // seedance_v2.0; the hidden 2.5 model sends seedance_v2.5. Plain "2.0" has no
  // confirmed wire value, so it is never forced.
  const wireModel = model => ({'2.0 Fast': 'seedance_v2.0', '2.5': 'seedance_v2.5'})[model] || '';

  function routeNow() {
    try {
      const url = new URL(window.location.href);
      if (!['chrome:', 'dola:'].includes(url.protocol) || url.hostname !== 'dola-chat' ||
          url.port || url.username || url.password) return null;
      return [url.pathname, url.search.slice(1), url.hash.slice(1)];
    } catch (_) { return null; }
  }
  const sameRoute = (a, b) => a && b && a.length === 3 && a.every((value, i) => value === b[i]);

  function selectedModel() {
    try {
      const visible = element => {
        const rect = element.getBoundingClientRect();
        const style = getComputedStyle(element);
        return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && style.display !== 'none';
      };
      const editors = Array.from(document.querySelectorAll('[role="textbox"],.tiptap[contenteditable="true"],textarea[data-testid="chat_input_input"]'))
        .filter(element => visible(element) && !element.closest('[data-message-id]'));
      const roots = Array.from(new Set(editors.map(element =>
        element.closest('[data-chat-input],[data-testid="chat_input"]') || element.closest('.guidance-input-surface'))
        .filter(Boolean)));
      if (roots.length !== 1) return null;
      const controls = Array.from(roots[0].querySelectorAll('[data-input-engine-actionbar-control-key="video-model"]'))
        .filter(element => !element.closest('[data-message-id]'));
      const shown = controls.filter(visible);
      const control = shown.length === 1 ? shown[0] : shown.length === 0 && controls.length === 1 ? controls[0] : null;
      if (!control) return null;
      const text = String(control.innerText || control.textContent || '');
      const matches = Array.from(text.matchAll(/(?:Seedance\s*)?2[.．](?:0\s*Fast\b|0\b|5\b)/gi));
      if (matches.length !== 1) return null;
      const value = matches[0][0].replace(/Seedance|\s/g, '').replace('．', '.').toLowerCase();
      return value === '2.0fast' ? '2.0 Fast' : value;
    } catch (_) { return null; }
  }

  function validate(value) {
    if (!value || typeof value !== 'object' || ![15, 30].includes(value.duration) ||
        !['2.0', '2.0 Fast', '2.5'].includes(value.model) || !Array.isArray(value.route) ||
        value.route.length !== 3 || !value.route.every(part => typeof part === 'string'))
      return fail('invalid_options');
    // 30s is valid for 2.5 and for 2.0 Fast (the 1-credit recipe); plain 2.0 stays at 15s.
    if (value.duration === 30 && !['2.5', '2.0 Fast'].includes(value.model)) return fail('unsupported_duration');
    if (value.forceModel !== undefined && typeof value.forceModel !== 'boolean') return fail('invalid_options');
    // An empty string means "not requested" and stays valid: the caller always sends the
    // key, so rejecting the empty value would break every call.
    if (value.ratio !== undefined && value.ratio !== '' && (typeof value.ratio !== 'string' ||
        !/^[0-9]{1,2}\s*[:：]\s*[0-9]{1,2}$/.test(String(value.ratio).trim()))) return fail('invalid_options');
    const forced = value.forceModel === true ? wireModel(value.model) : '';
    if (value.forceModel === true && !forced) return fail('invalid_options');
    const route = routeNow();
    if (!route) return fail('route_invalid');
    if (!sameRoute(route, value.route)) return fail('route_changed');
    const model = selectedModel();
    // Without an explicit wire override the composer must show exactly the
    // requested model. With one (Dola removed 2.5 from the picker) only video
    // mode matters: the outgoing request is still checked to carry that model.
    if (!forced && !model) return fail('model_unavailable');
    if (!forced && model !== value.model) return fail('model_changed');
    return {configuration: Object.freeze({duration: value.duration, model: value.model, forceModel: forced,
                                         ratio: (typeof value.ratio === 'string'
                                           ? value.ratio.trim().replace('：', ':') : ''),
                                         route: Object.freeze(value.route.slice())})};
  }

  // Only replace the duration token inside ability_param. JSON.parse/stringify
  // of the whole request would corrupt unrelated large integer IDs or escapes.
  function stringEnd(text, start) {
    for (let i = start + 1; i < text.length; i++) {
      if (text[i] === '\\') { i++; continue; }
      if (text[i] === '"') return i + 1;
    }
    throw new Error('invalid_json');
  }
  const space = (text, start) => {
    while (start < text.length && /[\t\n\r ]/.test(text[start])) start++;
    return start;
  };
  function valueEnd(text, start) {
    if (text[start] === '"') return stringEnd(text, start);
    if (text[start] === '{' || text[start] === '[') {
      let depth = 1;
      for (let i = start + 1; i < text.length; i++) {
        if (text[i] === '"') { i = stringEnd(text, i) - 1; continue; }
        if (text[i] === '{' || text[i] === '[') depth++;
        if (text[i] === '}' || text[i] === ']') depth--;
        if (depth === 0) return i + 1;
      }
      throw new Error('invalid_json');
    }
    let end = start;
    while (end < text.length && !/[\t\n\r ,}\]]/.test(text[end])) end++;
    return end;
  }
  function members(text, start = 0) {
    start = space(text, start);
    if (text[start] !== '{') throw new Error('not_object');
    const result = new Map();
    let pos = space(text, start + 1);
    while (text[pos] !== '}') {
      if (text[pos] !== '"') throw new Error('invalid_key');
      const keyEnd = stringEnd(text, pos);
      const name = JSON.parse(text.slice(pos, keyEnd));
      if (result.has(name)) throw new Error('duplicate_key');
      pos = space(text, keyEnd);
      if (text[pos] !== ':') throw new Error('invalid_key');
      const begin = space(text, pos + 1);
      const end = valueEnd(text, begin);
      result.set(name, {begin, end});
      pos = space(text, end);
      if (text[pos] === '}') break;
      if (text[pos] !== ',') throw new Error('invalid_json');
      pos = space(text, pos + 1);
    }
    return result;
  }
  function videoBody(body) {
    if (typeof body !== 'string') return null;
    try {
      const request = JSON.parse(body);
      if (!request || typeof request !== 'object' || Array.isArray(request)) return null;
      const ability = request.chat_ability;
      if (!ability || typeof ability !== 'object' || Array.isArray(ability) ||
          typeof ability.ability_param !== 'string') return null;
      const paramText = ability.ability_param;
      const param = JSON.parse(paramText);
      if (!param || typeof param !== 'object' || Array.isArray(param) ||
          !Object.prototype.hasOwnProperty.call(param, 'duration') ||
          typeof param.duration !== 'number' || !Number.isFinite(param.duration) || param.duration <= 0) return null;
      const rootMembers = members(body);
      const abilitySpan = rootMembers.get('chat_ability');
      if (!abilitySpan) return null;
      const valueSpan = members(body, abilitySpan.begin).get('ability_param');
      const paramMembers = members(paramText);
      const durationSpan = paramMembers.get('duration');
      const modelSpan = paramMembers.get('model');
      const ratioSpan = paramMembers.get('ratio');
      if (!valueSpan || !durationSpan) return null;
      return {request, paramText, param, valueSpan, durationSpan, modelSpan, ratioSpan, rootMembers};
    } catch (_) { return null; }
  }
  // Only the duration/model tokens inside ability_param are replaced: parsing and
  // re-serialising the whole request would corrupt large integer IDs and escapes.
  function transform(body, duration, information = null, forceModel = '', forceRatio = '') {
    try {
      const info = information || videoBody(body);
      if (!info) return body;
      const {paramText, valueSpan} = info;
      let changedParam = paramText;
      let touched = false;
      // Duration first: one token inside ability_param, exactly like the old build.
      const durationSpan = members(changedParam).get('duration');
      if (durationSpan) {
        const current = JSON.parse(changedParam.slice(durationSpan.begin, durationSpan.end));
        if (current !== duration) {
          changedParam = changedParam.slice(0, durationSpan.begin) + String(duration) +
            changedParam.slice(durationSpan.end);
          touched = true;
        }
      }
      // Model: re-derived from the edited text so the span cannot shift underneath us.
      if (forceModel) {
        const modelSpan = members(changedParam).get('model');
        if (modelSpan) {
          const current = JSON.parse(changedParam.slice(modelSpan.begin, modelSpan.end));
          if (current !== forceModel) {
            changedParam = changedParam.slice(0, modelSpan.begin) + JSON.stringify(forceModel) +
              changedParam.slice(modelSpan.end);
            touched = true;
          }
        }
      }
      // Ratio: older builds omit the member entirely, so it is inserted before the
      // closing brace instead of being dropped.
      if (forceRatio) {
        const ratioSpan = members(changedParam).get('ratio');
        if (ratioSpan) {
          const current = JSON.parse(changedParam.slice(ratioSpan.begin, ratioSpan.end));
          if (current !== forceRatio) {
            changedParam = changedParam.slice(0, ratioSpan.begin) + JSON.stringify(forceRatio) +
              changedParam.slice(ratioSpan.end);
            touched = true;
          }
        } else {
          changedParam = changedParam.replace(/\s*\}$/, ',"ratio":' + JSON.stringify(forceRatio) + '}');
          touched = true;
        }
      }
      if (!touched) return body;
      return body.slice(0, valueSpan.begin) + JSON.stringify(changedParam) + body.slice(valueSpan.end);
    } catch (_) { return body; }
  }
  function firstConversationBody(body, info, localId) {
    try {
      const meta = info.request.client_meta;
      const option = info.request.option;
      if (!meta || typeof meta !== 'object' || Array.isArray(meta) ||
          !option || typeof option !== 'object' || Array.isArray(option) ||
          meta.local_conversation_id !== localId || meta.conversation_id !== '' ||
          option.need_create_conversation !== true) return false;
      const metaSpan = info.rootMembers.get('client_meta');
      const optionSpan = info.rootMembers.get('option');
      if (!metaSpan || !optionSpan) return false;
      const metaMembers = members(body, metaSpan.begin);
      const optionMembers = members(body, optionSpan.begin);
      return metaMembers.has('local_conversation_id') && metaMembers.has('conversation_id') &&
        optionMembers.has('need_create_conversation');
    } catch (_) { return false; }
  }
  function syntheticCheck(duration, forceModel = '') {
    try {
      const param = '{"model":"seedance_v2.0","duration":5,"untouched":900719925474099312345,"keep":"a\\u0041"}';
      const source = '{"id":900719925474099312345,"chat_ability":{"ability_param":' + JSON.stringify(param) + '},"keep":true}';
      const result = transform(source, duration, null, forceModel);
      const parsed = JSON.parse(result);
      const actual = JSON.parse(parsed.chat_ability.ability_param);
      return actual.duration === duration && (!forceModel || actual.model === forceModel) &&
        parsed.keep === true && actual.keep === 'aA' &&
        result.includes('"id":900719925474099312345') &&
        parsed.chat_ability.ability_param.includes('"untouched":900719925474099312345') &&
        transform('{broken', duration, null, forceModel) === '{broken' &&
        transform('{"duration":5}', duration, null, forceModel) === '{"duration":5}';
    } catch (_) { return false; }
  }
  function legacyHook(fn) {
    try {
      const text = Function.prototype.toString.call(fn);
      return /Duration patched/i.test(text) && /targetDuration/.test(text) && /chat_ability/.test(text);
    } catch (_) { return true; }
  }
  function withBody(init, body) {
    if (init == null) return {body};
    const copy = Object.create(Object.getPrototypeOf(init));
    const descriptors = Object.getOwnPropertyDescriptors(init);
    delete descriptors.body;
    Object.defineProperties(copy, descriptors);
    Object.defineProperty(copy, 'body', {value: body, writable: true, enumerable: true, configurable: true});
    return copy;
  }
  function bodyPacket(body) {
    if (typeof body === 'string') return {text: body, replace: value => value};
    try {
      const view = ArrayBuffer.isView(body);
      const buffer = Object.prototype.toString.call(body) === '[object ArrayBuffer]';
      if ((!view && !buffer) || typeof TextDecoder !== 'function' || typeof TextEncoder !== 'function') return null;
      const bytes = view ? new Uint8Array(body.buffer, body.byteOffset, body.byteLength) : new Uint8Array(body);
      if (bytes.byteLength > 8 * 1024 * 1024) return null;
      const text = new TextDecoder('utf-8', {fatal: true}).decode(bytes);
      return {text, replace(value) {
        const encoded = new TextEncoder().encode(value);
        return buffer ? encoded.buffer : encoded;
      }};
    } catch (_) { return null; }
  }

  try {
    const prior = window[key];
    if (prior !== undefined) {
      const descriptor = Object.getOwnPropertyDescriptor(window, key);
      if (!prior || prior.version !== version || prior.brand !== 'anne.dola.duration/1' || !Object.isFrozen(prior) ||
          !descriptor || descriptor.value !== prior || descriptor.configurable || descriptor.writable ||
          typeof prior.update !== 'function' || typeof prior.verify !== 'function' ||
          typeof prior.arm !== 'function' || typeof prior.receipt !== 'function') return fail('incompatible_hook');
      return prior.update(options);
    }
    const checked = validate(options);
    if (!checked.configuration) return checked;
    const prototype = window.XMLHttpRequest && window.XMLHttpRequest.prototype;
    if (typeof window.fetch !== 'function' || !prototype || typeof prototype.open !== 'function' ||
        typeof prototype.send !== 'function') return fail('missing_transport');
    const originalFetch = window.fetch;
    const originalOpen = prototype.open;
    const originalSend = prototype.send;
    if ([originalFetch, originalOpen, originalSend].some(legacyHook)) return fail('legacy_hook');
    if (!syntheticCheck(checked.configuration.duration,
                        checked.configuration.forceModel || '')) return fail('verification_failed');

    const state = {configuration: checked.configuration, boundRoute: checked.configuration.route,
      pendingRoute: null, adoptedLocalId: null, enabled: false, reason: 'verification_failed',
      sequence: 0, ticket: null, receipt: null};
    const xhrConfigurations = new WeakMap();
    const ownWrappers = () => window.fetch === fetchWrapper && prototype.open === openWrapper && prototype.send === sendWrapper;
    const liveTicket = () => state.ticket && state.ticket.configuration === state.configuration &&
      state.ticket.status !== 'blocked' && Date.now() <= state.ticket.expires;
    function activeScope(transport = false) {
      if (!state.enabled) return null;
      if (!ownWrappers()) { state.enabled = false; state.reason = 'hook_replaced'; return null; }
      const route = routeNow();
      const bound = state.boundRoute;
      let localId = null;
      if (sameRoute(route, bound)) {
        if (state.pendingRoute) { state.reason = 'route_changed'; return null; }
      } else {
        const match = route && /^\/chat\/((?:local_)?\d{1,32})$/.exec(route[0]);
        if (!['/', '/chat', '/chat/'].includes(bound[0]) || !match || route[1] !== bound[1] || route[2] !== bound[2] ||
            (state.pendingRoute && !sameRoute(route, state.pendingRoute))) {
          state.enabled = false; state.reason = 'route_changed'; return null;
        }
        if (!state.pendingRoute) state.pendingRoute = Object.freeze(route.slice());
        localId = match[1];
      }
      const model = selectedModel();
      // Clicking Send can unmount the input controls before the request starts.
      // Only an explicit, short-lived arm of this exact configuration can bridge
      // an absent control; a visible different model is never accepted unless this
      // configuration carries a wire-level model override.
      const forced = !!state.configuration.forceModel;
      if (!forced && model !== state.configuration.model && !(transport && !model && liveTicket())) {
        state.enabled = false; state.reason = model ? 'model_changed' : 'model_unavailable'; return null;
      }
      return {configuration: state.configuration, route, localId};
    }
    function verify() {
      const scope = activeScope();
      if (!scope) return fail(state.reason);
      if (scope.localId) return fail('route_transition_pending');
      if (!syntheticCheck(scope.configuration.duration,
                        scope.configuration.forceModel || '')) return fail('verification_failed');
      return {verified: true, duration: scope.configuration.duration,
        model: scope.configuration.forceModel || scope.configuration.model,
        version,
        verification: 'configured-not-submitted'};
    }
    function arm() {
      const proof = verify();
      if (!proof.verified) return proof;
      state.ticket = {id: ++state.sequence, configuration: state.configuration,
        expires: Date.now() + 30000, status: 'armed'};
      state.receipt = {arm_id: state.ticket.id, status: 'armed', duration: proof.duration,
        model: proof.model, count: 0};
      return {verified: true, armed: true, arm_id: state.ticket.id, duration: proof.duration,
        model: proof.model, version};
    }
    function blocked(reason) {
      state.reason = reason || state.reason || 'verification_failed';
      if (state.ticket) {
        state.ticket.status = 'blocked';
        state.receipt = {arm_id: state.ticket.id, status: 'blocked', duration: state.configuration.duration,
          count: state.receipt?.count || 0, reason: state.reason};
      }
      return new Error('ANNE_DURATION_BLOCKED:' + state.reason);
    }
    function prepare(text, capturedScope = null) {
      const info = videoBody(text);
      if (!info) return null; // Upload, telemetry and normal chat do not touch the arm.
      if (state.ticket && !liveTicket()) throw blocked('arm_expired_or_cancelled');
      const scope = activeScope(true);
      if (!scope) {
        if (state.ticket) throw blocked(state.reason);
        return null;
      }
      // A request captured before a rebind belongs to the older configuration:
      // forward it byte-exact instead of blocking the client's own send.
      if (capturedScope && capturedScope.configuration !== scope.configuration) return null;
      const captured = capturedScope || scope;
      const initialScope = ['/', '/chat', '/chat/'].includes(captured.configuration.route[0]) &&
        (captured.localId || sameRoute(captured.route, captured.configuration.route));
      const requiredLocalId = scope.localId || (initialScope && state.adoptedLocalId);
      if (requiredLocalId && !firstConversationBody(text, info, requiredLocalId)) throw blocked('first_request_mismatch');
      const changed = transform(text, scope.configuration.duration, info, scope.configuration.forceModel || '',
                                scope.configuration.ratio || '');
      const proof = videoBody(changed);
      if (!proof || proof.param.duration !== scope.configuration.duration) throw blocked('outgoing_duration_mismatch');
      if (scope.configuration.forceModel && proof.param.model !== scope.configuration.forceModel) {
        throw blocked('outgoing_model_mismatch');
      }
      if (scope.configuration.ratio && proof.param.ratio !== scope.configuration.ratio) {
        throw blocked('outgoing_ratio_mismatch');
      }
      const current = activeScope(true);
      if (!current || current.configuration !== scope.configuration || !sameRoute(current.route, scope.route)) {
        throw blocked(state.reason || 'scope_changed');
      }
      if (scope.localId) {
        state.boundRoute = Object.freeze(scope.route.slice());
        state.pendingRoute = null;
        state.adoptedLocalId = scope.localId;
      }
      return {text: changed, before: info.param.duration, after: proof.param.duration,
        before_model: info.param.model, after_model: proof.param.model};
    }
    function forwarded(prepared, transport) {
      if (!prepared || !state.ticket) return;
      state.ticket.status = 'forwarded';
      state.receipt = {arm_id: state.ticket.id, status: 'forwarded', duration: prepared.after,
        model: prepared.after_model, original_duration: prepared.before,
        original_model: prepared.before_model, transport, count: (state.receipt?.count || 0) + 1};
    }
    function fetchWrapper(input, init) {
      const receiver = this;
      const args = Array.from(arguments);
      const forward = next => Reflect.apply(originalFetch, receiver, next);
      let suppliedBody;
      try { if (init != null && 'body' in Object(init)) suppliedBody = init.body; }
      catch (_) { return forward(args); }
      const packet = bodyPacket(suppliedBody);
      if (packet) {
        let prepared;
        try {
          prepared = prepare(packet.text);
          if (prepared && prepared.text !== packet.text) {
            args[1] = withBody(init, packet.replace(prepared.text));
          }
        } catch (error) { return Promise.reject(error); }
        if (prepared) forwarded(prepared, 'fetch');
        // Keep the native fetch contract: a synchronous exception from the
        // original transport must remain synchronous and must never be turned
        // into a second attempt or an artificial rejected Promise.
        return forward(args);
      }
      // Preserve explicit streams, FormData and binary uploads. The plugin also
      // independently checks the browser's actual outgoing request event.
      if (suppliedBody !== undefined || typeof window.Request !== 'function' || !(input instanceof window.Request)) return forward(args);
      const captured = {configuration: state.configuration, route: routeNow(), localId: null};
      let pending;
      try { pending = input.clone().text(); }
      catch (_) { return forward(args); }
      return pending.then(text => {
        const prepared = prepare(text, captured);
        if (prepared) {
          if (prepared.text !== text) args[1] = withBody(init, prepared.text);
          forwarded(prepared, 'fetch-request');
        }
        return forward(args);
      }, () => forward(args));
    }
    function openWrapper() {
      xhrConfigurations.delete(this);
      const result = Reflect.apply(originalOpen, this, arguments);
      // Record identity only. Background XHRs must not invalidate a video arm
      // just because the composer is rerendering while an asset is uploading.
      xhrConfigurations.set(this, {configuration: state.configuration, route: routeNow(), localId: null});
      return result;
    }
    function sendWrapper(data) {
      const args = Array.from(arguments);
      const packet = bodyPacket(data);
      if (packet) {
        // An XHR opened before this hook was installed is outside the task
        // scope. Leave it byte-for-byte untouched; only an XHR whose open()
        // was observed by this hook may consume the armed duration ticket.
        const captured = xhrConfigurations.get(this);
        if (captured) {
          const prepared = prepare(packet.text, captured);
          if (prepared) {
            if (prepared.text !== packet.text) args[0] = packet.replace(prepared.text);
            forwarded(prepared, 'xhr');
          }
        }
      }
      return Reflect.apply(originalSend, this, args);
    }
    function manualArm(event) {
      if (!event.isTrusted || liveTicket()) return;
      const target = event.target;
      if (!target || typeof target.closest !== 'function' || target.closest('[data-message-id]')) return;
      const send = target.closest('[data-testid="chat_input_send_button"],#flow-end-msg-send');
      const enter = event.type === 'keydown' && event.key === 'Enter' && !event.shiftKey && !event.isComposing &&
        target.closest('[role="textbox"],.tiptap[contenteditable="true"],textarea[data-testid="chat_input_input"]');
      if (send || enter) arm();
    }
    const api = Object.freeze({version, brand: 'anne.dola.duration/1', verify, arm,
      receipt(id) {
        if (!state.receipt || state.receipt.arm_id !== id) return {status: 'unknown', arm_id: id};
        return Object.assign({}, state.receipt);
      },
      update(value) {
        state.enabled = false;
        if (!ownWrappers()) return fail('hook_replaced');
        const next = validate(value);
        if (!next.configuration) return next;
        if (!syntheticCheck(next.configuration.duration, next.configuration.forceModel || '',
                        next.configuration.forceModel || '')) return fail('verification_failed');
        state.configuration = next.configuration;
        state.boundRoute = next.configuration.route;
        state.pendingRoute = null;
        state.adoptedLocalId = null;
        state.ticket = null;
        state.receipt = null;
        state.enabled = true;
        return verify();
      }
    });
    try {
      window.fetch = fetchWrapper;
      prototype.open = openWrapper;
      prototype.send = sendWrapper;
      if (!ownWrappers()) throw new Error('installation_failed');
      state.enabled = true;
      if (!verify().verified) throw new Error('verification_failed');
      Object.defineProperty(window, key, {value: api, enumerable: false, configurable: false, writable: false});
      if (typeof document.addEventListener === 'function') {
        document.addEventListener('pointerdown', manualArm, true);
        document.addEventListener('click', manualArm, true);
        document.addEventListener('keydown', manualArm, true);
      }
      return verify();
    } catch (_) {
      state.enabled = false;
      try { if (window.fetch === fetchWrapper) window.fetch = originalFetch; } catch (_) {}
      try { if (prototype.open === openWrapper) prototype.open = originalOpen; } catch (_) {}
      try { if (prototype.send === sendWrapper) prototype.send = originalSend; } catch (_) {}
      return fail('install_failed');
    }
  } catch (_) { return fail('install_failed'); }
}
