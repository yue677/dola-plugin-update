(() => {
  const visible=e=>!!(e.getBoundingClientRect().width&&e.getBoundingClientRect().height)&&getComputedStyle(e).visibility!=='hidden';
  const profiles=[...document.querySelectorAll('button[data-slot="dropdown-menu-trigger"]')].filter(e=>
    visible(e)&&!e.closest('[data-message-id],.guidance-input-surface,[role="dialog"],[role="menu"]')&&e.innerText.length<100);
  // A conversation may mention 登录后/请登录; body text is not a login signal.
  const profileReady=profiles.some(e=>{
    const name=e.innerText.trim();
    return name&&!/^(登录|登录\/注册|立即登录|对话|工作|技能|更多)$/.test(name)&&
      (!!e.querySelector('img,[data-slot="avatar"],[class*="avatar" i]')||
       /^(?:用户\s*\d+|.*(?:标准套餐|体验套餐|普通套餐|普通账号))$/.test(name));
  });
  const loginButton=[...document.querySelectorAll('button')].some(e=>visible(e)&&
    !e.closest('[data-message-id]')&&/^(登录|登录\/注册|立即登录)$/.test(e.innerText.trim()));
  const login=loginButton&&!profileReady;
  const text=profiles.map(e=>e.innerText).join('\n');
  const lines=text.split('\n').map(s=>s.trim());
  const expired=/已到期|已过期/.test(text);
  const labels=new Set(lines.filter(s=>s==='标准套餐'||s==='体验套餐'));
  const label=!expired&&labels.size===1?[...labels][0]:'';
  const free=expired||lines.some(s=>/^(免费(?:套餐|账号)?|普通(?:套餐|账号)|未订阅)$/.test(s));
  const plan=login?'logged_out':expired?'free':label==='标准套餐'?'standard':label==='体验套餐'?'trial':free?'free':'unknown';
  const login_state=login?'logged_out':profileReady||['standard','trial','free'].includes(plan)?'logged_in':'unknown';
  // Restrict quota reads to current controls, never historical conversation text.
  const controls=[...document.querySelectorAll('.guidance-input-surface,[role="dialog"],[data-creation-params-panel-id]')].filter(e=>visible(e)&&!e.closest('[data-message-id]')).map(e=>e.innerText).join('\n');
  const remaining=controls.match(/(?:今日|今天|每日)(?:视频(?:生成)?)(?:免费)?(?:剩余|可用|额度剩余)\s*[:：]?\s*(\d+)\s*(?:个|次|条)/)||controls.match(/(?:今日|今天|每日)(?:免费)?(?:剩余|可用)\s*[:：]?\s*(\d+)\s*(?:个|次|条)\s*(?:免费)?视频(?:生成)?(?:额度|次数)?/);
  const exhausted=/(?:今日|今天).{0,12}(?:视频(?:生成)?(?:次数|额度)|免费额度).{0,8}(?:已(?:经)?(?:用完|耗尽|达(?:到)?上限)|不足)|(?:视频|免费)(?:生成)?额度已用完/.test(controls);
  return {plan,login_state,plan_label:plan==='standard'?'标准套餐':plan==='trial'?'体验套餐':'',
    remaining:remaining?Number(remaining[1]):null, exhausted};
})()
