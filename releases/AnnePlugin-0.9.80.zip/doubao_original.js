(() => {
  if (!/^https:\/\/(www\.)?doubao\.com\//.test(location.href)) return;
  // A still-running older workbench may reinject its v1 helper. Keep the
  // asynchronous lookup in a separate namespace so that it cannot be discarded.
  if (window.__anneDoubaoOriginal?.version === 3) {
    window.__anneDoubao = window.__anneDoubaoOriginal;
    return;
  }
  const accepted = value => {
    try {
      const u = new URL(value);
      return u.protocol === 'https:' && !u.username && !u.password &&
        /^(?:[a-z0-9-]+-)?videoweb(?:-download)?\.doubao\.com$/.test(u.hostname) &&
        u.searchParams.getAll('download').length === 1 &&
        u.searchParams.get('download') === 'true';
    } catch { return false; }
  };
  const failure = (reason, message) => Object.assign(new Error(message), {originalReason:reason});
  const nodeId = value => {
    if (typeof value === 'number' && !Number.isSafeInteger(value))
      throw failure('identity', '原片节点标识精度不正确');
    const id = String(value ?? '');
    if (!/^\d+$/.test(id)) throw failure('identity', '原片节点标识不正确');
    return id;
  };
  const validVideo = value => typeof value === 'string' && /^v\d[a-zA-Z0-9]{15,100}$/.test(value);
  async function request(path, body, route) {
    if (location.href !== route) throw failure('route_changed', '对话已切换，请返回原视频后重试');
    const entry = performance.getEntriesByType('resource').map(r => r.name).reverse().find(value => {
      try { const u = new URL(value); return u.origin === location.origin && u.pathname.startsWith('/samantha/'); }
      catch { return false; }
    });
    const url = new URL(entry || location.origin); url.pathname = '/samantha/aispace/' + path;
    const response = await fetch(url, {method:'POST', credentials:'include',
      headers:{'content-type':'application/json','agw-js-conv':'str'}, body:JSON.stringify(body),
      signal:AbortSignal.timeout(15000)});
    if (!response.ok) throw failure('network', '豆包下载信息暂不可用');
    const json = await response.json();
    if (location.href !== route) throw failure('route_changed', '对话已切换，请返回原视频后重试');
    if (json.code !== 0) throw failure('network', '豆包下载接口未就绪，请确认账号登录状态');
    return json.data || {};
  }
  async function resolve(videoId, memo) {
    if (!validVideo(videoId)) throw failure('identity', '视频标识不正确');
    const route = location.href;
    if (memo.route !== route || Date.now() - (memo.time || 0) > 60000) {
      delete memo.root; delete memo.node;
      memo.route = route; memo.time = Date.now();
    }
    if (!memo.root) {
      const home = await request('homepage', {}, route);
      const root = (home.children || []).find(n => n.content?.directory_type === 5 || n.name === '我的创作');
      if (!root?.id) throw failure('directory_pending', '豆包创作目录未就绪');
      memo.root = nodeId(root.id);
    }
    let cursor = '', node = memo.node;
    const cursors = new Set();
    for (let i=0; !node && i<12; i++) {
      const payload = {node_id:memo.root, need_full_path:true, size:50,
        sort_param:{need_sort_config:true,sort_order:1,sort_type:0}};
      if (cursor) Object.assign(payload,{cursor,next_cursor_with_sort:cursor});
      const data = await request('node_info',payload,route);
      node = (data.children || []).find(n => n.node_type === 6 && n.key === videoId);
      if (node) break;
      cursor = String(data.next_cursor || '');
      if (!data.has_more || !cursor || cursors.has(cursor)) break;
      cursors.add(cursor);
    }
    if (!node) throw failure('directory_pending', '成品正在同步到豆包创作目录，请稍后重试');
    if (node.key !== videoId) throw failure('identity', '原片与当前视频不匹配');
    const id = nodeId(node.id);
    memo.node = node; // Retry download-info directly; do not rescan all creations.
    const data = await request('get_download_info',{requests:[{node_id:id}]},route);
    const info = (data.download_infos || []).find(n => nodeId(n.node_id) === id);
    if (!info || !accepted(info.main_url)) throw failure('original_pending', '尚未取得官方原片下载地址');
    return {url:info.main_url, declared_size:Number(node.size)||0, video_id:videoId,
      width:Number(node.content?.image_width)||0,height:Number(node.content?.image_height)||0,
      source:'doubao.official_download',priority:100};
  }
  const RESOLVE_STALE_MS = 25000;
  const DIRECTORY_REFRESH_ATTEMPTS = 30;
  const jobs = new Map();
  const api = {version:3, accepted};
  api.resolve = videoId => resolve(videoId, {});
  const start = (job, videoId, route, now) => {
    if (job.syncingAttempts >= DIRECTORY_REFRESH_ATTEMPTS) {
      // The creation directory can stay stale even after the video is ready.
      // Refresh the root and node instead of retrying the same cached context.
      job.memo = {};
      job.syncingAttempts = 0;
    }
    job.status = 'resolving'; job.reason = 'none'; job.attempt++; job.started = now;
    const token = ++job.token;
    Promise.resolve().then(() => resolve(videoId,job.memo)).then(result => {
      if (job.token !== token || job.status !== 'resolving') return;
      if (location.href !== route) throw failure('route_changed', '对话已切换');
      job.result = result; job.status = 'ready'; job.finished = Date.now();
    }).catch(error => {
      // A timed-out lookup may still finish later. It must never overwrite the
      // replacement lookup that was started for the same video.
      if (job.token !== token || job.status !== 'resolving') return;
      job.status = 'waiting';
      job.reason = error.originalReason || (/Timeout|Abort/.test(error.name || '') ? 'timeout' : 'network');
      const syncing = ['directory_pending','original_pending'].includes(job.reason);
      if (syncing) {
        job.syncingAttempts++;
      } else {
        job.syncingAttempts = 0;
        job.memo = {};
      }
      job.next = Date.now() + (syncing ? 2000 : Math.min(30000,5000*job.attempt));
    });
  };
  // Return immediately to CDP. One lookup survives however many short polls the
  // host makes; the multi-request promise is never tied to CDP's 20-second wait.
  api.poll = videoId => {
    if (!validVideo(videoId)) throw failure('identity', '视频标识不正确');
    const route = location.href, now = Date.now();
    for (const [id, job] of jobs) {
      if (job.route !== route || (job.status !== 'resolving' && now-job.touched > 60000)) jobs.delete(id);
    }
    let job = jobs.get(videoId);
    if (!job) {
      if (jobs.size >= 8) jobs.delete(jobs.keys().next().value);
      job = {route, status:'waiting', reason:'none', attempt:0, syncingAttempts:0,
        token:0, next:0, touched:now, memo:{}};
      jobs.set(videoId,job);
    }
    job.touched = now;
    if (job.status === 'resolving' && now - job.started >= RESOLVE_STALE_MS) {
      // Do not leave the host waiting forever on a browser request that stopped
      // answering. Invalidate its callbacks, then retry at the normal cadence.
      job.token++;
      job.status = 'waiting'; job.reason = 'timeout'; job.next = now + 2000;
      job.memo = {}; job.syncingAttempts = 0;
    }
    if (job.status === 'ready' && now-job.finished > 60000) {
      job.status = 'waiting'; job.next = 0; delete job.result;
    }
    if (job.status === 'waiting' && now >= job.next) {
      start(job, videoId, route, now);
    }
    return {status:job.status, reason:job.reason, attempt:job.attempt,
      elapsed:Math.max(0,(now-(job.started || now))/1000),
      ...(job.status === 'ready' ? {result:job.result} : {})};
  };
  window.__anneDoubaoOriginal = api;
  window.__anneDoubao = api;
})()
