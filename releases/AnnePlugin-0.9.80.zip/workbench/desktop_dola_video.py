﻿"""Account/page-bound Dola parameter actions; never submits or opens a client."""
import json
from pathlib import Path
import re
import threading
import time
import urllib.parse
import urllib.request

_locks={}
_lock=threading.Lock()


class VideoParameterError(RuntimeError):
    pass


def chat_route(url):
    try:
        value=urllib.parse.urlsplit(str(url or ''))
        if (value.scheme not in {'chrome','dola'} or value.hostname!='dola-chat' or value.username is not None
                or value.password is not None or value.port is not None):return None
        return value.path or '/',value.query,value.fragment
    except (TypeError,ValueError):return None


# Wire values observed from the client itself. Forcing them means the page's model
# control is only cosmetic: the submitted request carries the chosen model either way.
WIRE_MODEL={'2.0':'seedance_v2.0','2.0 Fast':'seedance_v2.0','2.5':'seedance_v2.5'}


def model_name(value):
    plain=re.sub(r'\s+','',str(value or '')).lower().replace('．','.')
    plain=re.sub(r'^(?:dreamina)?seedance','',plain)
    return {'2.0fast':'2.0 Fast','2.0':'2.0','2.5':'2.5'}.get(plain,'')


def read_targets(port):
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self,*args,**kwargs):return None
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
    with opener.open(f'http://127.0.0.1:{port}/json/list',timeout=3) as response:
        raw=response.read(1024*1024+1)
    if len(raw)>1024*1024:raise VideoParameterError('客户端页面列表异常，未设置时长')
    rows=json.loads(raw)
    if not isinstance(rows,list):raise VideoParameterError('客户端页面列表尚未就绪，未设置时长')
    return rows


def exact_target(rows,target_id,route,port):
    matches=[r for r in rows if isinstance(r,dict) and r.get('id')==target_id and r.get('type')=='page'
             and chat_route(r.get('url'))==route]
    if len(matches)!=1:raise VideoParameterError('原账号的任务页面已变化，未设置时长')
    endpoint=matches[0].get('webSocketDebuggerUrl','')
    try:
        url=urllib.parse.urlsplit(endpoint)
        valid=(url.scheme=='ws' and url.hostname in {'127.0.0.1','localhost'} and url.port==port
               and url.username is None and url.password is None and not url.query and not url.fragment
               and url.path=='/devtools/page/'+target_id)
    except (TypeError,ValueError):valid=False
    if not valid:raise VideoParameterError('客户端页面连接归属不符，未设置时长')
    return endpoint


STATE_JS=r'''(()=>{
 const visible=e=>e&&e.getBoundingClientRect().width&&getComputedStyle(e).visibility!=='hidden';
 const editors=[...document.querySelectorAll('[role="textbox"],.tiptap[contenteditable="true"],textarea[data-testid="chat_input_input"]')]
   .filter(e=>visible(e)&&!e.closest('[data-message-id]'));
 const roots=[...new Set(editors.map(e=>e.closest('[data-chat-input],[data-testid="chat_input"]')||e.closest('.guidance-input-surface')).filter(visible))];
 if(roots.length!==1)return {ready:false};
 const controls=[...roots[0].querySelectorAll('[data-input-engine-actionbar-control-key="video-model"]')];
 // Builds that render the model entry as plain text expose no control key. The model is
 // written into the outgoing request anyway, so an existing composer is enough there.
 if(controls.length!==1)return {ready:true,route:location.href,model:'',no_control_key:true};
 const label=controls[0].innerText||controls[0].textContent||'';
 const model=label.match(/(?:Seedance\s*)?2[.．](?:0\s*Fast|0|5)/i)?.[0]||'';
 return {ready:true,route:location.href,model};
})()'''


def evaluate(endpoint,expression):
    from dola_long_login import cdp_command
    result=cdp_command(endpoint,'Runtime.evaluate',dict(expression=expression,returnByValue=True,awaitPromise=True),timeout=12)
    if not isinstance(result,dict) or result.get('exceptionDetails'):
        raise VideoParameterError('客户端时长设置未完成，未提交任务')
    return (result.get('result') or {}).get('value')


def duration_script(duration,route,model,force_model=False,force_ratio=''):
    source=(Path(__file__).parent/'desktop_dola_duration.js').read_text(encoding='utf8')
    return '('+source+')('+json.dumps(dict(duration=duration,route=route,model=model,
                                           forceModel=bool(force_model),ratio=force_ratio or ''),
                                     ensure_ascii=True)+')'


def configure_duration(module,root,index,payload,can_operate=lambda:True):
    """Validate stable registry, process generation, page and route on every step."""
    import desktop_native as native
    if (type(index) is not int or index<=0 or not isinstance(payload,dict)
            or type(payload.get('duration')) is not int or payload['duration'] not in {15,30}
            or type(payload.get('port')) is not int):
        raise VideoParameterError('时长设置缺少有效的账号和参数')
    target=payload.get('target_id');route=chat_route(payload.get('page_url'));model=model_name(payload.get('model'))
    # Dola removed Seedance 2.5 from the picker while the backend still accepts it.
    # For 2.5 the composer is expected to show another video model and the request
    # hook writes seedance_v2.5 into the outgoing ability_param instead.
    forced=WIRE_MODEL.get(model,'')
    # The aspect ratio is a request field as well (ability_param.ratio, null while
    # the page leaves it on auto), so the plugin's choice is written on the wire
    # instead of clicking the page's ratio control.
    aspect=str(payload.get('aspect_ratio') or payload.get('ratio') or '').strip().replace('：',':')
    if aspect and not re.fullmatch(r'[0-9]{1,2}:[0-9]{1,2}',aspect):
        raise VideoParameterError('视频比例参数无效，未修改任何窗口')
    if (not isinstance(target,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',target) or route is None
            or payload['duration'] not in ({15,30} if model in {'2.5','2.0 Fast'} else {15} if model=='2.0' else set())):
        raise VideoParameterError('时长或原任务页面参数不匹配，未修改任何窗口')
    rows=[r for r in getattr(module,'accounts_list',[]) if isinstance(r,dict) and r.get('index')==index]
    if len(rows)!=1 or not isinstance(rows[0].get('email'),str):raise VideoParameterError('目标 Dola 账号已变化，请刷新后重试')
    account_key=rows[0]['email'];port=module.get_account_port(index)
    if type(port) is not int or not 1<=port<=65535 or payload['port']!=port:
        raise VideoParameterError('目标账号端口已变化，未设置其他窗口')
    with _lock:account_lock=_locks.setdefault((str(Path(root).resolve()),index),threading.Lock())
    if not account_lock.acquire(blocking=False):raise VideoParameterError('该账号正在设置参数，请稍后重试')
    try:
        pid=native.listener_pid(port)
        identity=native.process_identity(pid) if pid is not None else None
        expected=(Path(root)/'runtime/Cici/app/Cici.exe').resolve()
        if identity is None or identity[1]!=expected:
            raise VideoParameterError('未找到本工作台内该账号的已打开客户端；未重新启动或改动登录')
        def guard():
            current=[r for r in getattr(module,'accounts_list',[]) if isinstance(r,dict) and r.get('index')==index]
            if (not can_operate() or len(current)!=1 or current[0].get('email')!=account_key
                    or module.get_account_port(index)!=port or native.listener_pid(port)!=pid
                    or native.process_status(identity)!='running'):
                raise VideoParameterError('原账号正在关闭、切换或重新启动，未继续设置时长')
        def page_state():
            # Dola replaces the composer controls while entering video mode.
            # During that short React/CDP hydration window the model control
            # can be absent or report an empty label even though this exact
            # account/page is still valid. Retry only the read-only page/model
            # observation; never retry the duration mutation or choose another
            # target. Account, process, target and route identity remain strict.
            last_error=None
            for attempt in range(8):
                guard()
                try:
                    endpoint=exact_target(read_targets(port),target,route,port)
                    guard()
                    state=evaluate(endpoint,STATE_JS)
                    actual=chat_route(state.get('route')) if isinstance(state,dict) else None
                    # Entering video mode can change the route, so the same conversation
                    # (same first path segment) is accepted; the account, port, target and
                    # process identity checks above stay strict.
                    same_page = bool(actual and route and actual[0].split('/')[1:2] == route[0].split('/')[1:2])
                    if (isinstance(state,dict) and state.get('ready') and
                            (same_page or actual == route) and
                            (forced or state.get('no_control_key')
                             or model_name(state.get('model'))==model)):
                        return endpoint
                    last_error='page_not_ready_or_model_transition'
                except VideoParameterError as error:
                    # A transient target-list/CDP read can occur while the
                    # client swaps the composer. Keep the same target bound.
                    last_error=error
                if attempt < 7:
                    time.sleep(.25)
            raise VideoParameterError('原页面或模型已变化，未继续设置时长') from (
                last_error if isinstance(last_error,Exception) else None)
        endpoint=page_state()
        guard()
        result=evaluate(endpoint,duration_script(payload['duration'],route,model,force_model=forced,
                                                 force_ratio=aspect))
        guard()
        wired=str(result.get('model') or '') if isinstance(result,dict) else ''
        if (not isinstance(result,dict) or result.get('verified') is not True
                or result.get('duration')!=payload['duration']
                or (forced and wired!=forced)):
            # The ratio is enforced by the hook itself: it refuses to let the request out
            # unless ability_param carries the requested ratio, so a missing echo here is
            # not a failure. Checking it twice only produced false rejections.
            if isinstance(result,dict) and result.get('reason') in {'legacy_hook','incompatible_hook'}:
                raise VideoParameterError('该页面仍有旧版时长设置，请正常关闭本账号窗口后重开；未发送任务或清除登录')
            raise VideoParameterError('时长设置未通过回读核验，未发送任务')
        page_state()
        return dict(success=True,verified=True,verification='request-parameter-hook',account_index=index,
                    target_id=target,duration=payload['duration'],model=model,force_model=bool(forced),
                    wire_model=wired,aspect_ratio=aspect)
    finally:
        account_lock.release()
